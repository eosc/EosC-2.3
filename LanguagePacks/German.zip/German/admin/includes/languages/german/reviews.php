<?php
/*
  $Id: reviews.php,v 1.6 2002/04/17 15:57:07 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/
define('NAVBAR_TITLE', 'Meinungen');
define('HEADING_TITLE', 'Was sagen die Anderen?');
define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_RATING', 'Rating');
define('TABLE_HEADING_DATE_ADDED', 'Tag aufgenommen');
define('TABLE_HEADING_ACTION', 'Aktion');

define('ENTRY_PRODUCT', 'Produkt:');
define('ENTRY_FROM', 'Von:');
define('ENTRY_DATE', 'Tag:');
define('ENTRY_REVIEW', 'Meinung:');
define('ENTRY_REVIEW_TEXT', '<small><font color="#ff0000"><b>NOTE:</b></font></small>&nbsp;HTML is not translated!&nbsp;');
define('ENTRY_RATING', 'Rating:');

define('TEXT_INFO_DELETE_REVIEW_INTRO', 'Sind sie sicher das sie diese Meinung loeschen wollen?');

define('TEXT_INFO_DATE_ADDED', 'Tag aufgenommen:');
define('TEXT_INFO_LAST_MODIFIED', 'Zuletzt geaendert:');
define('TEXT_INFO_IMAGE_NONEXISTENT', 'Bild existiert nicht');
define('TEXT_INFO_REVIEW_AUTHOR', 'Author:');
define('TEXT_INFO_REVIEW_RATING', 'Rating:');
define('TEXT_INFO_REVIEW_READ', 'Read:');
define('TEXT_INFO_REVIEW_SIZE', 'Size:');
define('TEXT_INFO_PRODUCTS_AVERAGE_RATING', 'Average Rating:');

define('TEXT_OF_5_STARS', '%s of 5 Stars!');
define('TEXT_GOOD', '<small><font color="#ff0000"><b>GOOD</b></font></small>');
define('TEXT_BAD', '<small><font color="#ff0000"><b>BAD</b></font></small>');
define('TEXT_INFO_HEADING_DELETE_REVIEW', 'Delete Review');

// Review Approval
define('TEXT_APPROVED', 'Genehmigt') ;
define('TEXT_APPROVE', 'Genehmigen') ;
define('TEXT_DISAPPROVE', 'Nicht genehmigt') ;
define('TEXT_YES', 'JA') ;
define('TEXT_NO', 'NEIN') ;
?>