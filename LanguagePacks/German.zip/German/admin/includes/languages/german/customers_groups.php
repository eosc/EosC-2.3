<?php
/*
   for Separate Pricing Per Customer v4 2005/03/03
*/

define('HEADING_TITLE', 'Gruppen');
define('HEADING_TITLE_SEARCH', 'Suche::');

define('TABLE_HEADING_NAME', 'Name');
define('TABLE_HEADING_ACTION', 'Aktion');

define('ENTRY_GROUPS_NAME', 'Gruppenname:');
define('ENTRY_GROUP_SHOW_TAX', 'Zeige&#160;Preise&#160;mit/ohne&#160;Steuer:');
define('ENTRY_GROUP_SHOW_TAX_YES', 'Zeige Preise mit Steuer');
define('ENTRY_GROUP_SHOW_TAX_NO', 'Zeige Preise ohne Steuer');

define('ENTRY_GROUP_TAX_EXEMPT', 'Steuerbefreit:');
define('ENTRY_GROUP_TAX_EXEMPT_YES', 'Ja');
define('ENTRY_GROUP_TAX_EXEMPT_NO', 'Nein');

define('ENTRY_GROUP_PAYMENT_SET', 'Zahlungsmodule f�r die Kundengruppe definieren');
define('ENTRY_GROUP_PAYMENT_DEFAULT', 'Ben�tze die Einstellungen der Grundeinstellung');
define('ENTRY_PAYMENT_SET_EXPLAIN', 'Wenn <b><i>Zahlungsmodule f�r die Kundengruppe definieren</i></b> gew&auml;hlt wird aber keine Checkbox gesetzt ist, werden die Grundeinstellungen ben&uuml;tzt.');

define('ENTRY_GROUP_SHIPPING_SET', 'Versandarten f�r f�r die Kundengruppe definieren');
define('ENTRY_GROUP_SHIPPING_DEFAULT', 'Ben�tze die Einstellungen der Grundeinstellung');
define('ENTRY_SHIPPING_SET_EXPLAIN', 'Wenn <b><i>Versandarten f�r f�r die Kundengruppe definieren</i></b> gew&auml;hlt wird aber keine Checkbox gesetzt ist, werden die Grundeinstellungen ben&uuml;tzt.');

define('TEXT_DELETE_INTRO', 'Soll diese Gruppe wirklich gel&ouml;sch werden?');
define('TEXT_DISPLAY_NUMBER_OF_CUSTOMERS_GROUPS', 'Kundengruppe <b>%d</b> bis <b>%d</b> (von <b>%d</b>)');
define('TEXT_INFO_HEADING_DELETE_GROUP', 'Gruppe l&ouml;schen');

define('ERROR_CUSTOMERS_GROUP_NAME', 'Bitte einen Gruppennamen eingeben');
?>
