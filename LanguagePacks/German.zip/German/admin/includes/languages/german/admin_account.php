<?php
/*
  $Id: admin_members.php,v 1.13 2002/08/19 01:45:58 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Schlie�t Beitrag Ein:
  Zugang mit waagerecht ausgerichtetem Konto (v. 2.2a) f�r den Admin Bereich des osCommerce (MS2)

	Diese Akte kann gel�scht werden, wenn man den oben genannten Beitrag entfernt
*/

define('HEADING_TITLE', 'Admin Konto');

define('TABLE_HEADING_ACCOUNT', 'Mein Konto');

define('TEXT_INFO_FULLNAME', '<b>Name: </b>');
define('TEXT_INFO_FIRSTNAME', '<b>Vorname: </b>');
define('TEXT_INFO_LASTNAME', '<b>Letzter Name: </b>');
define('TEXT_INFO_EMAIL', '<b>Email Address: </b>');
define('TEXT_INFO_PASSWORD', '<b>Kennwort: </b>');
define('TEXT_INFO_PASSWORD_HIDDEN', '-Versteckt-');
define('TEXT_INFO_PASSWORD_CONFIRM', '<b>Best�tigen Sie Kennwort: </b>');
define('TEXT_INFO_CREATED', '<b>Konto erstellt: </b>');
define('TEXT_INFO_LOGDATE', '<b>Letzter Login: </b>');
define('TEXT_INFO_LOGNUM', '<b>Maschinenbordbuch-Zahl: </b>');
define('TEXT_INFO_GROUP', '<b>Gruppe Niveau: </b>');
define('TEXT_INFO_ERROR', '<font color="red">Email Adresse ist bereits verwendet worden! Bitte erneut versuchen.</font>');
define('TEXT_INFO_MODIFIED', 'Ge�ndert: ');

define('TEXT_INFO_HEADING_DEFAULT', 'Konto bearbeiten ');
define('TEXT_INFO_HEADING_CONFIRM_PASSWORD', 'Kennwort-Best�tigung ');
define('TEXT_INFO_INTRO_CONFIRM_PASSWORD', 'Kennwort:');
define('TEXT_INFO_INTRO_CONFIRM_PASSWORD_ERROR', '<font color="red"><b>ST�RUNG:</b> falsches Kennwort!</font>');
define('TEXT_INFO_INTRO_DEFAULT', 'Klicken Sie die Bearbeitentaste unten, um Ihre Kontoinformationen zu �ndern.');
define('TEXT_INFO_INTRO_DEFAULT_FIRST_TIME', '<br><b>Warnung:</b><br>Hallo <b>%s</b>, Dies ist Ihr erster Besuch, wir empfehlen dringend eine �nderung des Passworts!');
define('TEXT_INFO_INTRO_DEFAULT_FIRST', '<br><b>WARNING:</b><br>Hallo <b>%s</b>, Wir empfehlen eine �nderung Ihrer Email von <font color="red">admin@localhost</font> und Ihres Kennworts!');
define('TEXT_INFO_INTRO_EDIT_PROCESS', 'Alles f�ngt werden angefordert auf. Klicken speichert, um einzureichen.');

define('JS_ALERT_FIRSTNAME',        '- Erfordert: Vorname \n');
define('JS_ALERT_LASTNAME',         '- Erfordert: Nachname \n');
define('JS_ALERT_EMAIL',            '- Erfordert: Email Addresse \n');
define('JS_ALERT_PASSWORD',         '- Erfordert: Kennwort \n');
define('JS_ALERT_FIRSTNAME_LENGTH', '- Vorname ist zu kurz ');
define('JS_ALERT_LASTNAME_LENGTH',  '- Nachnahme ist zu kurz ');
define('JS_ALERT_PASSWORD_LENGTH',  '- Kennwort ist zu kurz ');
define('JS_ALERT_EMAIL_FORMAT',     '- Format der Email Adresse ist unzul�ssig! \n');
define('JS_ALERT_EMAIL_USED',       '- Email Adresse ist bereits vergeben! \n');
define('JS_ALERT_PASSWORD_CONFIRM', '- Es gibt einen Typo in der Kennwort-Best�tigung auffangen! \n');

define('ADMIN_EMAIL_SUBJECT', 'Pers�nliche Informationen bearbeiten');
define('ADMIN_EMAIL_TEXT', 'Hallo %s,' . "\n\n" . 'Ihre pers�nlichen Informationen, m�glicherweise auch Ihr Kennwort, sind ge�ndert worden.  Wenn dies ohne Ihr Wissen oder Ihre Zustimmung geschehen ist, treten Sie mit dem Administrator schnellstens in Verbindung!' . "\n\n" . 'Website : %s' . "\n" . 'Username: %s' . "\n" . 'Kennwort: %s' . "\n\n" . 'Danke!' . "\n" . '%s' . "\n\n" . 'Dies ist eine automatisierte Nachricht, bitte antworten Sie nicht!');
?>