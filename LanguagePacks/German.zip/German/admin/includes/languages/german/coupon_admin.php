<?php
/*
  $Id: coupon_admin.php,v 1.1.2.2 2003/05/15 23:10:55 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('TOP_BAR_TITLE', 'Statistics');
define('HEADING_TITLE', 'Rabatt Coupons');
define('HEADING_TITLE_STATUS', 'Status : ');
define('TEXT_CUSTOMER', 'Kunden:');
define('TEXT_COUPON', 'Coupon Name');
define('TEXT_COUPON_ALL', 'Alle Coupons');
define('TEXT_COUPON_ACTIVE', 'Active Coupons');
define('TEXT_COUPON_INACTIVE', 'Inaktive Coupons');
define('TEXT_SUBJECT', 'Betr.:');
define('TEXT_FROM', 'Von:');
define('TEXT_FREE_SHIPPING', 'Frachtfrei');
define('TEXT_MESSAGE', 'Message:');
define('TEXT_SELECT_CUSTOMER', 'Kunde waehlen');
define('TEXT_ALL_CUSTOMERS', 'Alle Kunden');
define('TEXT_NEWSLETTER_CUSTOMERS', 'An Alle Newsletter Abonenten');
define('TEXT_CONFIRM_DELETE', 'Sind sie sicher das sie diesen Couponloeschen wollen?');

define('TEXT_TO_REDEEM', 'Sie koennen diesen Coupon waehrend des Bezahlvorgangs einloesen. Geben sie den code ein und druecken den Einloese button.');
define('TEXT_IN_CASE', ' falls sie probleme haben. ');
define('TEXT_VOUCHER_IS', 'Der Coupon code ist ');
define('TEXT_REMEMBER', 'Verlieren Sie nicht den Coupon code, bewahren sie ihn sicher auf das sie auf dieses angebot zugreifen koennen.');
define('TEXT_VISIT', 'wenn sie besuchen ' . HTTP_SERVER . DIR_WS_CATALOG);
define('TEXT_ENTER_CODE', ' und geben sie den code ein ');

define('TABLE_HEADING_ACTION', 'Aktion');

define('CUSTOMER_ID', 'Kunden id');
define('CUSTOMER_NAME', 'Kunden Name');
define('REDEEM_DATE', 'Einloesetag');
define('IP_ADDRESS', 'IP Address');

define('TEXT_REDEMPTIONS', 'Einloeseoptionen');
define('TEXT_REDEMPTIONS_TOTAL', 'Gesamt');
define('TEXT_REDEMPTIONS_CUSTOMER', 'Fuer diesen Kunden');
define('TEXT_NO_FREE_SHIPPING', 'Nicht Frachtfrei');

define('NOTICE_EMAIL_SENT_TO', 'Notice: Email sent to: %s');
define('ERROR_NO_CUSTOMER_SELECTED', 'Error: Kein Kunde ausgewaehlt.');
define('COUPON_NAME', 'Coupon Name');
//define('COUPON_VALUE', 'Coupon Value');
define('COUPON_AMOUNT', 'Coupon Summe');
define('COUPON_CODE', 'Coupon Code');
define('COUPON_STARTDATE', 'Start Tag');
define('COUPON_FINISHDATE', 'End TAG');
define('COUPON_FREE_SHIP', 'Frachtfrei');
define('COUPON_DESC', 'Coupon Beschreibung');
define('COUPON_MIN_ORDER', 'Coupon Minimum Order');
define('COUPON_USES_COUPON', 'Einloesungen per Coupon');
define('COUPON_USES_USER', 'Einloesungen per Kunde');
define('COUPON_PRODUCTS', 'Gueltige Produkt Liste');
define('COUPON_CATEGORIES', 'Gueltige Kategories Liste');
define('VOUCHER_NUMBER_USED', 'Nummer gebraucht');
define('DATE_CREATED', 'Erstellungs Tag');
define('DATE_MODIFIED', 'Aenderungs Tag');
define('TEXT_HEADING_NEW_COUPON', 'Neuen Coupon erstellen');
define('TEXT_NEW_INTRO', 'Bitte fuellen sie folgendes aus fuer einen neunen coupon.<br>');


define('COUPON_NAME_HELP', 'Kurzname des coupon');
define('COUPON_AMOUNT_HELP', 'Rabatt fuer den coupon fest oder als % .');
define('COUPON_CODE_HELP', 'Tagen sie hier einen code ein, oder lassen sie es frei fuer einen automatisch generierten code.');
define('COUPON_STARTDATE_HELP', 'Beginn der Gueltigkeit des coupon');
define('COUPON_FINISHDATE_HELP', 'Ende der Gueltigkeit des coupon');
define('COUPON_FREE_SHIP_HELP', 'Der Coupon ist frachtfrei. Note. Dies ueberschreibt die coupon hoehe beachtet jedoch den mindermengen zuschlag');
define('COUPON_DESC_HELP', 'Beschreibung des coupon f�r den kunden');
define('COUPON_MIN_ORDER_HELP', 'Mindestbestellwert fuer die Gueltigkeit des coupon');
define('COUPON_USES_COUPON_HELP', 'Max. Anzahl der Nutzungen des coupon, leer fuer keine Einschraenkung.');
define('COUPON_USES_USER_HELP', 'Max. Zeit der Nutzungen des coupon, leer fuer keine Einschraenkung..');
define('COUPON_PRODUCTS_HELP', 'Komma getrennte Liste der Produkte fuer die der Coupon g�ltig ist, leer fuer keine Einschraenkung.');
define('COUPON_CATEGORIES_HELP', 'Komma getrennte Liste der Kategorien fuer die der Coupon g�ltig ist, leer fuer keine Einschraenkung.');
define('ERROR_NO_COUPON_AMOUNT', 'Error: Keine Coupon Summe angegeben. Geben sie eine summe an oder waehlen frachtfrei.');
define('ERROR_COUPON_EXISTS', 'Error: Ein coupon mit gleichem code besteht bereits.');
define('COUPON_BUTTON_EMAIL_VOUCHER', 'Email coupon');
define('COUPON_BUTTON_EDIT_VOUCHER', 'Edit coupon');
define('COUPON_BUTTON_DELETE_VOUCHER', 'coupon loeschen');
define('COUPON_BUTTON_VOUCHER_REPORT', 'Coupon Report');
define('COUPON_STATUS', 'Status');
define('COUPON_STATUS_HELP', 'Set to ' . IMAGE_ICON_STATUS_RED . ' to disable customers\' ability to use the coupon.');
?>