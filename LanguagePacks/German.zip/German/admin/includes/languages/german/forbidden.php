<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Schlie�t Beitrag Ein:
  Zugang mit waagerecht ausgerichtetem Konto (v. 2.2a) f�r den Admin Bereich des osCommerce (MS2)

	Diese Akte kann gel�scht werden, wenn man den oben genannten Beitrag entfernt
*/

define('HEADING_TITLE', 'Zugang verweigert!');
define('NAVBAR_TITLE', 'Sie haben f�r diesen Bereich keine Befugnis!');
define('TEXT_MAIN', '&nbsp;Bei Pronlemen treten Sie bitte mit Ihrem <b>Admin</b> in Verbindung!<br>&nbsp;');
define('TEXT_BACK', 'R�ckseite');
?>