<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Empfohlene Produkte');

define('TABLE_HEADING_PRODUCTS', 'Produkte');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_FEATURED_PRODUCT', 'Produkt:');
define('TEXT_FEATURED_EXPIRES_DATE', 'Erwartet am:');

define('TEXT_INFO_DATE_ADDED', 'Aufgenommen:');
define('TEXT_INFO_LAST_MODIFIED', 'Geaendert:');
define('TEXT_INFO_EXPIRES_DATE', 'Erwartet am:');
define('TEXT_INFO_STATUS_CHANGE', 'Status geaendert:');

define('TEXT_INFO_HEADING_DELETE_FEATURED', 'Loeschen Featured Produkt');
define('TEXT_INFO_DELETE_INTRO', 'Sind Sie sicher das sie das featured produkt loeschen wollen?');

define('TEXT_DISPLAY_NUMBER_OF_FEATURED', 'Displaying <b>%d</b> to <b>%d</b> (of <b>%d</b> featured products)');

?>