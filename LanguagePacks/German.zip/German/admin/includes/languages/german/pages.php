<?php

define('HEADING_TITLE', 'Seiten Editor');
define('TEXT_NEW_PAGE', 'Neue Seite');

define('TEXT_PAGES_NAME', 'Linking Name:<br><small>kleinbuchstaben keine leerzeichen</small>');
define('TEXT_PAGES_TITLE', 'Seiten Titel:');
define('TEXT_PAGES_BODY', 'Seiten Text:');
define('TEXT_PAGES_IMAGE', 'Seiten Bild:<br><small>in der rechten oberen Ecke der Seite</small>');
define('TEXT_PAGES_STATUS', 'Seiten Status:');
define('TEXT_SORT_ORDER', 'Sort Order:');
define('TEXT_PAGE_NOT_ACTIVE', 'Disabled');
define('TEXT_PAGE_ACTIVE', 'Aktiv');
define('TEXT_PAGES', 'Pages:');

define('TABLE_HEADING_PAGE_NAME', 'Name');
define('TABLE_HEADING_PAGE_STATUS', 'Status');
define('TABLE_HEADING_PAGE_TITLE', 'Titel');
define('TABLE_HEADING_ACTION', 'Aktion');

define('TEXT_INFO_HEADING_DELETE_PAGE', 'Seite L�schen');
define('TEXT_DELETE_PAGE_INTRO', 'Sind sie sicher das sie die seite endgueltig loeschen wollen?');
define('TEXT_IMAGE_NONEXISTENT', 'Bild existiert nicht');


?>
