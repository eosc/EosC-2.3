<?php
/*
  $Id: product_reviews_info.php,v 1.8 2003/02/16 00:42:03 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Meinungen');
define('HEADING_TITLE', 'Meinung zu \'%s\'');
define('SUB_TITLE_PRODUCT', 'Produkt:');
define('SUB_TITLE_FROM', 'Autor:');
define('SUB_TITLE_DATE', 'Datum:');
define('SUB_TITLE_REVIEW', 'Meinung:');
define('SUB_TITLE_RATING', 'Bewertung:');
define('TEXT_OF_5_STARS', '%s von 5 Sternen!');
define('TEXT_CLICK_TO_ENLARGE', 'F&uuml;r eine gr&ouml;ssere Darstellung<br>klicken Sie auf das Bild.');
?>