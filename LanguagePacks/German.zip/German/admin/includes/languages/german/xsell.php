<?php
/* $Id$
osCommerce, Open Source E-Commerce Solutions
http://www.oscommerce.com
Copyright (c) 2002 osCommerce

Released under the GNU General Public License
xsell.php
Original Idea From Isaac Mualem im@imwebdesigning.com <mailto:im@imwebdesigning.com>
Complete Recoding From Stephen Walker admin@snjcomputers.com
*/

define('CROSS_SELL_SUCCESS', 'Cross Sell Artikel erfolgreich geaendert fuer Artikel #'.$_GET['add_related_product_ID']);
define('SORT_CROSS_SELL_SUCCESS', 'Sort Order erfolgreich geaendert fuer Artikel #'.$_GET['add_related_product_ID']);
define('HEADING_TITLE', 'Cross-Sell (X-Sell) Admin');
define('TABLE_HEADING_PRODUCT_ID', 'Produkt Id');
define('TABLE_HEADING_PRODUCT_MODEL', 'Produkt Modell');
define('TABLE_HEADING_PRODUCT_NAME', 'Produkt Name');
define('TABLE_HEADING_CURRENT_SELLS', 'Momentane Cross-Sells');
define('TABLE_HEADING_UPDATE_SELLS', 'Update Cross-Sells');
define('TABLE_HEADING_PRODUCT_IMAGE', 'Produkt Bild');
define('TABLE_HEADING_PRODUCT_PRICE', 'Produkt Preis');
define('TABLE_HEADING_CROSS_SELL_THIS', 'Cross-Sell dies?');
define('TEXT_EDIT_SELLS', 'Edit');
define('TEXT_SORT', 'Priorit�t');
define('TEXT_SETTING_SELLS', 'Cross-Sells setzen fuer');
define('TEXT_PRODUCT_ID', 'Product Id');
define('TEXT_MODEL', 'Modell');
define('TABLE_HEADING_PRODUCT_SORT', 'Sort Order');
define('TEXT_NO_IMAGE', 'Kein Bild');
define('TEXT_CROSS_SELL', 'Cross-Sell');
?>
