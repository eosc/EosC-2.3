<?php
/*
  $Id: stats_monthly_sales.php,v 2.2 $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/
// German translation

define('HEADING_TITLE', 'Verk&auml;ufe & Steuerreport');
define('HEADING_TITLE_STATUS','Bestellstatus');
define('HEADING_TITLE_REPORTED','Berichtet');
define('TEXT_DETAIL','Detail');
define('TEXT_ALL_ORDERS', 'alles Bestellungen');
define('TEXT_NOTHING_FOUND', 'kein Einkommen f&uuml;r diese Vorw&auml;hler');
define('TEXT_BUTTON_REPORT_BACK','Zur&uuml;ck');
define('TEXT_BUTTON_REPORT_INVERT','Invert');
define('TEXT_BUTTON_REPORT_PRINT','Print');
define('TEXT_BUTTON_REPORT_SAVE','Sichern CSV');
define('TEXT_BUTTON_REPORT_HELP','Help');
define('TEXT_BUTTON_REPORT_BACK_DESC', 'Zurueck zur Summe nach Monaten');
define('TEXT_BUTTON_REPORT_INVERT_DESC', 'Spalten invertieren');
define('TEXT_BUTTON_REPORT_PRINT_DESC', 'Druckansicht Report');
define('TEXT_BUTTON_REPORT_HELP_DESC', 'Ueber diesen Report und die Nutzung seiner Features');
define('TEXT_BUTTON_REPORT_GET_DETAIL', 'Klicken fuer Tagessummen dieses Monats');
define('TEXT_REPORT_DATE_FORMAT', 'j M Y -   g:i a'); // date format string
//  as specified in php manual here: http://www.php.net/manual/en/function.date.php
define('TABLE_HEADING_YEAR','Jahr');
define('TABLE_HEADING_MONTH', 'Monat');
define('TABLE_HEADING_DAY', 'Tag');
define('TABLE_HEADING_INCOME', 'Brutto<br> Umsatz');
define('TABLE_HEADING_SALES', 'Produkt<br> verkauf');
define('TABLE_HEADING_NONTAXED', 'Steuerfreier<br> verkauf');
define('TABLE_HEADING_TAXED', 'Besteuerter<br> verkauf');
define('TABLE_HEADING_TAX_COLL', 'Steuer<br> eingenommen');
define('TABLE_HEADING_SHIPHNDL', 'Transport<br> & Handling');
define('TABLE_HEADING_SHIP_TAX', 'Steuer auf<br /> Transport');
define('TABLE_HEADING_LOWORDER', 'Mindermengen<br> Zuschlag');
define('TABLE_HEADING_OTHER', 'Gut<br> scheine');  // could be any other extra class value
define('TABLE_FOOTER_YTD','YTD');
define('TABLE_FOOTER_YEAR','JAHR');
define('TEXT_HELP', '<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<title>Monthly Sales/Tax Report</title>
<link rel="stylesheet" type="text/css" href="includes/stylesheet.css">
</head>
<BODY>
<center>
<table width="95%"><tr><td>
<p class="main" align="center">
<b>Wie dieser Report zu nutzen ist</b>
<p class="main" align="justify">
<b>Reporting store activity by month</b>
<p class="smallText" align="justify">
Wenn dieser Report vom Report Menu aufgerufen wird zeigt er alle finanziellen Aktionen des Shop auf Monatsbasis.  Jeder Monat der Shop Historie wird in einer Zeile dargestellt und zeigt den Umsatz und alles Umsatzgruppen wie Steuern, Transport, Mindermengenzuschlag und Gutscheine. (Falls der Shop ohne Mindermengenzuschlag und Gutscheine arbeitet sind diese deaktiviert.)  Grundlage ist das Rechnungsdatum.
<p class="smallText" align="justify">
Die obere Zeile ist der aktuelle Monat die Historie befindet sich in den Zeilen darunter.  Nach jeden Jahr wird eine Fusszeile mit den Jahresums�tzen eingefuegt.
<p class="smallText" align="justify">
Sortierung aendern Klick "Invert" button.
<p class="main" align="justify">
<b>Report Monatsumsatz nach Tagen</b>
<p class="smallText" align="justify">
Der Tagesumsatz komm inerhalb eines Monats angezeigt werden durch Klick auf den Monatsnamen, Rueckkehr zur Monatsdarstellung Klick auf den "Back" button in der Tagesdarstellung.
<p class="main" align="justify">
<b>Was die Spalten darstellen (headers explained)</b>
<p class="smallText" align="justify">
Links sind Jahr und Monat.  Die anderen Spalten sind von links nach rechts:
<ul><li class="smallText"><b>Brutto Umsatz</b> - Summe aller Umsaetze
<li class="smallText"><b>Order Subtotal</b> - Warenumsatz des Monats
<br>Dann der Umsatz unterteilt in zwei Kategorien:
<li class="smallText"><b>Steuerfrei</b> - steuerfreie Umsaetze, and
<li class="smallText"><b>Besteuert</b> - Umsaetze mit Steuern
<li class="smallText"><b>Steuern eingenommen</b> - Summe der eingenommenen Steuern
<li class="smallText"><b>Transport & Handling</b> - Umsatz and Transpoirtkosten und Handling
<li class="smallText"><b>Steuern auf Transport</b> - Steuern auf Transport und Handling
<li class="smallText"><b>Mindermengenzuschlag</b> and <b>Gutscheine</b> - Umsatz mit Mindermengenzuschlag und Gutscheinen
</ul>
<p class="main" align="justify">
<b>Summen nach Status /b>
<p class="smallText" align="justify">
Um die Summe eines bestimmten Status anzuzeigen waehlen sie im Drop Down Menu rechts oben im Report Scgreen deb Status aus.  Abhaengig von den Shopeinstellungen koennen sie waehlen.  Wenn sie den Status aendern wird der Report sofort neu kalkuliert
<p class="main" align="justify">
<b>Steuerdetails</b>
<p class="smallText" align="justify">
Beim Klick auf den Steuerumsatz in einer Spalte werden in einem popup Steuerklassen und zugehoerige Umsaetze dargestellt.
<p class="main" align="justify">
<b>Drucken des Reports</b>
<p class="smallText" align="justify">
Um den Report druckerfreundlich darzustellen druecken Sue den PRINT button und offnen dann im Browser die Druckvorschau.  Der shopname und die Ueberschriften werden generiert um zu zeigen wann und fuer wen der Report generiert wurde.
<p class="main" align="justify">
<b>Speichern des Reports als Datei</b>
<p class="smallText" align="justify">
Um den Report als Datei zu speichern druecken sie den Save CSV button.  Der Report wird als Komma separiete Text Datei zum Browser gesandt und sie werden nach dem Speicherort gefragt. Die Datei kann spaeter mit Excel weiterbearbeitet werden. <br><br>
<p class="smallText">v 2.1.1
</td></tr>
</table>
</BODY>
</HTML>');
?>