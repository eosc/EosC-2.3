<?php
/*
  $Id: index.php,v 1.2 2003/07/11 09:04:22 jan0815 Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Aktion waehlen..');

define('BOX_TITLE_ORDERS', 'Orders');
define('BOX_TITLE_STATISTICS', 'Statistik');

define('BOX_ENTRY_SUPPORT_SITE', 'Support Site');
define('BOX_ENTRY_SUPPORT_FORUMS', 'Support Forums');
define('BOX_ENTRY_MAILING_LISTS', 'Mailing Lists');
define('BOX_ENTRY_BUG_REPORTS', 'Bug Reports');
define('BOX_ENTRY_FAQ', 'FAQ');
define('BOX_ENTRY_LIVE_DISCUSSIONS', 'Live Discussions');
define('BOX_ENTRY_CVS_REPOSITORY', 'CVS Container');
define('BOX_ENTRY_INFORMATION_PORTAL', 'Informations Portal');

define('BOX_ENTRY_CUSTOMERS', 'Kunden:');
define('BOX_ENTRY_PRODUCTS', 'Produkte:');
define('BOX_ENTRY_REVIEWS', 'Bewertungen:');

define('BOX_CONNECTION_PROTECTED', 'Sie sind nicht gesch�tzt durch %s secure SSL Verbindung.');
define('BOX_CONNECTION_UNPROTECTED', 'Sie sind nicht <font color="#ff0000"></font> durch eine sichere SSL Verbindung.');
define('BOX_CONNECTION_UNKNOWN', 'unbekannt');

define('CATALOG_CONTENTS', 'Beschreibungen');

define('REPORTS_PRODUCTS', 'Produkte');
define('REPORTS_ORDERS', 'Bestellungen');

define('TOOLS_BACKUP', 'Datensicherung');
define('TOOLS_BANNERS', 'Banner');
define('TOOLS_FILES', 'Dateien');
?>
