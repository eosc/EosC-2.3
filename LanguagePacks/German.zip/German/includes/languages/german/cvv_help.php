<?php
// this file was created by Clifton Murphy <blue_glowstick@yahoo.com>
// using code supplied in a previous release by Thomas Nordstrom <t_nordstrom@yahoo.com>
// I take no credit for any of this work. I simply created this file and
// recompiled the distribution zip file with the fixes to prevent parse errors.
/*
  $Id: cvs_help.php,v 1.3 2004/02/4 07:28:00 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
*/
?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=<?php echo CHARSET; ?>">
<base href="<?php echo (($request_type == 'SSL') ? HTTPS_SERVER : HTTP_SERVER) . DIR_WS_CATALOG; ?>">
<title>Card Verification Value (CVV) Help</title>
<link rel="stylesheet" type="text/css" href="stylesheet.css">
</head>
<style type="text/css"><!--
BODY { margin-bottom: 5px; margin-left: 5px; margin-right: 5px; margin-top: 5px; }
table.cvvhelp { background: #ffffff; border: 1px solid red;}
//--></style>
<body marginwidth="5" marginheight="5" topmargin="5" bottommargin="5" leftmargin="5" rightmargin="5">
<table class="cvvhelp" width="100%" border="0" cellspacing="5" cellpadding="0">
  <tr>
    <td colspan="2" class="main"><p><strong>Was ist der Karten Verifikations Code (CVV)?</strong>
      </p>
      <p>Der Karten Verifikations Code (CVV) ist eine 3-stellige nummer zu finden nahe dem Unterschriftsfeld auf der Rueckseite der Karte. Er ist ein weiteres Sicherheitsmerkmal das hilft gegen Missbrauch und Betrugicht im Magnetstreifen, so das er auch nicht �bertragen wird.</p>
      <p><strong>Wo ist der CVV?</strong></p>
      </td>
  </tr>
  <tr>
    <td class="main"><p><strong>VISA, MASTERCARD &amp; DISCOVER</strong><br>
        Der CVV ist auf der Rueckseite der Karte im Unterschriftsfeld gedruckt. <br>
      </p></td>
    <td><img src="images/cvv_help1.jpg" width="200" height="139"></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td class="main"><p><strong>AMERICAN EXPRESS</strong><br>
        Der American Express Card CVV ist eine 4-stellige nummer gedruckt auf der
        Vorderseite der Karte. Rechts oberhalb der Kartennummer.<br>
      </p></td>
    <td><img src="images/cvv_help2.jpg" width="200" height="139"></td>
  </tr>
</table>
<p class="smallText" align="right"><?php echo '<a href="javascript:window.close()">' . 'Close Window' . '</a>'; ?></p>

</body>
</html>
<?php require('includes/application_bottom.php'); ?>