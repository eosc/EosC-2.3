<?php
/*

Last Update: 08/03/2005
Original Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/
define('TABLE_HEADING_NEW_PRODUCTS', 'Neu fuer %s');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Erwartete Produkte');
define('TABLE_HEADING_DATE_EXPECTED', 'Datum Erwartet/');
define('TEXT_NO_PRODUCTS', 'Es sind keine Referenzen in dieser Kategorie.');
define('NAVBAR_TITLE_1', 'Newsletters');
define('NAVBAR_TITLE', 'Newsletters');
define('HEADING_TITLE', 'Newsletter Registration');
define('TEXT_INFORMATION', '<b>Danke das Sie sich fuer unseren Newletter eingetragen haben.</b><br>A eine Bestaetigung wird an die von Ihnen eingetragene E-mail gesandt werden');
define('TOP_BAR_TITLE', STORE_NAME . 'Newsletter');
define('TOP_BAR_SUCCESS', '<I>Danke ! Sie sind nun eingetragen</I> fuer unseren Newsletter gem. ijrer Eintragung.<BR><BR><B>Ein email wird an die eingetragene Adresse gesendet</I> um <B>Ihre Registrierung zu best�tigen</B> und zu pruefen ob die adresse korrekt ist. <BR><BR>Diese email enthaelt auch die Anweisuner Zukunft den Newletter abbestellen koennen. <BR><BR> Sie koennen die Newletter Archive als PDF finden unter der Sektion Newsletter, unter auf der Seite <BR><BR>Wenn Sie einen Artikel fuer unseren Newsletter schreiben moechten zoegern Sie nicht uns zu kontaktieren . Sie k�nnen auch <B>unser Online Formular nutzen um uns den Artikel und Bilder zu senden</B>.<BR><BR>Der Artikel und die Fotos werden mit Ihrem Namen veroeffentlicht. <BR><BR> Ihr Artikel wird auch in unserem Archiv gespeichert.');
define('TOP_BAR_EXPLAIN', STORE_NAME . ' ist bemueht Ihnen Anregungen und Tips Informationen bezzgl. Sonderaktionen und neuer Produkte zu geben. Tragen Sie Ihre Mail Adresse ein und wir nehmen Sie in unseren Verteiler auf.<BR><BR>)');
define('TOP_BAR_EXPLAIN1', ' * Note: Alle Newsletter sind in Acrobat Format. Sie koennen die Newsletter downloaden aus dem Archiv. Acrobat ist frei und kann gedownloaded werden von Adobe (http://www.adobe.com).<BR><BR>');
define('EMAIL_WELCOME_SUBJECT', 'Willkommen ' . STORE_NAME . '!');

define('EMAIL_WELCOME1', 'Willkommen bei ' . STORE_NAME . '! You will now receive on a monthly basis our newsletter.' . "\n" . '* If you would like to contribute or write an article for one of our newsletters, do not hesitate to contact us.' . "\n\n" . 'For help with any of our online services, please email our Customer Service Center : ' . HTTP_SERVER . DIR_WS_CATALOG . 'customer_service.php' . "\n\n" . 'We are happy to have you as a member of our community. Privacy is important to us; therefore, we will not sell, rent, or give away your name or address to anyone. At any point, you can select the link at the bottom of every email to unsubscribe, or to receive less or more information.' . "\n\n" . 'Thanks again for registering, and please visit ' . STORE_NAME . ' soon! If you have any questions or comments, feel free to contact us.' . '"\n\n"');

define('EMAIL_WELCOME', '*** Welcome to ' . STORE_NAME . ' Newsletter ***' . "\n\n" . 'This email confirms that your request was correctly processed and you are now registered to receive the ' . STORE_NAME . ' Newsletter' . "\n\n" . 'Note: This email address was entered during the registration process. If you did not signup to receive our ' . STORE_NAME . ' newsletter, you can go at the bottom of this email and click the unsubscribe link to automatically unsubscribe you from our newsletter.');
define('CLOSING_BLOCK1', '');
define('CLOSING_BLOCK2', '');
define('CLOSING_BLOCK3', "\n\n" . 'View our privacy policy at: ' . HTTP_SERVER . DIR_WS_CATALOG . 'privacy.php' . '.');
define('UNSUBSCRIBE', "\n\n" . 'To unsubscribe:' ."\n". HTTP_SERVER . DIR_WS_CATALOG . 'newsletters_unsubscribe.php?action=view&email=');
define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>NOTE:</b></font></small>Registering to receive our newsletter is a different process than registering when placing an order. To receive our newsletters, you only need to enter your name, email and country. (however you will not be able to place orders or track shipments until you fully register.)</font>');
define('TEXT_ORIGIN_LOGIN1', '<font color="#FF0000"><small><b>NOTE2:</b></font></small>' . STORE_NAME . ' respects very strongly your privacy. We will never resell the information entered or use it in a way which was not originally explained : read our privacy page for all details.</font>');
define('EMAIL_GREET_MR', 'Dear Mr. ');
define('EMAIL_GREET_MS', 'Dear Ms. ');
define('EMAIL_GREET_NONE', 'Dear ');

define('TEXT_EMAIL', 'E Mail');
define('TEXT_EMAIL_FORMAT', 'Format');
define('TEXT_GENDER', 'Anrede');
define('TEXT_FIRST_NAME', 'Vorname');
define('TEXT_LAST_NAME', 'Name');
define('TEXT_ZIP_INFO', 'By entering your Zip Code below (USA only), we can define....');
define('TEXT_ZIP_CODE', 'PLZ');
define('TEXT_ORIGIN_EXPLAIN_BOTTOM', '');
define('TEXT_ORIGIN_EXPLAIN_TOP', '');
define('TEXT_EMAIL_HTML', 'HTML');
define('TEXT_EMAIL_TXT', 'Text');
define('TEXT_GENDER_MR', 'Herr');
define('TEXT_GENDER_MRS', 'Frau');
?>