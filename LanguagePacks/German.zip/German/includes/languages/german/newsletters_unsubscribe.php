<?php
////////////////////////////////////////////////////////////////////////////
// $Id: Newsletter Unsubscribe, (/catalog/includes/languages/english/unsubscribe.php)v 1.0 2003/01/24
// Programed By: Christopher Bradley (www.wizardsandwars.com)
//
// Developed for osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//
// Released under the GNU General Public License
//
///////////////////////////////////////////////////////////////////////////

define('NAVBAR_TITLE', 'Abbestellen');
define('HEADING_TITLE', 'Ihr Newsletter Abo abbestellen');

define('UNSUBSCRIBE_TEXT_INFORMATION', '<br>Es tut uns leid das Sie Ihren Newsletter abbestellen wollen. Falls Sie bedenken wegen Ihrer Daten haben sehen Sie hier<a href="' .FILENAME_PRIVACY . '"><u>privacy notice</u></a>.<br><br>Abonementen des Newsletters werden �ber Neuheiten, sonderaktionen und vieles mehr informiert.<br><br>Wenn Sie Ihren Newsletter wirklich abbestellen wollen klicken Sie den Button.');
define('UNSUBSCRIBE_DONE_TEXT_INFORMATION', '<br>Ihre Email Adresse, ist aus unserem Newsletterverteiler entfernt worden so wie Sie es gewuenscht haben.<br><br>');
define('UNSUBSCRIBE_ERROR_INFORMATION', '<br>Die unten angezeigte Email Adresse ist nicht in der Newsletter Datenbank gefunden worden, vielleicht haben Sie sie schon gel�scht.<br><br>');
?>