<?php
/*
  $Id: sitemap.php,v1.0 2004/05/10 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright � 2004 osCommerce

  Released under the GNU General Public License
*/

define('NAVBAR_TITLE', 'Alle Seiten');
define('HEADING_TITLE', 'Alle Seiten');

define('PAGE_ACCOUNT', 'Mein Account');
define('PAGE_ACCOUNT_EDIT', 'Account Information');
define('PAGE_ADDRESS_BOOK', 'Adressbuch');
define('PAGE_ACCOUNT_HISTORY', 'Bestell History');
define('PAGE_ACCOUNT_NOTIFICATIONS', 'Newsletter Bestellungen');
define('PAGE_SHOPPING_CART', 'Warenkorb');
define('PAGE_CHECKOUT_SHIPPING', 'Checkout');
define('PAGE_ADVANCED_SEARCH', 'Erweiterte Suche');
define('PAGE_PRODUCTS_NEW', 'Neue Produkte');
define('PAGE_SPECIALS', 'Specials');
define('PAGE_REVIEWS', 'Bewertungen');
?>