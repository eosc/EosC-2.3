<?php
/*

  Verions 2.04 for OSC 2.2 MS2+

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002, 2003 Steve Fatula of Fatula Consulting
  compconsultant@yahoo.com

  Released under the GNU General Public License
*/

define('MODULE_SHIPPING_FEDEX1_TEXT_TITLE', 'Federal Express');
define('MODULE_SHIPPING_FEDEX1_TEXT_DESCRIPTION', 'Federal Express<br><br>You will need to have registered an account with FEDEX to use this module. Please see the README.TXT file for other requirements.');
?>
