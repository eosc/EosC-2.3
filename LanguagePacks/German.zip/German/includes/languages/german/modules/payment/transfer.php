<?php
/*
  $Id: TRANSFER.php,v 1.6 2003/01/24 21:36:04 thomasamoulton Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_TRANSFER_TEXT_TITLE', 'Bankueberweisung oder Einzahlung');
  define('MODULE_PAYMENT_TRANSFER_TEXT_DESCRIPTION', 'Bitte benutzen sie die folgenden Informationen um eine Direktuebewweisung zu taetigen.' . '<br><br>Empfaenger: '. MODULE_PAYMENT_TRANSFER_PAYTO .'<br>Kontonummer: ' . MODULE_PAYMENT_TRANSFER_ACCOUNT . '<br>Name der Bank oder Kreditinstitut: ' . MODULE_PAYMENT_TRANSFER_BANK . '<br><br>' . 'Wir versenden die Ware nach Eingang Ihrer Zahlung.');
  define('MODULE_PAYMENT_TRANSFER_TEXT_EMAIL_FOOTER', "Bitte benutzen sie die folgenden Informationen um eine Direktuebewweisung zu taetigen:". "\n\nEmpfaenger: " . MODULE_PAYMENT_TRANSFER_PAYTO . "\nKontonummer: " . MODULE_PAYMENT_TRANSFER_ACCOUNT ."\nName der Bank oder Kreditinstitut: " . MODULE_PAYMENT_TRANSFER_BANK . "\n\n" . 'Wir versenden die Ware nach Eingang Ihrer Zahlung.');
?>