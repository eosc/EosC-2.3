<?php
/*
  $Id: cc.php,v 1.10 2002/11/01 05:14:11 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_CCERR_TEXT_TITLE', 'Credit Class Error');
  define('MODULE_PAYMENT_CCERR_TEXT_DESCRIPTION', 'Credit Class Error, needed with Gift Voucher');  
  define('MODULE_PAYMENT_CCERR_TEXT_ERROR', 'Payment selection error');
?>