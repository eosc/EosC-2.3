<?php
/*
  $Id: sts_product_info.php,v 1.0 2005/11/03 23:09:49 Rigadin Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2005 osCommerce

  Released under the GNU General Public License
  * Module for STS v4 
*/

  define('MODULE_STS_POPUP_IMAGE_TITLE', 'Popup image');
  define('MODULE_STS_POPUP_IMAGE_DESCRIPTION', 'Product image popup templates');
?>