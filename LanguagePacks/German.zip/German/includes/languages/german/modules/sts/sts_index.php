<?php
/*
  $Id: sts_index.php,v 1.0 2005/11/03 23:09:49 Rigadin Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2005 osCommerce

  Released under the GNU General Public License
  * Module for STS v4
*/

  define('MODULE_STS_INDEX_TITLE', 'Index');
  define('MODULE_STS_INDEX_DESCRIPTION', 'Index template');
?>