<?php
define('BOX_INFORMATION_GV', 'Gutschein einl�sen');
define('VOUCHER_BALANCE', 'Ihr Guthaben');
define('BOX_HEADING_GIFT_VOUCHER', 'Gutscheine');
define('GV_FAQ', 'Gutscheine - Fragen und Antworten');
define('ERROR_REEDEEMED_AMOUNT', 'Ihre Gutschrift wurde akzeptiert ');
define('ERROR_NO_REDEEM_CODE', 'Sie haben leider keinen Code eingegeben.');
define('ERROR_NO_INVALID_REDEEM_GV', 'Ung�ltiger Gutscheincode');
define('TABLE_HEADING_CREDIT', 'Guthaben');
define('GV_HAS_VOUCHERA', 'Sie verf�gen �ber ein Guthaben. Sie k�nnen dieses <br>
                         per <a class="pageResults" href="');
       
define('GV_HAS_VOUCHERB', '"><b>E-Mail</b></a> versenden');
define('ENTRY_AMOUNT_CHECK_ERROR', 'Sie verf�gen nicht �ber ein entsprechendes Guthaben.');
define('BOX_SEND_TO_FRIEND', 'Gutschein versenden');

define('VOUCHER_REDEEMED', 'Gutschein verbucht');
define('CART_COUPON', 'Coupon :');
define('CART_COUPON_INFO', '...mehr Informationen');
?>
