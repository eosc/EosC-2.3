<?php

/****************************************************** 
* Email Invoice 1.1.
* The values below are required by the email invoice mod.
* Author Contact: federicorodriguez911@gmail.com
******************************************************/

/**** Email Invoice File Definitions ****/
define('FILENAME_EMAIL_INVOICE', 'email_invoice.php');
define('FILENAME_ORDERS_INVOICE', 'invoice.php');

/**** Email Directory Definitions ****/
define('DIR_FS_ADMIN', 'C:/Apache2/Apache2/htdocs/osc22ms2/catalog/admin/'); // absolute path required
define('EMAIL_INVOICE_DIR', 'email_invoice/');
define('INVOICE_TEMPLATE_DIR', 'templates/');

/*** End of Mod ***/

?>
