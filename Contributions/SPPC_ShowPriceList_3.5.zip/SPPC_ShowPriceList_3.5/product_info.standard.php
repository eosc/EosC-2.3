<?php
/*
  $Id: product_info.php,v 1.97 2003/07/01 14:34:54 hpdl Exp $
  adapted for Separate Pricing Per Customer v4 2005/03/06
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2003 osCommerce
  Released under the GNU General Public License
*/

// Commented out for if tabbed - See product_info.php 
//  require('includes/application_top.php');
//  require(DIR_WS_LANGUAGES . $language . '/' . FILENAME_PRODUCT_INFO);

  $product_check_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS . " p, " . TABLE_PRODUCTS_DESCRIPTION . " pd where p.products_status = '1' and p.products_id = '" . (int)$HTTP_GET_VARS['products_id'] . "' and pd.products_id = p.products_id and pd.language_id = '" . (int)$languages_id . "'");
  $product_check = tep_db_fetch_array($product_check_query);
  
// BOF Separate Price per Customer
     if(!tep_session_is_registered('sppc_customer_group_id')) { 
     $customer_group_id = '0';
     } else {
      $customer_group_id = $sppc_customer_group_id;
     }
// EOF Separate Price per Customer
?>
<!doctype html public "-//W3C//DTD HTML 4.01 Transitional//EN">
<html <?php echo HTML_PARAMS; ?>>
<head>
<?php
// HTC BEGIN
if ( file_exists(DIR_WS_INCLUDES . 'header_tags.php') ) {
  require(DIR_WS_INCLUDES . 'header_tags.php');
} else {
?> 
  <title><?php echo TITLE; ?></title>
<?php
}
// HTC END
?>
<base href="<?php echo (($request_type == 'SSL') ? HTTPS_SERVER : HTTP_SERVER) . DIR_WS_CATALOG; ?>">
<link rel="stylesheet" type="text/css" href="stylesheet.css">
<script language="javascript"><!--
function popupWindow(url) {
  window.open(url,'popupWindow','toolbar=no,location=no,directories=no,status=no,menubar=no,scrollbars=no,resizable=yes,copyhistory=no,width=100,height=100,screenX=150,screenY=150,top=150,left=150')
}
//--></script>
</head>
<body marginwidth="0" marginheight="0" topmargin="0" bottommargin="0" leftmargin="0" rightmargin="0">
<!-- header //-->
<?php require(DIR_WS_INCLUDES . 'header.php'); ?>
<!-- header_eof //-->
<!-- body //-->
<table border="0" width="100%" cellspacing="3" cellpadding="3"><tr>
<td width="<?php echo BOX_WIDTH; ?>" valign="top"><table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="0" cellpadding="2">
<!-- left_navigation //-->
<?php require(DIR_WS_INCLUDES . 'column_left.php'); ?>
<!-- left_navigation_eof //-->
    </table></td>
<!-- body_text //-->
    <td width="100%" valign="top">
    <?php echo tep_draw_form('cart_quantity', tep_href_link(FILENAME_PRODUCT_INFO, tep_get_all_get_params(array('action')) . 'action=add_product')); ?>
<?php
  if ($product_check['total'] < 1) {
?>
<!-- Product Not Found Table -->
<p>
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
<td><?php new infoBox(array(array('text' => TEXT_PRODUCT_NOT_FOUND))); ?></td>
</tr><td>
<table border="0" width="100%" cellspacing="0" cellpadding="2"><tr>
<td width="10"><?php echo tep_draw_separator('pixel_trans.gif', '10', '1'); ?></td>
<td align="right"><?php echo '<a href="' . tep_href_link(FILENAME_DEFAULT) . '">' . tep_image_button('button_continue.gif', IMAGE_BUTTON_CONTINUE) . '</a>'; ?></td>
<td width="10"><?php echo tep_draw_separator('pixel_trans.gif', '10', '1'); ?>
</td></tr></table>

<?php
  } else {
// BOF MaxiDVD: Modified For Ultimate Images Pack!
    $product_info_query = tep_db_query("select p.products_id, pd.products_name, pd.products_description, pd.products_spec, p.products_model, p.products_quantity, p.products_image, p.products_image_med, p.products_image_lrg, p.products_image_sm_1, p.products_image_xl_1, p.products_image_sm_2, p.products_image_xl_2, p.products_image_sm_3, p.products_image_xl_3, p.products_image_sm_4, p.products_image_xl_4, p.products_image_sm_5, p.products_image_xl_5, p.products_image_sm_6, p.products_image_xl_6, pd.products_url, p.products_price, p.products_tax_class_id, p.products_date_added, p.products_date_available, p.manufacturers_id from " . TABLE_PRODUCTS . " p, " . TABLE_PRODUCTS_DESCRIPTION . " pd where p.products_status = '1' and p.products_id = '" . (int)$HTTP_GET_VARS['products_id'] . "' and pd.products_id = p.products_id and pd.language_id = '" . (int)$languages_id . "'");
// EOF MaxiDVD: Modified For Ultimate Images Pack!
    $product_info = tep_db_fetch_array($product_info_query);

    tep_db_query("update " . TABLE_PRODUCTS_DESCRIPTION . " set products_viewed = products_viewed+1 where products_id = '" . (int)$HTTP_GET_VARS['products_id'] . "' and language_id = '" . (int)$languages_id . "'");

    if ($new_price = tep_get_products_special_price($product_info['products_id'])) {
// BOF Separate Price per Customer

        $scustomer_group_price_query = tep_db_query("select customers_group_price from " . TABLE_PRODUCTS_GROUPS . " where products_id = '" . (int)$HTTP_GET_VARS['products_id']. "' and customers_group_id =  '" . $customer_group_id . "'");
        if ($scustomer_group_price = tep_db_fetch_array($scustomer_group_price_query)) {
        $product_info['products_price']= $scustomer_group_price['customers_group_price'];
	}
// EOF Separate Price per Customer

      $products_price = '<s>' . $currencies->display_price($product_info['products_price'], tep_get_tax_rate($product_info['products_tax_class_id'])) . '</s> <span class="productSpecialPrice">' . $currencies->display_price($new_price, tep_get_tax_rate($product_info['products_tax_class_id'])) . '</span>';
    } else {
// BOF Separate Price per Customer
        $scustomer_group_price_query = tep_db_query("select customers_group_price from " . TABLE_PRODUCTS_GROUPS . " where products_id = '" . (int)$HTTP_GET_VARS['products_id']. "' and customers_group_id =  '" . $customer_group_id . "'");
        if ($scustomer_group_price = tep_db_fetch_array($scustomer_group_price_query)) {
        $product_info['products_price']= $scustomer_group_price['customers_group_price'];
	}
// EOF Separate Price per Customer

      $products_price = $currencies->display_price($product_info['products_price'], tep_get_tax_rate($product_info['products_tax_class_id']));
    }

// Uncomment below to restore model number
//    if (tep_not_null($product_info['products_model'])) {
//      $products_name = $product_info['products_name'] . '<br><span class="smallText">[' . $product_info['products_model'] . ']</span>';
//    } else {
      $products_name = $product_info['products_name'];
//    }
?>
<!-- Product Name & Price Table -->
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
            <td class="pageHeading" width="99%" valign="top"><?php echo $products_name; ?></td>
            <td class="pageHeading" width="1%" align="right" valign="top"><?php echo $products_price; ?></td>
</tr></table>
<!-- End Product Name & Price Table -->

<!-- Product Description Table -->
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
<td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
</tr><tr>
<td class="main">
<!-- Product Main Image -->
<table border="0" cellspacing="0" cellpadding="2" align="right"><tr><td align="center" class="smallText">             
<?php
// BOF MaxiDVD: Modified For Ultimate Images Pack!
// This is a kludge solution to UI 1.1's mess but needed to get the enlarge to work for small and medium images
    if (tep_not_null($product_info['products_image_med'])) {
?>
<script language="javascript"><!--
      document.write('<?php echo '<a href="javascript:popupWindow(\\\'' . tep_href_link(FILENAME_POPUP_IMAGE, 'pID=' . $product_info['products_id'] . '&image=0') . '\\\')">' . tep_image(DIR_WS_IMAGES . $product_info['products_image_med'], addslashes($product_info['products_name']), SMALL_IMAGE_WIDTH, SMALL_IMAGE_HEIGHT, 'hspace="5" vspace="5"') . '<br>' . tep_image_button('image_enlarge.gif', TEXT_CLICK_TO_ENLARGE) . '</a>'; ?>');
//--></script>
<?
    } else {
?>
<script language="javascript"><!--
      document.write('<?php echo '<a href="javascript:popupWindow(\\\'' . tep_href_link(FILENAME_POPUP_IMAGE, 'pID=' . $product_info['products_id'] . '&image=0') . '\\\')">' . tep_image(DIR_WS_IMAGES . $product_info['products_image'], addslashes($product_info['products_name']), SMALL_IMAGE_WIDTH, SMALL_IMAGE_HEIGHT, 'hspace="5" vspace="5"') . '<br>' . tep_image_button('image_enlarge.gif', TEXT_CLICK_TO_ENLARGE) . '</a>'; ?>');
//--></script>
<?php
    }
echo '</td></tr></table>';
// EOF MaxiDVD: Modified For Ultimate Images Pack!
?>
<!-- End Product Main Image -->

<?php echo nl2br(stripslashes($product_info['products_description'])); ?>
</td></tr></table>
<!-- End Product Description Table -->
<br>
<!-- Product Spec Table -->
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td class="main">                   
<?php echo nl2br(stripslashes($product_info['products_spec'])); ?>
</td></tr></table>
<!-- End Product Spec Table -->

<!-- Additional Images Table -->
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td>
<?php
// BOF MaxiDVD: Modified For Ultimate Images Pack!
 if (ULTIMATE_ADDITIONAL_IMAGES == 'enable') { include(DIR_WS_MODULES . 'additional_images.php'); }
// EOF MaxiDVD: Modified For Ultimate Images Pack!
; ?>
</td></tr></table>
<!-- End Additional Images Table -->

<!-- Product Attributes Table -->
<?php
//++++ QT Pro: End Changed Code
    $products_attributes_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_ATTRIBUTES . " patrib where patrib.products_id='" . (int)$HTTP_GET_VARS['products_id'] . "' and patrib.options_id = popt.products_options_id and popt.language_id = '" . (int)$languages_id . "'");
    $products_attributes = tep_db_fetch_array($products_attributes_query);
    if ($products_attributes['total'] > 0) {
//++++ QT Pro: Begin Changed code
      $products_id=(preg_match("/^\d{1,10}(\{\d{1,10}\}\d{1,10})*$/",$HTTP_GET_VARS['products_id']) ? $HTTP_GET_VARS['products_id'] : (int)$HTTP_GET_VARS['products_id']); 
      require(DIR_WS_CLASSES . 'pad_' . PRODINFO_ATTRIBUTE_PLUGIN . '.php');
      $class = 'pad_' . PRODINFO_ATTRIBUTE_PLUGIN;
      $pad = new $class($products_id);
      echo $pad->draw();
//++++ QT Pro: End Changed Code
    }
?>
<p>
<!-- End Product Attributes Table -->

<!-- Product Reviews Table -->
<?php
//// Begin Reviews on Product Information page hack
if (MAX_REVIEWS_IN_PRODUCT_INFO <= 0) {
//// End Reviews on Product Information page hack
    $reviews = tep_db_query("select count(*) as count from " . TABLE_REVIEWS . " where products_id = '" . $HTTP_GET_VARS['products_id'] . "'");
    $reviews_values = tep_db_fetch_array($reviews);
    if ($reviews_values['count'] > 0) {
?>
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
<td class="main"><br><?php echo TEXT_CURRENT_REVIEWS . ' ' . $reviews_values['count']; ?></td>
</tr>
<?php
    }
//// Begin Reviews on Product Information page hack
}
?>
<?php
//// Begin Reviews on Product Information page hack
if (MAX_REVIEWS_IN_PRODUCT_INFO > 0) {
?>
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr><td align="center">
<table border="0" width="90%" cellspacing="0" cellpadding="0"><tr>
<td class="main"><?php echo '<a href="' . tep_href_link(FILENAME_PRODUCT_REVIEWS_WRITE, substr(tep_get_all_get_params(), 0, -1)) . '">' . tep_image_button('button_write_review.gif', IMAGE_BUTTON_WRITE_REVIEW) . '</a>'; ?></td>
<td class="main" align="right"><?php echo tep_draw_hidden_field('products_id', $product_info['products_id']) . tep_image_submit('button_in_cart.gif', IMAGE_BUTTON_IN_CART); ?></td>
</tr></table>
</td></tr>
<?php
  $reviews_query = tep_db_query("select r.reviews_id, rd.reviews_text, r.reviews_rating, r.date_added, r.customers_name from " . TABLE_REVIEWS . " r, " . TABLE_REVIEWS_DESCRIPTION . " rd where r.products_id = '" . $HTTP_GET_VARS['products_id'] . "' and rd.reviews_id = r.reviews_id and rd.languages_id = '" . $languages_id . "' order by r.reviews_id DESC");
  $num_rows = tep_db_num_rows($reviews_query);

  if ($num_rows > 0) {
    $row = 0;
    while (($reviews_values = tep_db_fetch_array($reviews_query)) && ($row < MAX_REVIEWS_IN_PRODUCT_INFO)) {
      $row++;
      $date_added = tep_date_short($reviews_values['date_added']);
?>
<tr>
<td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
</tr><tr>
<td valign="top" class="main"><?php echo sprintf(tep_image(DIR_WS_IMAGES . 'stars_' . $reviews_values['reviews_rating'] . '.gif', sprintf(BOX_REVIEWS_TEXT_OF_5_STARS, $reviews_values['reviews_rating']))) . ' &ndash; <i>' . $reviews_values['customers_name'] . ', ' . $date_added . '</i><br>' . htmlspecialchars($reviews_values['reviews_text']) ?></td>
</tr>
<?php
    }
?>
      <tr>
        <td class="smallText"><?php echo sprintf(TEXT_DISPLAY_NUMBER_OF_REVIEWS, '1', $row, $num_rows); ?></td>
      </tr>
<?php
    if ($num_rows > MAX_REVIEWS_IN_PRODUCT_INFO) {
?>
      <tr>
        <td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
      </tr><tr>
        <td><a href="<?php echo tep_href_link(FILENAME_PRODUCT_REVIEWS, substr(tep_get_all_get_params(), 0, -1)); ?>"><?php echo tep_image_button('button_more_reviews.gif', IMAGE_BUTTON_MORE_REVIEWS); ?></a></td>
      </tr>
<?php
    }
  } else {
?>
    <tr>
      <td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '10'); ?></td>
    </tr><tr>
      <td class="smallText"><?php echo TEXT_NO_REVIEWS; ?></td>
    </tr>
<?php
  }
} else {
?>
      <tr>
        <td><br>
<table border="0" width="100%" cellspacing="0" cellpadding="0"><tr>
            <td class="main"><a href="<?php echo tep_href_link(FILENAME_PRODUCT_REVIEWS, substr(tep_get_all_get_params(), 0, -1)); ?>"><?php echo tep_image_button('button_reviews.gif', IMAGE_BUTTON_REVIEWS); ?></a></td>
            <td align="right" class="main"><input type="hidden" name="products_id" value="<?php echo $product_info_values['products_id']; ?>"><?php echo tep_image_submit('button_in_cart.gif', IMAGE_BUTTON_IN_CART); ?></td>
</tr></table>
</td></tr></table>
</td></tr></table>
<?php
} //// End Reviews on Product Information page hack
?>
<?php
    }
?>
      <tr>
        <td><?php echo tep_draw_separator('pixel_trans.gif', '100%', '5'); ?></td>
      </tr></table>
      <p>
<!-- End Product Reviews Table -->

<!-- Cross Sell & Also Purchased Table - Comment out Also Purchased here to disable -->
<?php
//added for cross -sell
   if ( (USE_CACHE == 'true') && !SID) {
    echo tep_cache_also_purchased(3600);
     include(DIR_WS_MODULES . FILENAME_XSELL_PRODUCTS);
   } else {
     include(DIR_WS_MODULES . FILENAME_XSELL_PRODUCTS);
      include(DIR_WS_MODULES . FILENAME_ALSO_PURCHASED_PRODUCTS);
    }
?>
<!-- End Cross Sell & Also Purchased Table -->

</form></td>
<!-- body_text_eof //-->
    <td width="<?php echo BOX_WIDTH; ?>" valign="top">
    <table border="0" width="<?php echo BOX_WIDTH; ?>" cellspacing="0" cellpadding="2">
<!-- right_navigation //-->
<?php require(DIR_WS_INCLUDES . 'column_right.php'); ?>
<!-- right_navigation_eof //-->
    </table></td>
  </tr>
</table>
<!-- body_eof //-->

<!-- footer //-->
<?php require(DIR_WS_INCLUDES . 'footer.php'); ?>
<!-- footer_eof //-->
<br>
</body>
</html>
<?php require(DIR_WS_INCLUDES . 'application_bottom.php'); ?>