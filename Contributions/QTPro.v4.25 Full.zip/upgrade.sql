# QT Pro V4.0 Date: 12/04/2004

# Database changes for QT Pro installation to a store that already has a
# previous version of QT Pro installed



# Change products_options column "special" to "products_options_track_stock"
# to clarify its use

ALTER TABLE products_options
  ADD products_options_track_stock tinyint(4) default '0' not null
  AFTER products_options_name;
UPDATE products_options
  SET products_options_track_stock = 1 - special;
ALTER TABLE products_options
  DROP special;


# Add new column to orders_products to track attributes to make it possible
# to remove order and restock

ALTER TABLE orders_products
  ADD products_stock_attributes varchar(255) default NULL
    AFTER products_quantity;

  
# Cleanup products_stock to remove unneccesary column in primary key

ALTER TABLE products_stock
  DROP PRIMARY KEY,
  ADD PRIMARY KEY (products_stock_id);

  
# Cleanup products_stock to make products_stock_attributes not null

ALTER TABLE products_stock
  MODIFY COLUMN products_stock_attributes varchar(255) not null;
  
  
# Cleanup products_stock to make index more useful

ALTER TABLE products_stock
  DROP INDEX idx_products_stock_attributes,
  ADD UNIQUE idx_products_stock_attributes (products_id,products_stock_attributes);
