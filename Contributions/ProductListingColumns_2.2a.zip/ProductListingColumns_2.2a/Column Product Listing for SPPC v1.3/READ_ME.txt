This is version 1.3 of Column Product Listing for Separate Pricing Per Customer v4.0 or higher


This version now supports the standard osC feature for enabling or disabling the 'buy now' button via the admin control panel.  It is modelled on the product_listing_multi_col.php from the "Add Multiple Products to Cart, in columns, for SPPC" contribution [3606].

This is a full package, containing the product_listing_col.php file, a Read_Me.txt, Install.txt with install instructions and a version tracker file Version_Tracker.txt

Requirements: osC MS2.2 with SPPC v4.0 or higher installed.


No credit taken, they all go to the original authors.

SKYLLA


-----------

This version and version 1.2 combine column listing with SPPC v4.1, just like the original version. Note that the contribution posted below on 23 Apr 2006 is a combination of "Add Multiple Products to Cart, in columns, for SPPC" contribution [3606] and the "Product Listing in Columns" (17 Apr 2006 post) contribution [112].