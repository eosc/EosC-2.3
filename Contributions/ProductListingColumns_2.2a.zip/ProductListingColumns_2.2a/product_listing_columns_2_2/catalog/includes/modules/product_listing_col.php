<?php
/*
original: $Id: product_listing.php,v 1.44 2003/06/09 22:49:43 hpdl Exp $

corrected for proper HTML 2005/07/10 JanZ
merged and updated by djmonkey1 with indispensable assistance by JanZ 2005/10/05
v2.1 developed by djmonkey1 with indispensable assistance by the Mighty JanZ  2005/10/09
reverted to  a non-SPPC state by djmonkey1
v 2.2 modified by adilovetini with small feature 2006/04/18

osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2003 osCommerce

  Released under the GNU General Public License
  
*/

//version 2.2 modification
//if number of column per row is 1, include the original product_listing.php
if (PRODUCT_LIST_NUMCOL == 1) {
	include(dirname(__FILE__).'/product_listing.php');

} else{
	//display the version 2.2 product_listing_col.php code
	
//bof product listing with attributes
$list_box_contents = array();
$list_box_contents[] = array('params' => 'class="productListing-heading"');
$cur_row = sizeof($list_box_contents) - 1;

for ($col=0, $n=sizeof($column_list); $col<$n; $col++) {
    switch ($column_list[$col]) {
		case 'PRODUCT_LIST_MULTIPLE':
			$add_multiple = "1";
			echo '<form name="buy_now_" method="post" action="' . tep_href_link(basename($PHP_SELF), tep_get_all_get_params(array('action')) . 'action=add_multiple', 'NONSSL') . '">';
			break;
	}
}
//eof product listing with attributes
?>
<?php
$listing_split = new splitPageResults($listing_sql, MAX_DISPLAY_SEARCH_RESULTS, 'p.products_id');

if ( ($listing_split->number_of_rows > 0) && ( (PREV_NEXT_BAR_LOCATION == '1') || (PREV_NEXT_BAR_LOCATION == '3') ) ) {
?>
<table border="0" width="100%" cellspacing="0" cellpadding="2">
<tr>  <td class="smallText"><?php echo $listing_split->display_count(TEXT_DISPLAY_NUMBER_OF_PRODUCTS); ?></td>
  <td class="smallText" align="right"><?php echo TEXT_RESULT_PAGE . ' ' . $listing_split->display_links(MAX_DISPLAY_PAGE_LINKS, tep_get_all_get_params(array('page', 'info', 'x', 'y'))); ?></td>
</tr>
</table>
<?php
}

$list_box_contents = array();
 
 if ($listing_split->number_of_rows > 0) {
	
	//BOF version 2.2 modification
	if (PRODUCT_LIST_NUMCOL <= 0) {
		$colnum = 3;
		$tdsize = floor(100/3);
	} else {
		$colnum = PRODUCT_LIST_NUMCOL;
		$tdsize = floor(100/PRODUCT_LIST_NUMCOL);
	}
	//EOF version 2.2 modification
	
	$row = 0;
	//$rows = 0;
	$column = 0;
	$listing_query = tep_db_query($listing_split->sql_query);
	while ($listing = tep_db_fetch_array($listing_query)) {

	// WARNING the code assumes there are three products per row. To use a different number change the number
	// at line 195: if ($column >= 3) and the code to fill up the table row below that accordingly
	
	// $counter = $row;
	// $class_for_buy_now = 'class="productListing-odd"';
	// $list_box_contents[$row] = array('params' => 'class="productListing-odd"');

		$rows++;

	    if (($rows/2) == floor($rows/2) && ($row > $counter)) {
			$list_box_contents[$row] = array('params' => 'class="productListing-even"');
			//2.2 modification ,add width in td
			$class_for_buy_now = 'class="productListing-even" width="'.$tdsize.'%"';
			$counter = $row;
	    } else {
			if ($row > $counter) {
				$list_box_contents[$row] = array('params' => 'class="productListing-odd"');
				//2.2 modification ,add width in td
				$class_for_buy_now = 'class="productListing-odd" width="'.$tdsize.'%"';
				$counter = $row;
			}
	    }

		$product_contents = array();
 
		for ($col=0, $n=sizeof($column_list); $col<$n; $col++) {
			$lc_align = '';

			switch ($column_list[$col]) {
				case 'PRODUCT_LIST_MODEL':
				$lc_align = '';
				$lc_text = '&nbsp;' . $listing['products_model'] . '&nbsp;';
				break;
				case 'PRODUCT_LIST_NAME':
				$lc_align = '';
				if (isset($HTTP_GET_VARS['manufacturers_id'])) {
					$lc_text = '<a href="' . tep_href_link(FILENAME_PRODUCT_INFO, 'manufacturers_id=' . $HTTP_GET_VARS['manufacturers_id'] . '&products_id=' . $listing['products_id']) . '">' . $listing['products_name'] . '</a>';
				} else {
					$lc_text = '&nbsp;<a href="' . tep_href_link(FILENAME_PRODUCT_INFO, ($cPath ? 'cPath=' . $cPath . '&' : '') . 'products_id=' . $listing['products_id']) . '">' . $listing['products_name'] . '</a>&nbsp;';
				}
				break;
				case 'PRODUCT_LIST_MANUFACTURER':
				$lc_align = '';
				$lc_text = '&nbsp;<a href="' . tep_href_link(FILENAME_DEFAULT, 'manufacturers_id=' . $listing['manufacturers_id']) . '">' . $listing['manufacturers_name'] . '</a>&nbsp;';
				break;
				case 'PRODUCT_LIST_PRICE':
				$lc_align = 'right';
				if (tep_not_null($listing['specials_new_products_price'])) {
					$lc_text = '&nbsp;<s>' .  $currencies->display_price($listing['products_price'], tep_get_tax_rate($listing['products_tax_class_id'])) . '</s>&nbsp;&nbsp;<span class="productSpecialPrice">' . $currencies->display_price($listing['specials_new_products_price'], tep_get_tax_rate($listing['products_tax_class_id'])) . '</span>&nbsp;';
				} else {
					$lc_text = '&nbsp;' . $currencies->display_price($listing['products_price'], tep_get_tax_rate($listing['products_tax_class_id'])) . '&nbsp;';
				}
				break;
				case 'PRODUCT_LIST_QUANTITY':
				$lc_align = 'right';
				$lc_text = '&nbsp;' . $listing['products_quantity'] . '&nbsp;';
				break;
				case 'PRODUCT_LIST_WEIGHT':
				$lc_align = 'right';
				$lc_text = '&nbsp;' . $listing['products_weight'] . '&nbsp;';
				break;
				case 'PRODUCT_LIST_IMAGE':
				$lc_align = 'center';
				if (isset($HTTP_GET_VARS['manufacturers_id'])) {
					$lc_text = '<a href="' . tep_href_link(FILENAME_PRODUCT_INFO, 'manufacturers_id=' . $HTTP_GET_VARS['manufacturers_id'] . '&products_id=' . $listing['products_id']) . '">' . tep_image(DIR_WS_IMAGES . $listing['products_image'], $listing['products_name'], SMALL_IMAGE_WIDTH, SMALL_IMAGE_HEIGHT) . '</a>';
				} else {
					$lc_text = '&nbsp;<a href="' . tep_href_link(FILENAME_PRODUCT_INFO, ($cPath ? 'cPath=' . $cPath . '&' : '') . 'products_id=' . $listing['products_id']) . '">' . tep_image(DIR_WS_IMAGES . $listing['products_image'], $listing['products_name'], SMALL_IMAGE_WIDTH, SMALL_IMAGE_HEIGHT) . '</a>&nbsp;';
				}
				break;
				//bof product listing with attributes
				case 'PRODUCT_LIST_BUY_NOW':
				$lc_align = 'center';
				$lc_text = '<a href="' . tep_href_link(basename($PHP_SELF), tep_get_all_get_params(array('action')) . 'action=buy_now&products_id=' . $listing['products_id']) . '">' . tep_image_button('button_buy_now.gif', IMAGE_BUTTON_BUY_NOW) . '</a>&nbsp;';
				break;
				// Begin Buy Now button with attributes and quantity mod 
				// Begin Add Multiple  with attributes Contrib
				case 'PRODUCT_LIST_MULTIPLE': 
				$lc_align = 'right'; 
				$lc_valign = 'top'; 
				$lc_text = (TABLE_HEADING_MULTIPLE . tep_draw_input_field('Qty_ProdId_' . $listing['products_id'], '0', 'size="4"'));
				$product_info_query = tep_db_query("select p.products_id, pd.products_name, pd.products_description, p.products_model, p.products_quantity, p.products_image, pd.products_url, p.products_price, p.products_tax_class_id, p.products_date_added, p.products_date_available, p.manufacturers_id from " . TABLE_PRODUCTS . " p, " . TABLE_PRODUCTS_DESCRIPTION . " pd where p.products_status = '1' and p.products_id = '" . $listing['products_id'] . "' and pd.products_id = p.products_id and pd.language_id = '" . $languages_id . "'");
				$product_info = tep_db_fetch_array($product_info_query);
				$products_attributes_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_ATTRIBUTES . " patrib where patrib.products_id='" . $listing['products_id'] . "' and patrib.options_id = popt.products_options_id and popt.language_id = '" . $languages_id . "'");
				$products_attributes = tep_db_fetch_array($products_attributes_query);
				if ($products_attributes['total'] > 0) {
					$lc_text .= '<table border="0" cellpadding="0" cellspacing"0">';
					$products_options_name_query = tep_db_query("select distinct popt.products_options_id, popt.products_options_name from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_ATTRIBUTES . " patrib where patrib.products_id='" . $listing['products_id'] . "' and patrib.options_id = popt.products_options_id and popt.language_id = '" . $languages_id . "'");
					while ($products_options_name = tep_db_fetch_array($products_options_name_query)) {
						$selected = 0;
						$products_options_array = array();
						$lc_text .= '<tr><td class="main">' . $products_options_name['products_options_name'] . ':</td><td>' . "\n";
						$products_options_query = tep_db_query("select pov.products_options_values_id, pov.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_ATTRIBUTES . " pa, " . TABLE_PRODUCTS_OPTIONS_VALUES . " pov where pa.products_id = '" . $listing['products_id'] . "' and pa.options_id = '" . $products_options_name['products_options_id'] . "' and pa.options_values_id = pov.products_options_values_id and pov.language_id = '" . $languages_id . "'");
						while ($products_options = tep_db_fetch_array($products_options_query)) {
							$products_options_array[] = array('id' => $products_options['products_options_values_id'], 'text' => $products_options['products_options_values_name']);
							if ($products_options['options_values_price'] != '0') {
								$products_options_array[sizeof($products_options_array)-1]['text'] .= ' (' . $products_options['price_prefix'] . $currencies->display_price($products_options['options_values_price'], tep_get_tax_rate($product_info['products_tax_class_id'])) .') ';
							}
						}
						//$lc_text .= tep_draw_pull_down_menu('id[' . $products_options_name['products_options_id'] . ']', $products_options_array, $cart->contents[$HTTP_GET_VARS['products_id']]['attributes'][$products_options_name['products_options_id']]);
						//$lc_text .= tep_draw_pull_down_menu('id_'.$listing[$x]['products_id'].'[' . $products_options_name_values['products_options_id'] . ']', $products_options_array);
						$lc_text .= tep_draw_pull_down_menu('id_'.$listing['products_id'].'[' . $products_options_name['products_options_id'] . ']', $products_options_array, $cart->contents[$HTTP_GET_VARS['products_id']]['attributes'][$products_options_name['products_options_id']]);
						//$lc_text .= tep_draw_pull_down_menu('id[' . $products_options_name['products_options_id'] . ']', $products_options_array, $cart->contents[$HTTP_GET_VARS['products_id']]['attributes'][$products_options_name['products_options_id']]); 
						$lc_text .= '</td></tr>';
					}
					$lc_text .= '</table>';
				}
				break;	
				case 'PRODUCT_LIST_BUY_NOW_MULTIPLE': 
				$lc_align = 'right'; 
				$lc_valign = 'top'; 
				$lc_text = '<form name="buy_now_' . $listing['products_id'] . '" method="post" action="' . tep_href_link(basename($PHP_SELF), tep_get_all_get_params(array('action')) . 'action=buy_now_form', 'NONSSL') . '">';
				$lc_text .= (TABLE_HEADING_MULTIPLE) . '<input type="text" name="cart_quantity" value="1" maxlength="6" size="4">'; 
				$product_info_query = tep_db_query("select p.products_id, pd.products_name, pd.products_description, p.products_model, p.products_quantity, p.products_image, pd.products_url, p.products_price, p.products_tax_class_id, p.products_date_added, p.products_date_available, p.manufacturers_id from " . TABLE_PRODUCTS . " p, " . TABLE_PRODUCTS_DESCRIPTION . " pd where p.products_status = '1' and p.products_id = '" . $listing['products_id'] . "' and pd.products_id = p.products_id and pd.language_id = '" . $languages_id . "'"); 
				$product_info = tep_db_fetch_array($product_info_query); 
				$products_attributes_query = tep_db_query("select count(*) as total from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_ATTRIBUTES . " patrib where patrib.products_id='" . $listing['products_id'] . "' and patrib.options_id = popt.products_options_id and popt.language_id = '" . $languages_id . "'"); 
				$products_attributes = tep_db_fetch_array($products_attributes_query); 
				if ($products_attributes['total'] > 0) { 
					$lc_text .= '<table border="0" cellpadding="0" cellspacing"0">'; 
					$products_options_name_query = tep_db_query("select distinct popt.products_options_id, popt.products_options_name from " . TABLE_PRODUCTS_OPTIONS . " popt, " . TABLE_PRODUCTS_ATTRIBUTES . " patrib where patrib.products_id='" . $listing['products_id'] . "' and patrib.options_id = popt.products_options_id and popt.language_id = '" . $languages_id . "'"); 
					while ($products_options_name = tep_db_fetch_array($products_options_name_query)) { 
						$selected = 0; 
						$products_options_array = array(); 
						$lc_text .= '<tr><td class="main">' . $products_options_name['products_options_name'] . ':</td><td>' . "\n"; 
						$products_options_query = tep_db_query("select pov.products_options_values_id, pov.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_ATTRIBUTES . " pa, " . TABLE_PRODUCTS_OPTIONS_VALUES . " pov where pa.products_id = '" . $listing['products_id'] . "' and pa.options_id = '" . $products_options_name['products_options_id'] . "' and pa.options_values_id = pov.products_options_values_id and pov.language_id = '" . $languages_id . "'"); 
						while ($products_options = tep_db_fetch_array($products_options_query)) { 
							$products_options_array[] = array('id' => $products_options['products_options_values_id'], 'text' => $products_options['products_options_values_name']); 
							if ($products_options['options_values_price'] != '0') { 
								$products_options_array[sizeof($products_options_array)-1]['text'] .= ' (' . $products_options['price_prefix'] . $currencies->display_price($products_options['options_values_price'], tep_get_tax_rate($product_info['products_tax_class_id'])) .') '; 
							} 
						} 
						$lc_text .= tep_draw_pull_down_menu('id[' . $products_options_name['products_options_id'] . ']', $products_options_array, $cart->contents[$HTTP_GET_VARS['products_id']]['attributes'][$products_options_name['products_options_id']]); 
						//$lc_text .= tep_draw_pull_down_menu('id_'.$listing['products_id'].'[' . $products_options_name['products_options_id'] . ']', $products_options_array, $cart->contents[$HTTP_GET_VARS['products_id']]['attributes'][$products_options_name['products_options_id']]);
						$lc_text .= '</td></tr>'; 
					} 
					$lc_text .= '</table>'; 
					$lc_text .= tep_draw_hidden_field('products_id', $product_info['products_id']) . tep_image_submit('button_buy_now.gif', TEXT_BUY . $listing['products_name'] . TEXT_NOW);
	
				}
				if ($products_attributes['total'] == 0) { 
					$lc_text .= '<br>&nbsp;';
					$lc_text .= tep_draw_hidden_field('products_id', $product_info['products_id']) . tep_image_submit('button_buy_now.gif', TEXT_BUY . $listing['products_name'] . TEXT_NOW);
					$lc_text .= '<br>&nbsp;';
					$lc_text .= '<table border="0" cellpadding="0" cellspacing"0"><tr><td class="main"></td><td></td></tr></table>';
				}
				$lc_text .= '</form>'; 
				break; 
				// End Add Multiple mod
			}
			$product_contents[] = $lc_text;
		}
		$lc_text = implode('<br>', $product_contents);
		$list_box_contents[$row][$column] = array('align' => 'center',
												//bof product listing with attributes
												'valign' => $lc_valign,
												//eof product listing with attributes
												//2.2 modification ,add width in td
                                              'params' => 'class="productListing-data" width="'.$tdsize.'%"',
                                              'text'  => $lc_text);
    
		$column ++;
    
		if ($x == ($no_of_listings -1)) {
			
			//BOF version 2.2 modification
			// fill up the remainder of the table row with empty cells, assumes three products per row!
			for($column=1; $column < $colnum; $column++) {
				$list_box_contents[$row][$column + 1] = array('align' => 'center',
												//bof product listing with attributes
												'valign' => $lc_valign,
												//eof product listing with attributes
												//2.2 modification ,add width in td
                                              'params' => 'class="productListing-data" width="'.$tdsize.'%"',
                                              'text'  => " ");
			}
			//EOF version 2.2 modification
			
			//the commented code below is the old 2.1 version
			/*
			if ($column == '1') {
				$list_box_contents[$row][$column + 1] = array('align' => 'center',
												//bof product listing with attributes
												'valign' => $lc_valign,
												//eof product listing with attributes
                                              'params' => 'class="productListing-data"',
                                              'text'  => " ");
				$column ++;
			}
			if ($column == '2') {
				$list_box_contents[$row][$column + 1] = array('align' => 'center',
												//bof product listing with attributes
												'valign' => $lc_valign,
												//eof product listing with attributes
                                              'params' => 'class="productListing-data"',
                                              'text'  => " ");
			}
			*/
		}
		
		//BOF version 2.2 modification
		//change the hardcoded value of 3 to $colnum variable
		if ($column >= $colnum || $x == ($no_of_listings -1) ) {
			$row ++; // we start a new tr here  with $list_box_contents
			$list_box_contents[$row] = array('params' => $class_for_buy_now);
			$column = 0;
		}
		//EOF version 2.2 modification
	} // end for ($x = 0; $x < $no_of_listings; $x++)

	new productListingBox($list_box_contents);

} else {
	$list_box_contents = array();

	$list_box_contents[0] = array('params' => 'class="productListing-odd"');
	$list_box_contents[0][] = array('params' => 'class="productListing-data"',
                                 'text' => TEXT_NO_PRODUCTS);

	new productListingBox($list_box_contents);
}

if ( ($listing_split->number_of_rows > 0) && ((PREV_NEXT_BAR_LOCATION == '2') || (PREV_NEXT_BAR_LOCATION == '3')) ) {
?>

<table border="0" width="100%" cellspacing="0" cellpadding="2">
<tr>
  <td class="smallText"><?php echo $listing_split->display_count(TEXT_DISPLAY_NUMBER_OF_PRODUCTS); ?></td>
  <td class="smallText" align="right"><?php echo TEXT_RESULT_PAGE . ' ' . $listing_split->display_links(MAX_DISPLAY_PAGE_LINKS, tep_get_all_get_params(array('page', 'info', 'x', 'y'))); ?></td>
</tr>
 <?php if ($add_multiple == "1"){
?>
  <tr> 
    <td align="left" class="main"><!--a href="<//?php echo tep_href_link(FILENAME_CHECKOUT_PAYMENT, 'file:///Y|/Documents/Websites/Best%20Test%20Site/catalog/includes/modules/%20', 'SSL'); ?>"><//?php echo tep_image_button('button_checkout.gif', IMAGE_BUTTON_CHECKOUT); ?></a--></td>
            <td align="right" class="main"><?php echo tep_image_submit('button_in_cart.gif', IMAGE_BUTTON_IN_CART); ?></td> 
  </tr> 
<?php } ?>
</table>
<?php
}

	
	
}
?>

