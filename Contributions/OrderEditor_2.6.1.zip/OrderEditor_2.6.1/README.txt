If you need help or have any questions or recommendations please post in the Order Editor thread on 
the oscommerce forums: http://forums.oscommerce.com/index.php?showtopic=54032  

What and what not to expect from Order Editor and how to use its many features, or lack thereof

   1. Price(base) vs. Price(excl.)
   NOTE- if you are using Order Editor v2.4 or higher on an order last edited with a pre 2.4 version
of OE, you may notice differences in Price(base) when compared to Price(excl).  This is to be expected
as previous editions of Order Editor did not edit the base price of the items in the order.
   
   Many of you may wonder what the difference is between Price(base) and Price(excl), and the answer
is products attributes prices.   Price(base), at the time the order is placed, is the catalog price,
while Price(excl) is the base price plus any premiums or discounts added in by products attributes.
For products that don't have any products attributes, there will be no difference between the two.
   
   2. Collecting Payment/Issuing Refunds
   Order Editor is not a payment module.  Collecting payment or issuing a refund 
for differences calculated against the original order is the responsibility of the shop owner.  Please
remember it's unethical and hopefully illegal to charge someone's credit card for more than they've
authorized.

   3. Shipping Tax
   If you charge tax on shipping, please remember that when you first view an order using OE the 
value of shipping tax will display as 0.00 and you will have to manually enter the correct rate prior
to updating the order.   This is, as things stand now, normal.  A stock osC install does not log the 
shipping tax rate during the checkout process, and Order Editor does not include any code that 
modifies the checkout process.   Furthermore, if your site features more than one tax class the 
shipping tax may not be added to the correct tax class.  There is a setting at about line 26 of the 
file, ($default_tax_class = 1;), where the default tax class is identified (tax on shipping is 
considered part of the default tax class total).  This should be edited if necessary to match your 
shop configuration.
   
    4.  Taxes
    Thanks to a patch supplied by Hartmut Holzgraefe and modified by djmonkey1, Order Editor as of 
v2.4 supports the use of multiple tax classes as well as multiple tax rates per class.  Taxes should 
be calculated correctly in all possible stock osC scenarios (with an emphasis on "stock"). 

    5.  Payment Method
    Order Editor v2.4 and up use a JavaScript function coupled with CSS to hide/display credit card info 
fields depending on the value of the input box for payment method.  Make sure that the value of 
ENTRY_CREDIT_CARD in the language file you use is the same as whatever gets written to your db as the 
payment method when a customer pays by cc.   This function is designed to fail gracefully on 
browsers without support for JavaScript.

    6.  Product Prices
    Order Editor v2.4 and up include a JavaScript calculator to change the values of Price (base), Price 
(excl.), Price (incl.), Total (excl.), and Total (incl.) on the fly as changes are made to any of 
those five fields, qty, tax, or any attributes prices that may be associated with the item.   This is 
a powerful tool and will allow the shop owner to do things like come up with a new total price for all
the products in a line item without having to do any independent calculations (for instance if a 
customer bought 10 items of Product X for $272.34, tax included, but you want to sell them to him for 
$250.00 total, just type "250" into the Total (incl.) box and hit "Update".  The new values will be 
calculated automatically for you to review before you submit the form).  The form should still work 
properly on browsers without support for JavaScript, although obviously no on the fly calculations 
will be performed.
   
   PLEASE NOTE:  Because the JavaScript calculator displays and rounds values to four decimal places,
it's normal to see small rounding differences once you hit "Update".  For instance, in the example
above, the value of Total (incl.) after you press "Update" may be something like 250.0010 or 249.9999.
Either of these values will appear as $250.00 on an invoice.  Final totals are based on Price (excl.) 
and should be correct for whatever is entered in that box. Only qty, tax, Price(base) as 
products_price, and Price (excl.) as final_price are written to the database; the other values 
are for display/calculations only.