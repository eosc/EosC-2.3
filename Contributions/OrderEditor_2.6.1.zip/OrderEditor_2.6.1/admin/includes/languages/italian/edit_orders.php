<?php
/*
  $Id: edit_orders.php,v 2.5 2006/04/28 10:42:44 ams Exp $
  italian
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2006 osCommerce
  
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Modifica Ordine');
define('HEADING_TITLE_NUMBER', 'Nr.');
define('HEADING_TITLE_DATE', 'of');
define('HEADING_SUBTITLE', 'Modifica tutte le sezioni come desiderato e clicca sul pulsante "Aggiorna" in basso.');
define('HEADING_TITLE_STATUS', 'Stato:');
define('ADDING_TITLE', 'Aggiungi un prodotto all\' ordine');

define('HINT_UPDATE_TO_CC', 'Set payment method to ');
//ENTRY_CREDIT_CARD should be whatever is saved in your db as the payment method
//when your customer pays by Credit Card
define('ENTRY_CREDIT_CARD', 'Credit Card');
define('HINT_UPDATE_TO_CC2', ' and the other fields will be displayed automatically.  CC fields are hidden if any other payment method is selected.');
define('HINT_PRODUCTS_PRICES', 'Price and weight calculations are done on the fly, but you must hit update in order to save any changes.  Zero and negative values may be entered for quantity. If you want to delete a product, check the delete box and hit update. Weight fields are not editable.');
define('HINT_SHIPPING_ADDRESS', 'If the shipping destination is changed this may change the tax zone the order is in as well.  You will have to press the update button again to properly calculate tax totals in this case.');
define('HINT_TOTALS', 'Feel free to give discounts by adding negative values. Any field with a value of 0 is deleted when updating the order (exception: shipping).  Weight, subtotal, tax total, and total fields are not editable. On-the-fly calculations are estimates; small rounding differences are possible after updating.');
define('HINT_PRESS_UPDATE', 'Cliccare su "Aggiorna" per salvare tutti i cambiamenti apportati.');
define('HINT_BASE_PRICE', 'Price (base) is the products price before products attributes (ie, the catalog price of the item)');
define('HINT_PRICE_EXCL', 'Price (excl) is the base price plus any product attributes prices that may exist');
define('HINT_PRICE_INCL', 'Price (incl) is Price (excl) times tax');
define('HINT_TOTAL_EXCL', 'Total (excl) is Price (excl) times qty');
define('HINT_TOTAL_INCL', 'Total (incl) is Price (excl) times tax and qty');

define('TABLE_HEADING_COMMENTS', 'Note - Commenti');
define('TABLE_HEADING_STATUS', 'Nuovo Stato');
define('TABLE_HEADING_QUANTITY', 'Qta');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Mod. Prodotto');
define('TABLE_HEADING_PRODUCTS_WEIGHT', 'Weight');
define('TABLE_HEADING_PRODUCTS', 'Prodotti');
define('TABLE_HEADING_TAX', 'Tasse');
define('TABLE_HEADING_BASE_PRICE', 'Price (base)');
define('TABLE_HEADING_UNIT_PRICE', 'Prezzo (escl.)');
define('TABLE_HEADING_UNIT_PRICE_TAXED', 'Prezzo (incl.)');
define('TABLE_HEADING_TOTAL_PRICE', 'Totale (escl.)');
define('TABLE_HEADING_TOTAL_PRICE_TAXED', 'Totale (incl.)');
define('TABLE_HEADING_TOTAL_MODULE', 'Prezzo Totale');
define('TABLE_HEADING_TOTAL_AMOUNT', 'Importo');
define('TABLE_HEADING_TOTAL_WEIGHT', 'Total Weight: ');
define('TABLE_HEADING_DELETE', 'Cancellazione? ');
define('TABLE_HEADING_SHIPPING_TAX', 'Shipping tax: ');

define('TABLE_HEADING_CUSTOMER_NOTIFIED', 'Cliente notificato');
define('TABLE_HEADING_DATE_ADDED', 'Data aggiunta');

define('ENTRY_CUSTOMER_NAME', 'Nome');
define('ENTRY_CUSTOMER_COMPANY', 'Azienda');
define('ENTRY_CUSTOMER_ADDRESS', 'Indirizzo');
define('ENTRY_CUSTOMER_SUBURB', 'Frazione');
define('ENTRY_CUSTOMER_CITY', 'Citt�');
define('ENTRY_CUSTOMER_STATE', 'Stato');
define('ENTRY_CUSTOMER_POSTCODE', 'CAP');
define('ENTRY_CUSTOMER_COUNTRY', 'Nazione');
define('ENTRY_CUSTOMER_PHONE', 'Telefono');
define('ENTRY_CUSTOMER_EMAIL', 'E-Mail');
define('ENTRY_ADDRESS', 'Address');

define('ENTRY_SHIPPING_ADDRESS', 'Indirizzo di Spedizione');
define('ENTRY_BILLING_ADDRESS', 'Indirizzo di Fatturazione');
define('ENTRY_PAYMENT_METHOD', 'Metodo di Pagamento:');
define('ENTRY_CREDIT_CARD_TYPE', 'Typo Carta:');
define('ENTRY_CREDIT_CARD_OWNER', 'Intestatario Carta:');
define('ENTRY_CREDIT_CARD_NUMBER', 'Numero Carta:');
define('ENTRY_CREDIT_CARD_EXPIRES', 'Scadenza Carta:');
define('ENTRY_SUB_TOTAL', 'Sub Totale:');
//do not put a colon (" : ") in the definition of ENTRY_TAX
//ie entry should be 'Tax' NOT 'Tax:'
define('ENTRY_TAX', 'Tasse');
define('ENTRY_TOTAL', 'Totale:');
define('ENTRY_STATUS', 'Stato Ordine:');
define('ENTRY_NOTIFY_CUSTOMER', 'Notifica Cliente:');
define('ENTRY_NOTIFY_COMMENTS', 'Invia Commenti:');

define('TEXT_NO_ORDER_HISTORY', 'No order found');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('EMAIL_TEXT_STATUS_UPDATE2', 'If you have questions, please reply to this email.' . "\n\n" . 'With warm regards from your friends at ' . STORE_NAME . "\n");
define('EMAIL_TEXT_SUBJECT', 'Il tuo ordine � stato aggiornato');
define('EMAIL_TEXT_ORDER_NUMBER', 'Numero ordine:');
define('EMAIL_TEXT_INVOICE_URL', 'Fattura dettagliata a questo URL:');
define('EMAIL_TEXT_DATE_ORDERED', 'Data ordine:');
define('EMAIL_TEXT_STATUS_UPDATE', 'Lo status del tuo ordine � cambiato.' . "\n\n" . 'Nuovo status: %s' . "\n\n" . 'Per qualsiasi informazione rispondi a questa email.' . "\n\n" . 'Cordiali saluti,' . "\n". 'Lo staff' . "\n");
define('EMAIL_TEXT_COMMENTS_UPDATE', 'Commenti' . "\n\n%s\n\n");

define('ERROR_ORDER_DOES_NOT_EXIST', 'Errore: Nessun ordine.');
define('SUCCESS_ORDER_UPDATED', 'Completato: L\' ordine � stato completato correttamente.');

define('ADDPRODUCT_TEXT_CATEGORY_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_PRODUCT', 'Scegli un prodotto');
define('ADDPRODUCT_TEXT_PRODUCT_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_OPTIONS', 'Scegli una opzione');
define('ADDPRODUCT_TEXT_OPTIONS_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_OPTIONS_NOTEXIST', 'Il prodotto non ha opzioni quindi andiamo avanti...');
define('ADDPRODUCT_TEXT_CONFIRM_QUANTITY', 'unit� di questo prodotto');
define('ADDPRODUCT_TEXT_CONFIRM_ADDNOW', 'Aggiungi');
define('ADDPRODUCT_TEXT_STEP', 'Step');
define('ADDPRODUCT_TEXT_STEP1', ' &laquo; Scegli un catalogo. ');
define('ADDPRODUCT_TEXT_STEP2', ' &laquo; Scegli un prodotto. ');
define('ADDPRODUCT_TEXT_STEP3', ' &laquo; Scegli una opzione. ');

define('MENUE_TITLE_CUSTOMER', '1. Dati Cliente');
define('MENUE_TITLE_PAYMENT', '2. Metodo di Pagamento');
define('MENUE_TITLE_ORDER', '3. Prodotti Ordinati');
define('MENUE_TITLE_TOTAL', '4. Sconti, Spedizione e Totale');
define('MENUE_TITLE_STATUS', '5. Status e Notifiche');
define('MENUE_TITLE_UPDATE', '6. Aggiorna i dati');
?>
