<?php
/*
  $Id: edit_orders.php,v 2.5 2006/04/28 10:42:44 ams Exp $
   swedish
  
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2006 osCommerce
  
  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Edit Order');
define('HEADING_TITLE_NUMBER', 'Nr.');
define('HEADING_TITLE_DATE', 'of');
define('HEADING_SUBTITLE', 'Editera din order och tryck sedan "Update" knappen nedanf�r.');
define('HEADING_TITLE_STATUS', 'Status:');
define('ADDING_TITLE', 'L�gg till en product p� denna order');

define('HINT_UPDATE_TO_CC', 'Set payment method to ');
//ENTRY_CREDIT_CARD should be whatever is saved in your db as the payment method
//when your customer pays by Credit Card
define('ENTRY_CREDIT_CARD', 'Credit Card');
define('HINT_UPDATE_TO_CC2', ' and the other fields will be displayed automatically.  CC fields are hidden if any other payment method is selected.');
define('HINT_PRODUCTS_PRICES', 'Price and weight calculations are done on the fly, but you must hit update in order to save any changes.  Zero and negative values may be entered for quantity. If you want to delete a product, check the delete box and hit update. Weight fields are not editable.');
define('HINT_SHIPPING_ADDRESS', 'If the shipping destination is changed this may change the tax zone the order is in as well.  You will have to press the update button again to properly calculate tax totals in this case.');
define('HINT_TOTALS', 'Feel free to give discounts by adding negative values. Any field with a value of 0 is deleted when updating the order (exception: shipping).  Weight, subtotal, tax total, and total fields are not editable. On-the-fly calculations are estimates; small rounding differences are possible after updating.');
define('HINT_PRESS_UPDATE', 'Klicka p� "Update" f�r att spara alla �ndringar.');
define('HINT_BASE_PRICE', 'Price (base) is the products price before products attributes (ie, the catalog price of the item)');
define('HINT_PRICE_EXCL', 'Price (excl) is the base price plus any product attributes prices that may exist');
define('HINT_PRICE_INCL', 'Price (incl) is Price (excl) times tax');
define('HINT_TOTAL_EXCL', 'Total (excl) is Price (excl) times qty');
define('HINT_TOTAL_INCL', 'Total (incl) is Price (excl) times tax and qty');

define('TABLE_HEADING_COMMENTS', 'Kommentar');
define('TABLE_HEADING_STATUS', 'Ny Status');
define('TABLE_HEADING_QUANTITY', 'Kvantitet');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Artikel nr.');
define('TABLE_HEADING_PRODUCTS_WEIGHT', 'Weight');
define('TABLE_HEADING_PRODUCTS', 'Produkter');
define('TABLE_HEADING_TAX', 'Moms');
define('TABLE_HEADING_BASE_PRICE', 'Price (base)');
define('TABLE_HEADING_UNIT_PRICE', 'Pris (excl.)');
define('TABLE_HEADING_UNIT_PRICE_TAXED', 'Pris (incl.)');
define('TABLE_HEADING_TOTAL_PRICE', 'Total (excl.)');
define('TABLE_HEADING_TOTAL_PRICE_TAXED', 'Total (incl.)');
define('TABLE_HEADING_TOTAL_MODULE', 'Total Pris Component');
define('TABLE_HEADING_TOTAL_AMOUNT', 'Tot');
define('TABLE_HEADING_TOTAL_WEIGHT', 'Total Weight: ');
define('TABLE_HEADING_DELETE', 'Radera?');
define('TABLE_HEADING_SHIPPING_TAX', 'Shipping tax: ');

define('TABLE_HEADING_CUSTOMER_NOTIFIED', 'Kund meddelad');
define('TABLE_HEADING_DATE_ADDED', 'Skriv datum');

define('ENTRY_CUSTOMER_NAME', 'Namn');
define('ENTRY_CUSTOMER_COMPANY', 'F�retag');
define('ENTRY_CUSTOMER_ADDRESS', 'Adress');
define('ENTRY_CUSTOMER_SUBURB', 'F�rort');
define('ENTRY_CUSTOMER_CITY', 'Stad');
define('ENTRY_CUSTOMER_STATE', 'State');
define('ENTRY_CUSTOMER_POSTCODE', 'Postadress');
define('ENTRY_CUSTOMER_COUNTRY', 'Land');
define('ENTRY_CUSTOMER_PHONE', 'Telefon');
define('ENTRY_CUSTOMER_EMAIL', 'E-Mail');
define('ENTRY_ADDRESS', 'Address');

define('ENTRY_SHIPPING_ADDRESS', 'Leverans Adress');
define('ENTRY_BILLING_ADDRESS', 'Faktura Adress');
define('ENTRY_PAYMENT_METHOD', 'Betalningsmetod:');
define('ENTRY_CREDIT_CARD_TYPE', 'Kort typ:');
define('ENTRY_CREDIT_CARD_OWNER', 'Kort �gare:');
define('ENTRY_CREDIT_CARD_NUMBER', 'Kort nr:');
define('ENTRY_CREDIT_CARD_EXPIRES', 'Card Expires:');
define('ENTRY_SUB_TOTAL', 'Tot:');

//do not put a colon (" : ") in the definition of ENTRY_TAX
//ie entry should be 'Tax' NOT 'Tax:'
define('ENTRY_TAX', 'Moms');

define('ENTRY_TOTAL', 'Total:');
define('ENTRY_STATUS', 'Order Status:');
define('ENTRY_NOTIFY_CUSTOMER', 'Meddela kund:');
define('ENTRY_NOTIFY_COMMENTS', 'Skicka kommentarer:');

define('TEXT_NO_ORDER_HISTORY', 'Inga order funna');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('EMAIL_TEXT_SUBJECT', 'Din order har uppdaterats');
define('EMAIL_TEXT_ORDER_NUMBER', 'Order nummer:');
define('EMAIL_TEXT_INVOICE_URL', 'Detaljerad faktura:');
define('EMAIL_TEXT_DATE_ORDERED', 'Order datum:');
define('EMAIL_TEXT_STATUS_UPDATE', 'Statusen p� din order har blitt uppdaterad.' . "\n\n" . 'New status: %s' . "\n\n" . 'If you have questions, please reply to this email.' . "\n\n" . 'Kind regards,' . "\n". 'Your Onlineshop-Team' . "\n");
define('EMAIL_TEXT_STATUS_UPDATE2', 'If you have questions, please reply to this email.' . "\n\n" . 'With warm regards from your friends at the ' . STORE_NAME . "\n");
define('EMAIL_TEXT_COMMENTS_UPDATE', 'Kommentarer' . "\n\n%s\n\n");

define('ERROR_ORDER_DOES_NOT_EXIST', 'Fel: finns ingen order med detta nummret.');
define('SUCCESS_ORDER_UPDATED', 'Klar: Ordern har blitt uppdaterad.');

define('ADDPRODUCT_TEXT_CATEGORY_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_PRODUCT', 'V�lj en produkt');
define('ADDPRODUCT_TEXT_PRODUCT_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_OPTIONS', 'V�lj ett val');
define('ADDPRODUCT_TEXT_OPTIONS_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_OPTIONS_NOTEXIST', 'Produkten har inga val..s� skippa detta...');
define('ADDPRODUCT_TEXT_CONFIRM_QUANTITY', 'pieces of this product');
define('ADDPRODUCT_TEXT_CONFIRM_ADDNOW', 'L�gg till');
define('ADDPRODUCT_TEXT_STEP', 'Step');
define('ADDPRODUCT_TEXT_STEP1', ' &laquo; V�lj en katalog. ');
define('ADDPRODUCT_TEXT_STEP2', ' &laquo; V�lj en produkt. ');
define('ADDPRODUCT_TEXT_STEP3', ' &laquo; V�lj ett val. ');

define('MENUE_TITLE_CUSTOMER', '1. Kund Data');
define('MENUE_TITLE_PAYMENT', '2. Betalningsmetod');
define('MENUE_TITLE_ORDER', '3. Best�llda produkter');
define('MENUE_TITLE_TOTAL', '4. Rabattt, Frakt och Total');
define('MENUE_TITLE_STATUS', '5. status och meddelanden');
define('MENUE_TITLE_UPDATE', '6. Updatera Data');
?>
