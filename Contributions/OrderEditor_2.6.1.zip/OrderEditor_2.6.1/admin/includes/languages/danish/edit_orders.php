<?php
/*
  $Id: edit_orders.php,v 2.5 2006/04/28 10:42:44 ams Exp $
  danish

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2006 osCommerce

  Released under the GNU General Public License

  Translation by The-Exterminator.dk
  Date: 3 June 2005
*/

define('HEADING_TITLE', '�ndre Ordre');
define('HEADING_TITLE_NUMBER', 'Nr.');
define('HEADING_TITLE_DATE', 'Fra Og Med');
define('HEADING_SUBTITLE', 'V�r Venlig At Regigere Alle Dele Som �nsket, Og Klik P� Den "Opdateret" Knap Nedenfor.');
define('HEADING_TITLE_STATUS', 'Status:');
define('ADDING_TITLE', 'Tilf�j Produkt Til Ordre');

define('HINT_UPDATE_TO_CC', 'S�t Betalings Metode Til ');
//ENTRY_CREDIT_CARD should be whatever is saved in your db as the payment method
//when your customer pays by Credit Card
define('ENTRY_CREDIT_CARD', 'Kreditkort');
define('HINT_UPDATE_TO_CC2', ' Og De Andre Felter Vil Ligge Fremme Automatisk. CC Feltet Er Skjult evt. Ander Betalings Metoder Er Valgt.');
define('HINT_PRODUCTS_PRICES', 'Pris Og V�gt Beregninger Er F�rdige On-The-Fly, Men Du M� Trykke P� Opdatere For At Gemme Hvilken Som Helst Forandring. Nul Og Negative V�rdier Kunne Blive Indtaste Efter Kvalitet. HVis Du Vil Slette Et Produkt, Tj�k Den Slettet Boks Og Tryk Opdatere. V�gt Feltet Er Ikke Redigeret.');
define('HINT_SHIPPING_ADDRESS', 'Hvis En Af Forsendelser Destination Er �ndret, Kunne Dette Forandre Skatte Omr�det Du Vil M�ske Trykke p� Ajourf�ringen Knappen Om P� Den Anden Side. Regne Moms Totaler I Dette Filf�lde.');
define('HINT_TOTALS', 'F�ler Fri Til At Give Rabatter Med Till�g Og Synlige V�rdier. HVilken Som Helst Felt Med En V�rdi Fra Om Med 0 Er Slettet N�r Opdateringen Er Slet (Indsigelse: Forsendelse). V�gt, Pris -Moms, Moms Total, Og Total Felt Er Ikke Regigeret. On-The-Fly Beregning Er Estimater, Sm� Rounding Differencer For Mulig Opdatering.');
define('HINT_PRESS_UPDATE', 'V�r Venlig At Klik P� "Opdatere" For At Gemme Forandringer.');
define('HINT_BASE_PRICE', 'Pris (base) Er Produkte V�rdi, F�r Produkt Kvalitet (ie, En Af Katalog V�rdi Fra Og Med En Af Posterne)');
define('HINT_PRICE_EXCL', 'Pris (ex) Er Den Basis V�rdi, Samt Hvilke Produkt Kvalitet Prisen Kunne Finde');
define('HINT_PRICE_INCL', 'Pris (incl) Er Prisen (ex) Gange Afgift');
define('HINT_TOTAL_EXCL', 'Total (ex) Er Prisen (ex) Gange qty');
define('HINT_TOTAL_INCL', 'Total (incl) Er Prisen (ex) Gange Afgift Og qty');

define('TABLE_HEADING_COMMENTS', 'Bem�rkninger');
define('TABLE_HEADING_STATUS', 'Status');
define('TABLE_HEADING_QUANTITY', 'Stk.');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Model');
define('TABLE_HEADING_PRODUCTS_WEIGHT', 'V�gt');
define('TABLE_HEADING_PRODUCTS', 'Produkter');
define('TABLE_HEADING_TAX', 'Moms');
define('TABLE_HEADING_BASE_PRICE', 'Pris (Base)');
define('TABLE_HEADING_UNIT_PRICE', 'Pris Per Enhed');
define('TABLE_HEADING_UNIT_PRICE_TAXED', 'Pris (Incl.)');
define('TABLE_HEADING_TOTAL_PRICE', 'Total Pris');
define('TABLE_HEADING_TOTAL_PRICE_TAXED', 'Total (Incl.)');
define('TABLE_HEADING_TOTAL_MODULE', 'Total Pris Component');
define('TABLE_HEADING_TOTAL_AMOUNT', 'Antal');
define('TABLE_HEADING_TOTAL_WEIGHT', 'Total V�gt: ');
define('TABLE_HEADING_DELETE', 'Slette?');
define('TABLE_HEADING_SHIPPING_TAX', 'Forsendelse Afgift: ');

define('TABLE_HEADING_CUSTOMER_NOTIFIED', 'Kunde Er Underrettet');
define('TABLE_HEADING_DATE_ADDED', 'Tilf�jet:');

define('ENTRY_CUSTOMER_NAME', 'Navn');
define('ENTRY_CUSTOMER_COMPANY', 'Firma');
define('ENTRY_CUSTOMER_ADDRESS', 'Adresse');
define('ENTRY_CUSTOMER_SUBURB', 'Suburb');
define('ENTRY_CUSTOMER_CITY', 'By');
define('ENTRY_CUSTOMER_STATE', 'Lands del');
define('ENTRY_CUSTOMER_POSTCODE', 'Post nr.');
define('ENTRY_CUSTOMER_COUNTRY', 'Land');
define('ENTRY_CUSTOMER_PHONE', 'Phone');
define('ENTRY_CUSTOMER_EMAIL', 'E-Mail');
define('ENTRY_ADDRESS', 'Address');

define('ENTRY_SHIPPING_ADDRESS', 'Modtager Adresse:');
define('ENTRY_BILLING_ADDRESS', 'Betalings Adresse:');
define('ENTRY_PAYMENT_METHOD', 'Betallings Metode:');
define('ENTRY_CREDIT_CARD_TYPE', 'Kreditkort Type:');
define('ENTRY_CREDIT_CARD_OWNER', 'Kreditkort Ejer:');
define('ENTRY_CREDIT_CARD_NUMBER', 'Kreditkort Nr.:');
define('ENTRY_CREDIT_CARD_EXPIRES', 'Kreditkort Udl�bsdato:');
define('ENTRY_SUB_TOTAL', 'Sub-Totalt:');

//do not put a colon (" : ") in the definition of ENTRY_TAX
//ie entry should be 'Moms' NOT 'Moms:'
define('ENTRY_TAX', 'Moms');

define('ENTRY_TOTAL', 'Totalt:');
define('ENTRY_STATUS', 'Status:');
define('ENTRY_NOTIFY_CUSTOMER', 'Underret Kunde:');
define('ENTRY_NOTIFY_COMMENTS', 'Tilf�j Bem�rkning:');

define('TEXT_NO_ORDER_HISTORY', 'Ingen Baggrund For Denne Ordre');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('EMAIL_TEXT_SUBJECT', 'Din Ordre Er Blevet Opdateret');
define('EMAIL_TEXT_ORDER_NUMBER', 'Ordre ID:');
define('EMAIL_TEXT_INVOICE_URL', 'Faktura:');
define('EMAIL_TEXT_DATE_ORDERED', 'Bestillings Dato:');
define('EMAIL_TEXT_STATUS_UPDATE', 'Din Ordre Er Blevet Opdateret Til F�lgene Status' . "\n\n" . 'Ny Status: %s' . "\n\n" . 'Besvar Endelig Denne E-Mail Hvis Du Har Nogen Sp�rgsm�l.' . "\n");
define('EMAIL_TEXT_STATUS_UPDATE2', 'Hvis Du Har Sp�rgsm�l, S� Send Endlig En E-Mail.' . "\n\n" . 'Med Venlig Hilsen ' . STORE_NAME . "\n");
define('EMAIL_TEXT_COMMENTS_UPDATE', 'Der Er F�lgene Bem�rkning Til Dig:' . "\n\n%s\n\n");

define('ERROR_ORDER_DOES_NOT_EXIST', 'Fejl: Ordre Findes Ikke.');
define('SUCCESS_ORDER_UPDATED', 'Succes: Ordren Er Blevet Opdateret');

define('ADDPRODUCT_TEXT_CATEGORY_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_PRODUCT', 'V�lg Produkt');
define('ADDPRODUCT_TEXT_PRODUCT_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_OPTIONS', 'V�lg Muligheder');
define('ADDPRODUCT_TEXT_OPTIONS_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_OPTIONS_NOTEXIST', 'Ingen Muligheder: skipped...');
define('ADDPRODUCT_TEXT_CONFIRM_QUANTITY', 'Stk.');
define('ADDPRODUCT_TEXT_CONFIRM_ADDNOW', 'Tilf�j');
define('ADDPRODUCT_TEXT_STEP', 'Step');
define('ADDPRODUCT_TEXT_STEP1', ' &laquo; V�lg Et Katalog. ');
define('ADDPRODUCT_TEXT_STEP2', ' &laquo; V�lg Et Produktt. ');
define('ADDPRODUCT_TEXT_STEP3', ' &laquo; V�lg En Mulighed. ');

define('MENUE_TITLE_CUSTOMER', '1. Kunde Data');
define('MENUE_TITLE_PAYMENT', '2. Betalings Metode');
define('MENUE_TITLE_ORDER', '3. Bestilte Produkter');
define('MENUE_TITLE_TOTAL', '4. Rabat, Forsendelse Og Total');
define('MENUE_TITLE_STATUS', '5. Status Og Meddelelse');
define('MENUE_TITLE_UPDATE', '6. Opdatere Dato');

?>
