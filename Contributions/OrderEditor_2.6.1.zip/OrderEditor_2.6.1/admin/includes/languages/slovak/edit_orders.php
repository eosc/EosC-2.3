<?php
/*
  $Id: edit_orders.php,v 2.1 2006/03/21 10:42:44 ams Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  slovak translation/ Robert Lexmann/ rc@rc.sk 03/04/2006
  Copyright (c) 2006 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', '�prava objedn�vky');
define('HEADING_TITLE_NUMBER', '��s.');
define('HEADING_TITLE_DATE', 'z');
define('HEADING_SUBTITLE', 'Upravte polo�ky pod�a potreby a stla�te "Update" .');
define('HEADING_TITLE_STATUS', 'Stav');
define('ADDING_TITLE', 'Prida� produkt do objedn�vky');

define('HINT_UPDATE_TO_CC', '<span style="color: red;">Pozn: </span>Nastav platbu na "Credit Card" , ostatn� pol��ka sa uk�u automaticky');
define('HINT_DELETE_POSITION', '<span style="color: red;">Pozn: </span>Pri �prave produktu s vlastnos�ami je nutn� nov� cenu po��ta� manu�lne.');
define('HINT_TOTALS', '<span style="color: red;">Pozn: </span>Pol��ka s hodnotou "0" bud� zmazan� pri odoslan� (v�nimka: doprava).');
define('HINT_PRESS_UPDATE', 'Pre ulo�enie zmien stla�te "Update".');

define('TABLE_HEADING_COMMENTS', 'Koment�r');
define('TABLE_HEADING_STATUS', 'Nov� stav');
define('TABLE_HEADING_QUANTITY', 'Po�et');
define('TABLE_HEADING_PRODUCTS_MODEL', 'Kat.�.');
define('TABLE_HEADING_PRODUCTS', 'N�zov');
define('TABLE_HEADING_TAX', 'DPH %');
define('TABLE_HEADING_UNIT_PRICE', 'Cena (bez)');
define('TABLE_HEADING_UNIT_PRICE_TAXED', 'Cena (s)');
define('TABLE_HEADING_TOTAL_PRICE', 'Celkom (bez)');
define('TABLE_HEADING_TOTAL_PRICE_TAXED', 'Celkom (s)');
define('TABLE_HEADING_TOTAL_MODULE', 'Komponent');
define('TABLE_HEADING_TOTAL_AMOUNT', 'Suma');
define('TABLE_HEADING_DELETE', 'Zmaza� ?');
define('TABLE_HEADING_SHIPPING_TAX', 'DPH dopravy: ');

define('TABLE_HEADING_CUSTOMER_NOTIFIED', 'Z�kazn�k upovedomen�');
define('TABLE_HEADING_DATE_ADDED', 'D�tum z�znamu');

define('ENTRY_CREDIT_CARD', 'Credit Card');
define('ENTRY_CUSTOMER_NAME', 'Meno');
define('ENTRY_CUSTOMER_COMPANY', 'Firma');
define('ENTRY_CUSTOMER_ADDRESS', 'Adresa z�kazn�ka');
define('ENTRY_CUSTOMER_SUBURB', 'Adresa');
define('ENTRY_CUSTOMER_CITY', 'Mesto');
define('ENTRY_CUSTOMER_STATE', '�t�t');
define('ENTRY_CUSTOMER_POSTCODE', 'PS�');
define('ENTRY_CUSTOMER_COUNTRY', 'Krajina');
define('ENTRY_CUSTOMER_PHONE', 'Telef�n');
define('ENTRY_CUSTOMER_EMAIL', 'E-Mail');
define('ENTRY_ADDRESS', 'Adresa');

define('ENTRY_SHIPPING_ADDRESS', 'Adresa na zaslanie');
define('ENTRY_BILLING_ADDRESS', 'Adresa platite�a');
define('ENTRY_PAYMENT_METHOD', 'Druh platby:');
define('ENTRY_CREDIT_CARD_TYPE', 'Typ karty:');
define('ENTRY_CREDIT_CARD_OWNER', 'Majite� karty:');
define('ENTRY_CREDIT_CARD_NUMBER', '��slo karty:');
define('ENTRY_CREDIT_CARD_EXPIRES', 'Exp. karty:');
define('ENTRY_SUB_TOTAL', 'Medzis��et:');
define('ENTRY_TAX', 'DPH:');
define('ENTRY_TOTAL', 'Celkom:');
define('ENTRY_STATUS', 'Stav objedn�vky:');
define('ENTRY_NOTIFY_CUSTOMER', 'Upovedomi� z�kazn�ka:');
define('ENTRY_NOTIFY_COMMENTS', 'Posla� koment�r:');

define('TEXT_NO_ORDER_HISTORY', '�iadne objedn�vky');

define('EMAIL_SEPARATOR', '------------------------------------------------------');
define('EMAIL_TEXT_SUBJECT', 'Va�a OBJEDN�VKA bola aktualizovan�');
define('EMAIL_TEXT_ORDER_NUMBER', '��slo objedn�vky:');
define('EMAIL_TEXT_INVOICE_URL', 'URL detailnej fakt�ry:');
define('EMAIL_TEXT_DATE_ORDERED', 'D�tum objedn�vky:');
define('EMAIL_TEXT_STATUS_UPDATE', '�akujeme za Va�u objedn�vku n�s!' . "\n\n" . 'Stav Va�ej objedn�vky bol aktualizovan�.' . "\n\n" . 'Nov� stav: %s' . "\n\n");
define('EMAIL_TEXT_STATUS_UPDATE2', 'V pr�pade ot�zok odpovedzte na tento email.' . "\n\n" . 'S pozdravom Va�i priatelia z ' . STORE_NAME . "\n");
define('EMAIL_TEXT_COMMENTS_UPDATE', 'Tu je koment�r ku Va�ej objedn�vke:' . "\n\n%s\n\n");

define('ERROR_ORDER_DOES_NOT_EXIST', 'Chyba: �iadne objedn�vky.');
define('SUCCESS_ORDER_UPDATED', 'Objedn�vka bola �spe�ne aktualizovan�!');

define('ADDPRODUCT_TEXT_CATEGORY_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_PRODUCT', 'Zvoli� produkt');
define('ADDPRODUCT_TEXT_PRODUCT_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_SELECT_OPTIONS', 'Zvoli� alternat�vu');
define('ADDPRODUCT_TEXT_OPTIONS_CONFIRM', 'OK');
define('ADDPRODUCT_TEXT_OPTIONS_NOTEXIST', 'Produkt nem� alternat�vu, tak�e ideme �alej...');
define('ADDPRODUCT_TEXT_CONFIRM_QUANTITY', 'kusov produktu');
define('ADDPRODUCT_TEXT_CONFIRM_ADDNOW', 'Prida�');
define('ADDPRODUCT_TEXT_STEP', 'Krok');
define('ADDPRODUCT_TEXT_STEP1', ' &laquo; Zvoli� katal�g. ');
define('ADDPRODUCT_TEXT_STEP2', ' &laquo; Zvoli� produkt. ');
define('ADDPRODUCT_TEXT_STEP3', ' &laquo; Zvoli� alternat�vu. ');

define('MENUE_TITLE_CUSTOMER', '1. �daje o z�kazn�kovi');
define('MENUE_TITLE_PAYMENT', '2. Platobn� podmienky');
define('MENUE_TITLE_ORDER', '3. Objednan� produkty');
define('MENUE_TITLE_TOTAL', '4. Z�avy, Doprava a Celkov� suma');
define('MENUE_TITLE_STATUS', '5. Stav a Upovedomenie');
define('MENUE_TITLE_UPDATE', '6. Aktualizova� �daje');
?>