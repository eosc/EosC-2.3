Reviews on Products Info Pages v.1.0 (based on the 9/1 snapshot of osCommerce)
(Back up your files.. blah, blah, blah.. no guarantees, etc.)

This mod will show reviews for a product on its description page. Set the number of reviews you'd like shown by changing the number in the admin>Configuration>Maximum Values (look towards the bottom). A setting of 0 will disable this mod completely (default setting is 3).

Reviews will be shown newest first from the given product and current language. Additionally there is an added "Write Review" button, and a "More Reviews" button that will disappear when not needed.

(Note: only english language is provided, feel free to translate :) )

*This addition is covered under the same GPL as osCommerce. If you don't know what that means then look it up.*
_____________________________________________________________________________
***NOTE: I highly recommend inserting the code manually. If nothing else it is at least good practice.***
Summary of changes: 

bunch of stuff in catalog/product_info.php (you can just replace your old file with the one included)

add file catalog/includes/languages/english/images/buttons/button_more_reviews.gif

add to catalog/includes/languages/english.php (or replace your current file with the one included):

// Begin Reviews on Product Info Page Mod
define('IMAGE_BUTTON_MORE_REVIEWS', 'More Reviews');
// End Reviews on Product Info Page Mod

Run the following query using phpMyAdmin (or whatever you're comfortable with) on your osCommerce database:

INSERT INTO configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, date_added) VALUES ('Number of Reviews in Product Description', 'MAX_REVIEWS_IN_PRODUCT_INFO', '3', 'Number of reviews to display on product information page (set to 0 to disable)', '3', '19', now());