<?php
/*
  $Id: ot_gv.php,v 1.2.2.4 2003/05/14 22:52:59 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

 // #################### Begin Added CGV JONYO ######################

 define('MODULE_ORDER_TOTAL_GV_TITLE', 'Gift Vouchers (-) ');
 define('MODULE_ORDER_TOTAL_GV_HEADER', 'Enter code below if you have any gift certificates or coupons you have not redeemed yet.');
 define('MODULE_ORDER_TOTAL_GV_DESCRIPTION', 'Gift Vouchers');
 define('SHIPPING_NOT_INCLUDED', ' [Shipping not included]');
 define('TAX_NOT_INCLUDED', ' [Tax not included]');
 define('MODULE_ORDER_TOTAL_GV_USER_PROMPT', ' <b>to be used from Gift Vouchers</td><td align=right>');
 define('TEXT_ENTER_GV_CODE', 'Enter Redeem Code  ');

 // #################### End Added CGV JONYO ######################

 /*
  define('MODULE_ORDER_TOTAL_GV_TITLE', 'Gift Vouchers');
  define('MODULE_ORDER_TOTAL_GV_HEADER', 'Gift Vouchers/Discount Coupons');
  define('MODULE_ORDER_TOTAL_GV_DESCRIPTION', 'Gift Vouchers');
  define('SHIPPING_NOT_INCLUDED', ' [Shipping not included]');
  define('TAX_NOT_INCLUDED', ' [Tax not included]');
  define('MODULE_ORDER_TOTAL_GV_USER_PROMPT', 'Tick to use Gift Voucher account balance -> ');
  define('TEXT_ENTER_GV_CODE', 'Enter Redeem Code  ');
  */
// Added by Rigadin in v5.13 to show module errors on checkout_payment page
  define('MODULE_ORDER_TOTAL_GV_TEXT_ERROR', 'Gift Voucher/Discount coupon');

?>