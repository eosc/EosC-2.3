<?php
/*
  $Id: popup_coupon_help.php,v 1.1.2.2 2003/05/15 23:04:32 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_COUPON_HELP', 'Gutschein Information');
define('TEXT_CLOSE_WINDOW', 'Fenster schliessen [x]');
define('TEXT_COUPON_HELP_HEADER', 'Ihr Gutschein wurde erfolgreich verbucht.');
define('TEXT_COUPON_HELP_NAME', '<br><br>Gutscheinbezeichnung : %s');
define('TEXT_COUPON_HELP_FIXED', '<br><br>Der Gutscheinwert betr�gt %s ');
define('TEXT_COUPON_HELP_MINORDER', '<br><br>Der Mindestbestellwert betr�gt %s ');
define('TEXT_COUPON_HELP_FREESHIP', '<br><br>Gutschein f�r kostenlosen Versand');
define('TEXT_COUPON_HELP_DESC', '<br><br>Couponbeschreibung : %s');
define('TEXT_COUPON_HELP_DATE', '<br><br>Dieser Coupon ist g�ltig vom %s bis %s');
define('TEXT_COUPON_HELP_RESTRICT', '<br><br>Produkte / Kategorien');
define('TEXT_COUPON_HELP_CATEGORIES', 'Kategorie');
define('TEXT_COUPON_HELP_PRODUCTS', 'Produkt');
?>
