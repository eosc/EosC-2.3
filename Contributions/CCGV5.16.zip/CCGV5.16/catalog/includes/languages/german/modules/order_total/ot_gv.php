<?php
/*
  $Id: ot_gv.php,v 1.1.2.1 2003/05/15 23:05:02 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_GV_TITLE', 'Gutscheine');
  define('MODULE_ORDER_TOTAL_GV_HEADER', 'Gutscheine / Gutschriften');
  define('MODULE_ORDER_TOTAL_GV_DESCRIPTION', 'Gutscheine');
  define('SHIPPING_NOT_INCLUDED', ' [Versand nicht enthalten]');
  define('TAX_NOT_INCLUDED', ' [MwSt. nicht enthalten]');
  define('MODULE_ORDER_TOTAL_GV_USER_PROMPT', 'Bitte hier klicken um das Guthaben zu verrechnen ->&nbsp;');
  define('TEXT_ENTER_GV_CODE', 'Geben Sie bitte hier Ihren Gutscheincode ein &nbsp;&nbsp;');
?>
