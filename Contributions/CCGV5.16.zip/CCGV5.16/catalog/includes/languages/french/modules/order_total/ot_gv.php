<?php
/*
  $Id: ot_gv.php,v 1.2.2.4 2003/05/14 22:52:59 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_GV_TITLE', 'Ch&egrave;que cadeau');
  define('MODULE_ORDER_TOTAL_GV_HEADER', 'Ch&egrave;que cadeau/Coupons de r&eacute;duction');
  define('MODULE_ORDER_TOTAL_GV_DESCRIPTION', 'Ch&egrave;que cadeau');
  define('SHIPPING_NOT_INCLUDED', ' [Livraison non incluse]');
  define('TAX_NOT_INCLUDED', ' [Taxe non incluse]');
  define('MODULE_ORDER_TOTAL_GV_USER_PROMPT', 'Cochez pour utiliser votre solde disponnible en ch&egrave;que cadeau ->&nbsp;');
  define('TEXT_ENTER_GV_CODE', 'Entrez le code &agrave; utiliser&nbsp;&nbsp;');
// Added by Rigadin in v5.13 to show module errors on checkout_payment page
  define('MODULE_ORDER_TOTAL_GV_TEXT_ERROR', 'Coupon de r�duction / Ch�ques Cadeaux');
?>