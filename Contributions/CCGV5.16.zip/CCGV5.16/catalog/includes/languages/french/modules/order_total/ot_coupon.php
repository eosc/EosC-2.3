<?php
/*
  $Id: ot_coupon.php,v 1.1.2.5 2003/05/14 22:52:59 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_ORDER_TOTAL_COUPON_TITLE', 'Coupons de r�duction');
  define('MODULE_ORDER_TOTAL_COUPON_HEADER', 'Coupons de r&eacute;duction/Remise ch&egrave;que cadeau');
  define('MODULE_ORDER_TOTAL_COUPON_DESCRIPTION', 'Coupons de r&eacute;duction');
  define('SHIPPING_NOT_INCLUDED', ' [Livraison non incluse]');
  define('TAX_NOT_INCLUDED', ' [Taxe non incluse]');
  define('MODULE_ORDER_TOTAL_COUPON_USER_PROMPT', '');
  define('ERROR_NO_INVALID_REDEEM_COUPON', 'Code du coupon invalide');
  define('ERROR_INVALID_STARTDATE_COUPON', 'Ce coupon n\'est plus valable');
  define('ERROR_INVALID_FINISDATE_COUPON', 'Ce coupon a expir&eacute;');
  define('ERROR_INVALID_USES_COUPON', 'Ce coupon peut seulement &ecirc;tre utilis&eacute; ');  
  define('TIMES', ' temps.');
  define('ERROR_INVALID_USES_USER_COUPON', 'Vous avez utilis&eacute; le maximum de coupon autoris&eacute; par client.'); 
  define('REDEEMED_COUPON', 'valeur du coupon ');  
  define('REDEEMED_MIN_ORDER', 'sur la commande ');  
  define('REDEEMED_RESTRICTIONS', ' [Les restrictions s\'appliquent sue les produits et cat&eacute;gorie]');  
  define('TEXT_ENTER_COUPON_CODE', 'Entrez le code &agrave; utiliser&nbsp;&nbsp;');
  define('MODULE_ORDER_TOTAL_COUPON_TEXT_ERROR', 'Redeemed Coupon');
?>
