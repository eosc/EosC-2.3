<?php
/*
  $Id: cc.php,v 1.10 2002/11/01 05:14:11 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

  define('MODULE_PAYMENT_CCERR_TEXT_TITLE', 'Erreur Cr�dit class');
  define('MODULE_PAYMENT_CCERR_TEXT_DESCRIPTION', 'Erreur Cr�dit class, � utiliser avec Coupons cadeaux');  
  define('MODULE_PAYMENT_CCERR_TEXT_ERROR', 'Erreur de s�lection de paiement');
?>