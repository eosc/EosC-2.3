<?php
/*
  $Id: gv_sent.php,v 1.2 2003/02/18 00:15:52 wilt Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 - 2003 osCommerce

  Gift Voucher System v1.0
  Copyright (c) 2001,2002 Ian C Wilson
  http://www.phesis.org

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Ch&egrave;ques cadeaux envoy&eacute;s');

define('TABLE_HEADING_SENDERS_NAME', 'Nom de l\'exp�diteur');
define('TABLE_HEADING_VOUCHER_VALUE', 'Valeur du bon');
define('TABLE_HEADING_VOUCHER_CODE', 'Code du bon');
define('TABLE_HEADING_DATE_SENT', 'Date de l\'envoi');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_INFO_SENDERS_ID', 'Identifiant de l\'exp&eacute;diteur :');
define('TEXT_INFO_AMOUNT_SENT', 'Montant envoy&eacute; :');
define('TEXT_INFO_DATE_SENT', 'Date de l\'envoi :');
define('TEXT_INFO_VOUCHER_CODE', 'Code du ch&egrave;que :');
define('TEXT_INFO_EMAIL_ADDRESS', 'Adresse email :');
define('TEXT_INFO_DATE_REDEEMED', 'Date de validation :');
define('TEXT_INFO_IP_ADDRESS', 'Adresse IP :');
define('TEXT_INFO_CUSTOMERS_ID', 'Identifiant du client :');
define('TEXT_INFO_NOT_REDEEMED', '<b><font color="red">Non valid&eacute;</font></b>');
?>