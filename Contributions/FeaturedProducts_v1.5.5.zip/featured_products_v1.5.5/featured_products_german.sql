create table featured (
  featured_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  featured_date_added datetime ,
  featured_last_modified datetime ,
  expires_date datetime ,
  date_status_change datetime ,
  status int(1) default '1' ,
  PRIMARY KEY (featured_id)
);

INSERT INTO configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('33','Top-Artikel', 'Angezeigte Top-Artikel', '33', '1'
);

INSERT into configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added) values ('Anzeige Top-Artikel', 'FEATURED_PRODUCTS_DISPLAY', 'true', 'Um den Artikel anzuzeigen setzen Sie 1=ja oder 0=nein', '33', '1', now(), now()
);

INSERT into configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added) values ('Maxiale Anzeige an Top-Artikeln', 'MAX_DISPLAY_FEATURED_PRODUCTS', '6', 'Das ist die maximal sichtbare Anzahl der Top-Artikel.', '33', '2', now(), now()
);