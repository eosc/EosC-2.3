Featured Products v1.5.4
Appended by Monti (http://botiga.rugbycatala.org): 18 Jan 2005
Catalan translation added to this contribution. This package contain the complete contribution plus catalan translated files and sql file in catalan for catalan administration. 

Featured Products v1.5.3
Appended by JoSch: 25 Jul 2004
German translation added to this contribution. This package contain the complete contribution plus German translated files and sql file in German for German administration. 

Featured Products v1.5.2
Appended by Graith (http://www.graith.co.uk): 5 April 2004
Added back the featured_products.php page linked from the module and corrected a minor bug which resulted in a divide by zero

Featured Products v1.5.1
Appended by Raffles: 02 February 2004
Spanish translation added to this contribution. This package contain the complete contribution plus spanish translated files and sql file in spanish for spanish administration.

Featured Products v1.5
Appended by Jesse Labrocca Date: 20 January 2004
The reason I updated these instructions and files is because there are a few extra files that are no longer needed for this contrib.  I also streamlined the admin so that you can turn on or off the featured display inside the admin as well as change  how many products you would like to display.  My version is about as simple as you can get to install. Enjoy.


Featured Products V1.4 by Jono Behr
For osCommerce V2.2 MS2
Date:16 January 2004
------------------------------------

Featured Products InfoBox V1.3 by Aubrey Killian was orignally writen for an earlier version of osCommerce, and doesnt quite work in the current version of osCommerce. Whilst there are bits of pieces of information all over the forums and the contribution section to help users install V1.3 and get it up to date and working properly, this updated version simply takes the awesome work by Aubrey (c'mon the bokke!) and the knowledge and help from others to make one all-inclusive contribution and things a bit easier. This contribution (V1.4) includes all the files and instructions that I used in my own installation to get things up and running in V2.2 MS2. I take no credit for the original work or mods, and also dont take any responsibility if this doesnt work!


---
WHAT IS IT?
---
The purpose of this contribution is to replace the "New Products" Infobox that appears on the main page and top-level category pages, to show selected products in the infobox, instead of new products. The featured products can be chosen in the admin.

On the main default page of oscommerce, a selection of ALL the featured products will be display, and in top-level categories, only featured products that belongs to that category. For example, "A Bug's Life" is a DVD movie in the sub-category "Cartoons", and "Cartoons" is a sub-category of "DVD Movies". If "A Bug's Life" is made a featured product, it will appear on the main oscommerce page, and also on the DVD Movies category page, but not on the Hardware page. If there are more featured products than the maximum allowed to be displayed, a random selection will be shown.

It's been written in such a way that the Infobox will *not* show up if there are no featured products to display.


---
HOW TO INSTALL
---

Installation should take about 15 to 20 minutes, there are some copying of files, and then some editing of current files is
necessary. There are a number of files to be edited, but don't be put off but this, it's mostly inserting one or two lines
into the file. Nothing majorly complicated.

Step 1:
As always, first BACKUP FILES AND DATABASE!!!

Step 2:
Copy the directory structure that came with this archive, as it is into your /catalog and /admin direcories.


Step 3:
Add the following lines to /catalog/admin/includes/filenames.php

define('FILENAME_FEATURED', 'featured.php');
define('FILENAME_FEATURED_PRODUCTS', 'featured_products.php');

Step 4:
Add the following line to /catalog/admin/includes/database_tables.php
define('TABLE_FEATURED', 'featured');

Step 5:
Add the following line to /catalog/admin/includes/boxes/catalog.php, right before the line that contains <a href="'. tep_href_link(FILENAME_PRODUCTS_EXPECTED, '', 'NONSSL') . '" class="menuBoxContentLink">' . BOX_CATALOG_PRODUCTS_EXPECTED . '</a>');

'<a href="' . tep_href_link(FILENAME_FEATURED, '', 'NONSSL') . '" class="menuBoxContentLink">' . BOX_CATALOG_FEATURED_PRODUCTS . '</a><br>' .

Step 6:
Add the following line to /catalog/admin/includes/languages/english.php, right before the line that contains define('BOX_CATALOG_PRODUCTS_EXPECTED', 'Products Expected');

define('BOX_CATALOG_FEATURED_PRODUCTS', 'Featured Products');

:::::::::SPANISH TRANSLATION:::::::::
Add the following line to /catalog/admin/includes/languages/espanol.php, right before the line that contains define('BOX_CATALOG_PRODUCTS_EXPECTED', 'Pr�ximamente');

define('BOX_CATALOG_FEATURED_PRODUCTS', 'Productos destacados');
:::::::::::::::::::::::::::::::::::::

:::::::::GERMAN TRANSLATION:::::::::
Add the following line to /catalog/admin/includes/languages/german.php, right before the line that contains define('BOX_CATALOG_PRODUCTS_EXPECTED', 'erwartete Artikel');

define('BOX_CATALOG_FEATURED_PRODUCTS', 'Highlights');
:::::::::::::::::::::::::::::::::::::

:::::::::CATALAN TRANSLATION:::::::::
Add the following line to /catalog/admin/includes/languages/catalan.php, right before the line that contains define('BOX_CATALOG_PRODUCTS_EXPECTED', 'Properament');

define('BOX_CATALOG_FEATURED_PRODUCTS', 'Productes destacats');
:::::::::::::::::::::::::::::::::::::

:::::::::FRENCH TRANSLATION:::::::::
Add the following line to /catalog/admin/includes/languages/french.php, right before the line that contains define('BOX_CATALOG_PRODUCTS_EXPECTED', 'Produits &agrave; venir');

define('BOX_CATALOG_FEATURED_PRODUCTS', 'Prod. recommand&eacute;s');
:::::::::::::::::::::::::::::::::::::

Step 7:
Add the following lines to /catalog/includes/filenames.php

define('FILENAME_FEATURED', 'featured.php');
define('FILENAME_FEATURED_PRODUCTS', 'featured_products.php');


Step 8:
Add the following lines to /catalog/includes/database_tables.php

define('TABLE_FEATURED', 'featured');


Step 9:
In /catalog/includes/application_top.php, insert the following lines right after the line that contains "tep_expire_specials();"

// auto expire featured products
require(DIR_WS_FUNCTIONS . 'featured.php');
tep_expire_featured();


Step 10:
In /catalog/includes/languages/english/index.php, add the following lines right after the line "define('TABLE_HEADING_DATE_EXPECTED', 'Date Expected');"

define('TABLE_HEADING_FEATURED_PRODUCTS', 'Featured Products');
define('TABLE_HEADING_FEATURED_PRODUCTS_CATEGORY', 'Featured Products in %s');

:::::::::SPANISH TRANSLATION:::::::::
In /catalog/includes/languages/espanol/index.php, add the following lines right after the line "define('TABLE_HEADING_DATE_EXPECTED', 'Lanzamiento');"

define('TABLE_HEADING_FEATURED_PRODUCTS', 'Productos Destacados');
define('TABLE_HEADING_FEATURED_PRODUCTS_CATEGORY', 'Productos Destacados en %s');
:::::::::::::::::::::::::::::::::::::

:::::::::DEUTSCHE �BERSETZUNG::::::::
In /catalog/includes/languages/german/index.php, direkt hinter der Zeile define('TABLE_HEADING_DATE_EXPECTED', 'Datum');  einf�gen.

// Add on for Featured Products
define('TABLE_HEADING_FEATURED_PRODUCTS', 'Neue Produkte und Highlight`s');
define('TABLE_HEADING_FEATURED_PRODUCTS_CATEGORY', 'Neue Produkte und Hightlight`s in %s');
:::::::::::::::::::::::::::::::::::::

:::::::::CATALAN TRANSLATION:::::::::
In /catalog/includes/languages/catalan/index.php, add the following lines right after the line "define('TABLE_HEADING_DATE_EXPECTED', 'Llan�ament');"

define('TABLE_HEADING_FEATURED_PRODUCTS', 'Productes Destacats');
define('TABLE_HEADING_FEATURED_PRODUCTS_CATEGORY', 'Productes Destacats en %s');
:::::::::::::::::::::::::::::::::::::

:::::::::FRENCH TRANSLATION:::::::::
In /catalog/includes/languages/french/index.php, add the following lines right after the line define('TABLE_HEADING_DATE_EXPECTED', 'Date pr&eacute;vue');

define('TABLE_HEADING_FEATURED_PRODUCTS', 'Produits recommand�s');
define('TABLE_HEADING_FEATURED_PRODUCTS_CATEGORY', 'Produits recommand�s dans %s');
:::::::::::::::::::::::::::::::::::::

Step 11:
edit /catalog/index.php and change the two instances of FILENAME_NEW_PRODUCTS to FILENAME_FEATURED

Step 12:
Now you need to create the database table that will be holding the featured products. You need to run the featured_products_english.sql file's contents in your favourite sql interface (like phpmyadmin) to your database .

:::::::::SPANISH TRANSLATION:::::::::
You've got an alternative spanish version of the sql file called featured_products_espanol.sql
:::::::::::::::::::::::::::::::::::::

:::::::::GERMAN TRANSLATION:::::::::
You've got an alternative german version of the sql file called featured_products_german.sql
::::::::::::::::::::::::::::::::::::

:::::::::CATALAN TRANSLATION:::::::::
You've got an alternative catalan version of the sql file called featured_products_catalan.sql
:::::::::::::::::::::::::::::::::::::

:::::::::FRENCH TRANSLATION:::::::::
You've got an alternative french version of the sql file called featured_products_french.sql
:::::::::::::::::::::::::::::::::::::


Step 13:
go to your admin panel and add the products that you want featured.


--
HOW TO UNINSTALL
---

* To disable this contribution, all you would need to do is set the value of
FEATURED_PRODUCTS_DISPLAY in /catalog/includes/configure.php to false.
This module will automatically display the "New Products for <month>"
infobox if featured products is disabled in the configure.php


* Totally removing the Featured Products Infobox means removing each of
the lines that were added during the INSTALLATION part of this
documentation, and then remove the files that were added.


---
HOW TO GET IT GOING
---

All you need to do is to add products into the featured products list from
the Admin section, by going to your admin section's "catalog" box, and then
clicking on "Featured Products". The Featured Products section works
exactly like the Specials section, except you don't choose a price. You can
choose an expiry date for the Featured Product if you so choose. There is a
status on/off button too. Any expired Featured Products will automatically
get changed to Off status when their expiry date is reached.

That's it. I hope some of you find this useful, and if you do, let me know.
Feedback, comments, constructive critisism is always welcome.
If I'm missing something in the archive, please let me know.