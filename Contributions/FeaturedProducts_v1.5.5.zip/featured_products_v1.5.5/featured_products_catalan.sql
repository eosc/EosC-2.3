create table featured (
  featured_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  featured_date_added datetime ,
  featured_last_modified datetime ,
  expires_date datetime ,
  date_status_change datetime ,
  status int(1) default '1' ,
  PRIMARY KEY (featured_id)
);

INSERT INTO configuration_group (configuration_group_id, configuration_group_title, configuration_group_description, sort_order, visible) values ('39','Destacats', 'Mostrar Productes Destacats', '339', '1'
);

INSERT into configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added) values ('Mostrar Productes Destacats', 'FEATURED_PRODUCTS_DISPLAY', 'true', 'Marcar Verdader (true) o Fals (false) per activar el m�dul de Productes Destacats.', '39', '1', now(), now()
);

INSERT into configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added) values ('N�mero m�xim de Productes Destacats', 'MAX_DISPLAY_FEATURED_PRODUCTS', '6', 'Aquest es el n�mero m�xim de productes a mostrar en la portada.', '39', '2', now(), now()
);

