<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  
  Featured Products Listing Language File
*/

define('NAVBAR_TITLE', 'Productes Destacats');
define('HEADING_TITLE', 'Productes Destacats');
define('TEXT_DISPLAY_NUMBER_OF_FEATURED_PRODUCTS', 'La millor relaci� qualitat-preu');
define('TEXT_NO_FEATURED_PRODUCTS', 'No hi han productes destacats.');
define('TEXT_DATE_ADDED', 'Data d\'Alta:');
define('TEXT_MANUFACTURER', 'Fabricant:');
define('TEXT_PRICE', 'Preu:');
?>
