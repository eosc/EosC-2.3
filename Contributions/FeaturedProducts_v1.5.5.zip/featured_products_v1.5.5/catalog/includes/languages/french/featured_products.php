<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  
  Featured Products Listing Language File
*/

define('NAVBAR_TITLE', 'Produits recommand�s');
define('HEADING_TITLE', 'Produits recommand�s');
define('TEXT_DISPLAY_NUMBER_OF_FEATURED_PRODUCTS', 'These Are The Most For The Money');
define('TEXT_NO_FEATURED_PRODUCTS', 'Il n\'y a pas de produits recommand�s !');
define('TEXT_DATE_ADDED', 'Date d\'ajout :');
define('TEXT_MANUFACTURER', 'Fabriquant :');
define('TEXT_PRICE', 'Prix :');
?>