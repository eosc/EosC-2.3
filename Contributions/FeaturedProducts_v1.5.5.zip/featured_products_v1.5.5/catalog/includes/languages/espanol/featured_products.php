<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  
  Featured Products Listing Language File
*/

define('NAVBAR_TITLE', 'Productos Destacados');
define('HEADING_TITLE', 'Productos Destacados');
define('TEXT_DISPLAY_NUMBER_OF_FEATURED_PRODUCTS', 'La mejor relaci�n calidad-precio');
define('TEXT_NO_FEATURED_PRODUCTS', 'No hay productos destacados.');
define('TEXT_DATE_ADDED', 'Fecha de Alta:');
define('TEXT_MANUFACTURER', 'Fabricante:');
define('TEXT_PRICE', 'Precio:');
?>