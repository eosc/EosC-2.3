<?php
/*
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License

  Featured Products Listing Language File
  �bersetzt von J�rg Schlechter
*/

define('NAVBAR_TITLE', 'Neue Produkte und Highlight`s');
define('HEADING_TITLE', 'Neue Produkte und Highlight`s');
define('TEXT_DISPLAY_NUMBER_OF_FEATURED_PRODUCTS', 'These Are The Most For The Money');
define('TEXT_NO_FEATURED_PRODUCTS', 'Es sind keine pr�sentierten Produkte angelegt.');
define('TEXT_DATE_ADDED', 'Hinzuf�gt am:');
define('TEXT_MANUFACTURER', 'Hersteller:');
define('TEXT_PRICE', 'Preis:');
?>