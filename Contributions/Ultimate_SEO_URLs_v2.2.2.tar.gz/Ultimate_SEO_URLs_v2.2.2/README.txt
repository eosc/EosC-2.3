Ultimate SEO URLs

http://www.oscommerce.com/community/contributions,2823

I am proud to announce the release of Ultimate SEO URLs for osCommerce-MS2.

This contribution builds on the cName & pName code to give an even more flexible, search engine friendly, and cross server compatible SEO URLs.

Once installed, Ultimate SEO URLs will give the store owner the choice of the v1.X style cName or new v2.X style static HTML file. This setting is incorporated into the admin control panel so can be toggled on, off, cName, or Rewrite at will.

This contribution will work for any store on any server. It is compatible with not only *NIX based servers but also Windows/IIS servers (although IIS is limited to cName).

In addition, this contribution is compatible with all other contributions by me including Page Cache (directions included in install package).

This release supports multiple languages, unlimited nested categories, and duplicates with ease.
