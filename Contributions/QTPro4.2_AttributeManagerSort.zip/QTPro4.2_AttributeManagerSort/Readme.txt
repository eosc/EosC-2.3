New Attributes Manager+Sort+QTpro

A trivial hack of New Attributes Manager v4b with Product Attribute Sort v1.0 
coupled with a sorta trivial hack to QTpro
_____________________________________________________________________
Author: Iggy
email: iggy@e.volve.net
Date: June 26, 2005

Very simple and effective Attribute Management contribution combined with an
an easy to install, simple to use modification to arbitrarily sort product 
attributes within their select box.

All credit for this contribution goes to Ralph Day, Mike G. and Forrest Miller. 
All of these excellent contributions compliment each other and, 
after performing this little hack multiple times, I was surprised 
someone hadn't already done it. So here it is!

Support will be sporadic at best but feel free to email me if you have 
problems. I can't guarantee I'll get back to you very quickly, 
if at all, but I'll give it a shot. For the most part this is a 
slam-dunk so hopefully no one will need support.

All files are modified osC 2.2. If you have a bone-stock osC installation 
(ie: brand new MS2) you can just copy the included files to their appropriate 
spots. If not, be careful =]

Instructions in this file are for Attribute Manager and Product Attribute Sort.
Please see the QTpro manual for QTpro install instructions.

Be sure to run all three sql files.

Hope this comes in handy for someone!
_____________________________________________________________________

New Attribute Manager v4b
Author: Mike G.
Date: 04/10/03
http://www.oscommerce.com/community/contributions,1119

Product Attrib Sort v1.0
by Forrest Miller  11/28/03 for osCommerce MS2
http://www.oscommerce.com/community/contributions,1690

_____________________________________________________________________


Installation--->

*This contribution works with 2.2MS2
*It's always a good idea to make backups before you begin a modification!

1. *Only perform this step if your default language id isn't 1 (Should be 1 by default).
	a) open new_attributes_config.php
	b) On line 4 change "1" to your language id.

2. *Only perform this step if you have one of the specified contributions installed.
	a) Linda McGrath's Sorter/Copier 5.1 with weight
		-a1) Open new_attributes_config.php
		-a2) On line 11 set $optionSortCopyInstalled = "1"

	b) Attributes Mod version 2.02.MS1 by countezero
		-b1) Open new_attributes_config.php
		-b2) On line 7 set $optionTypeInstalled = "1"

	b) Option Type Feature v1-4 by Chandra Roukema
		-b1) Open new_attributes_config.php
		-b2) On line 14 set $optionTypeTextInstalled = "1"
		-b3) On line 17 set $optionTypeTextInstalledID to your PRODUCTS_OPTIONS_VALUE_TEXT_ID
		     as specified in catalog/includes/config.php
		-b4) It is very important that you keep your products_options_values_to_products_options
		     table up to date as indicated in Chandra's README.html. If you don't have
		     entries in this table for your options then my contribution won't work.

3. The following files should go in your /admin/ directory: 
	a) new_attributes.php
	b) new_attributes_include.php
	c) new_attributes_change.php
	d) new_attributes_select.php
	e) new_attributes_functions.php
	f) new_attributes_config.php

4. You will need to edit the OSCommerce file admin/includes/boxes/catalog.php:
	a) find this line: '<a href="' . tep_href_link(FILENAME_CATEGORIES, '', 'NONSSL') . '" class="menuBoxContentLink">' . BOX_CATALOG_CATEGORIES_PRODUCTS . '</a><br>' .
	b) paste this on the line below it: '<a href="' . tep_href_link('new_attributes.php', '', 'NONSSL') . '" class="menuBoxContentLink">Attribute Manager</a><br>' .
	c) Save catalog.php & upload it if you need to.

5. You will need to make a small edit in the OSCommerce file admin/categories.php:
	a) I have included categories.php from 2.2MS2 in osc_files/categories.php already modified.
	b) If you can't just replace your categories.php with the one I provide, proceed->
		b1- In your admin/categories.php find: tep_image_button('button_copy_to.gif', IMAGE_COPY_TO) . '</a>');

		b2- replace with: tep_image_button('button_copy_to.gif', IMAGE_COPY_TO) . '</a><a href="./new_attributes.php?action=select&current_product_id=' . $pInfo->products_id . '&cPath=' . $cPath . '">' . tep_image_button('button_edit_attributes.gif', 'Edit Attributes') . '</A>');


6. Upload the provided images/button_edit_attributes.gif to the directory:
   admin/includes/languages/images/buttons/
 
7. Run the sql query in insert_attrib_sort.sql or use phpMyAdmin to upload and execute the file 
   to add a new column to the products_attributes table

8. Modify /catalog/product_info.php
FIND:
        $products_options_query = tep_db_query("select pov.products_options_values_id, pov.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_ATTRIBUTES . " pa, " . TABLE_PRODUCTS_OPTIONS_VALUES . " pov where pa.products_id = '" . (int)$HTTP_GET_VARS['products_id'] . "' and pa.options_id = '" . (int)$products_options_name['products_options_id'] . "' and pa.options_values_id = pov.products_options_values_id and pov.language_id = '" . (int)$languages_id . "'");

REPLACE WITH:
        $products_options_query = tep_db_query("select pov.products_options_values_id, pov.products_options_values_name, pa.options_values_price, pa.price_prefix from " . TABLE_PRODUCTS_ATTRIBUTES . " pa, " . TABLE_PRODUCTS_OPTIONS_VALUES . " pov where pa.products_id = '" . (int)$HTTP_GET_VARS['products_id'] . "' and pa.options_id = '" . (int)$products_options_name['products_options_id'] . "' and pa.options_values_id = pov.products_options_values_id and pov.language_id = '" . (int)$languages_id . "' order by pa.attribute_sort");

9. Modify /admin/includes/functions/general.php
ADD (anywhere):
   function tep_attributes_sort($attributes_id) {
    global $languages_id;

    $attributes_sort = tep_db_query("select attribute_sort from " . TABLE_PRODUCTS_ATTRIBUTES . " where products_attributes_id = '" . (int)$attributes_id . "'");
    $attributes_sort_values = tep_db_fetch_array($attributes_sort);

    return $attributes_sort_values['attribute_sort'];
  }
  
10. /admin/products_attributes.php
Line changes have been noted. A good diff program would come in handy right here if you can't just replace the file.


That's all there is to the installation. Attributes still need to be added via the 
Products Attributes but once you define them you can use the Attribute Manager for everything else. 
The remainder of this file is unchanged.

*********************************************************************

How To Use--->

I didn't remove or edit the original attribute manager. After installation
my manager will appear in the navigation menu above "Products Attributes" 
and will be listed as "*Attribute Manager".

*Added "edit attributes" button to the categories/product screen. 

You add Options & Option Values using the original OS Commerce Attribute 
Management, but use my manager to edit products.

**********************************************************************

Future Plans--->

I am going to combine the attribute management into one page.. using 
my system for editing products, and probably the original OS Commerce 
system for adding Options & Values.

Compatibility with other contributions continues.. suggestions welcomed.

**********************************************************************

Comments--->

Please send me some feedback.. I don't care if you are criticizing 
my programming or letting me know how my little contribution helped 
you..etc. It's all welcome =)

You can also email me if you have trouble getting it set up... 
although, I feel I've kept it very simple.

email: mp3man@internetwork.net
