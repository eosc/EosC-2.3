# QT Pro V4.0 Date: 12/04/2004

# Database changes for QT Pro installation to a store that does not have a
# previous version of QT Pro installed



# Add new column to products_options to indicate if stock should be tracked
# for an option

ALTER TABLE products_options
  ADD products_options_track_stock tinyint(4) default '0' not null
  AFTER products_options_name;

  
# Add new column to orders_products to track attributes to make it possible
# to delete an order and restock

ALTER TABLE orders_products
  ADD products_stock_attributes varchar(255) default NULL
  AFTER products_quantity;


# Create new table to track stock for products attributes

DROP TABLE IF EXISTS products_stock;
CREATE TABLE products_stock (
  products_stock_id int(11) not null auto_increment,
  products_id int(11) default '0' not null ,
  products_stock_attributes varchar(255) not null,
  products_stock_quantity int(11) default '0' not null ,
  PRIMARY KEY (products_stock_id),
  UNIQUE idx_products_stock_attributes (products_id,products_stock_attributes)
);
