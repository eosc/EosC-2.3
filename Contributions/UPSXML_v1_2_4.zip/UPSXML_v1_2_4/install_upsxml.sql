ALTER TABLE products
ADD products_length DECIMAL(6,2) DEFAULT '12' NOT NULL,
ADD products_width DECIMAL(6,2) DEFAULT '12' NOT NULL,
ADD products_height DECIMAL(6,2) DEFAULT '12' NOT NULL,
ADD products_ready_to_ship INT(1) DEFAULT '0' NOT NULL;

DROP TABLE IF EXISTS packaging;
CREATE TABLE packaging (
  package_id int NOT NULL auto_increment,
  package_name varchar(64) NOT NULL,
  package_description varchar(255) NOT NULL,
  package_length DECIMAL(6,2) default '5' NOT NULL,
  package_width DECIMAL(6,2) default '5' NOT NULL,
  package_height DECIMAL(6,2) default '5' NOT NULL,
  package_empty_weight DECIMAL(6,2) DEFAULT '0' NOT NULL,
  package_max_weight DECIMAL(6,2) DEFAULT '50' NOT NULL,
  package_cost int(5) NOT NULL,
  PRIMARY KEY (package_id)
);