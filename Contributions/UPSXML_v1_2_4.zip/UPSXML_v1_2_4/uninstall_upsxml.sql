ALTER TABLE products DROP products_length;
ALTER TABLE products DROP products_width;
ALTER TABLE products DROP products_height;
ALTER TABLE products DROP products_ready_to_ship;

DROP TABLE IF EXISTS PACKAGING;