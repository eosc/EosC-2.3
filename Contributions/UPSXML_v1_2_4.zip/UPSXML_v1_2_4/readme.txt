UPS XML Rates v1.2.4 for osCommerce 2.2 MS2 2006/12/26

Original Copyright (c) 2003 Torin Walker, torinwalker@rogers.com
Insurance Support 2005 Joe McFrederick, jomcfred@oldeparsonage.com

===============================================================================
This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as
published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied
warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program.
If not, you may obtain one by writing to and requesting one from

	The Free Software Foundation, Inc.,
	59 Temple Place, Suite 330,
	Boston, MA 02111-1307 USA
===============================================================================

Updated/modified/repackaged  for osCommerce 2.2 MS2 by Stuart Owens 11/14/04
Time in Transit fixed by Greg MacLellan 11/15/04
A few bugfixes and installation added to upsxml.php JanZ 11/27/04 (1.1.3)
Bugfix for ship in cart: Jackie Edwards (1.1.3a)
More options for cURL (CLI support added and logging of cURL errors) JanZ 12/18/04 (1.1.4)


Version 1.2.4 (JanZ): The services were updated according to Version 1.0, Volume 7, Number 1, Revision Date: December 17, 2006 of the Rates and Services XML Programming Information. See the file changes.txt for more detailed information on the changes.

Version 1.2:  **IMPORTANT** 
When upgrading from a version before this one, you *HAVE* to go into the admin, modules shipping, make a note of the settings (especially Access Key, Username and Password) and "remove" UPSXML, then upload the new version of the upsxml.php files and then install again. Otherwise the shipping options you did not wanted to offer are now the only ones offered (from version 1.1 -> 1.2). Because of new keys to be added to configuration you will also have to do this when going to 1.2.4.

Support: http://forums.oscommerce.com/index.php?showtopic=49382&view=getlastpost

Credits:
    Original Contribution and updates - Torin Walker
    Time In Transit capability - Donna Gordon
    Bug fixes - Fox Morrey
    Admin selectable methods and bug fixes - Jan Zonjee/Stuart Owens

===============================================================================
A note from the original author
-----------------------------------
If you somehow benefit from using this module, even if you chuckle at its moderate humour, you are requested to direct
your kids, friends, relatives, and pets toward my website to consider purchasing one of my fabulous products. If you like
toys, math, physics, chemistry, architecture, games, puzzles, construction sets, or twirling your hair, you are sure to enjoy
the Magnetic Geometric Toy For All Ages, Geo-Magnet!

  ++++  Don't be shy: http://www.geo-magnet.com

Our site will go live soon before Christmas in 2003. Be sure to mark Geo-Magnet down on your list of "Neat new presents I've
never seen before that I'm sure everyone will really, really enjoy and which are much better than underwear" things to buy.

**NOTE JanZ** I have never seen this site live

Description
-------------------
This module provides the osCommerce community with the long-awaited XML version of the UPS Rates and Services gatway.
It supports mutliple (customer facing) languages, multiple geographic origins, and implements the most necessary features
offered by the UPS Rates and Services system. The module connects to UPS and retrieves a list of available shipping methods
and prices and presents them to the user.

Settings are changed in the admin interface under
        Admin->Modules->Shipping->United Parcel Service (XML), and
        Admin->Tools->Packaging (if dimensional support is enabled)

The administrative interface shows shipper (not customer) related variables such as package type and origin in English, but
customer-facing product names (the name UPS uses to describe its services, such as 'Express Plus', and 'Next Day A.M.' can
be multi-lingual.

This module was created for three reasons: First, the HTML version does not support Canadian origins very well (read: at all).
Second, the HTML interface has been deprecated for some time now and it's about time *someone* wrote a new one. Third
and finally, because I wanted to contribute to pay homage to HPDL and the gang for their extraordinary efforts. It is the least
I could do for their providing me with such a wonderful online store system.

I tried like hell to use existing XML DOC support, but XML was not installed nor supported by my web hosting service which
required me to create my own. Hence, the additional pair of xmldocument.php files (they're identical) which provides simple
xml by path functions that work quite well for the task at hand.  You might find them useful elsewhere.

Finally, and most importantly, I installed Tom St. Croix's Canada Post 3.1 module which supports package dimensions, and
decided to support and enhance what he started. Dimensional support is disabled by default as it is rather involved, but you
should at the very least try it out. See STEP 6 for further details.

-- Torin Walker

===============================================================================
Features - version 1.1
-------------------------
If you elect to install dimensional support, the UPSXML Module will use an intelligent packing algorithm to load boxes with
product and return quotes based on the size and dimensions of those boxes. This contrasts with osCommerce's default
installation of quotes based on weight only, multiplied by the number of boxes. There is no guarantee that this simple packing
algoritm will work for all situations, nor return a better rate, but it should. More accurate quoting means less loss due to
customers being underquoted for shipping.

There is a Package Definition interface in Admin where one can create various packages in which product will ship. The
package definition is located in Admin->Tools->Packaging, and should be pretty straightforward. 

BOF ORIGINAL TEXT ABOUT COST
Cost (algorithmic cost, not
monetary) is the only factor that might not be intuitive. Cost determines the order in which packages are tried. Packages with
lower cost are tried before packages with higher cost. A box of 5x5x5 inches with a cost of 0 will be packed with product
before a package with dims of 8x8x8 and a cost of 1. This enables you to prioritize cardboard before wood or metal (of the
same dimensions), packages of identical volume, etc.
EOF ORIGINAL TEXT ABOUT COST

Cost can still be set in the packaging but is not used anywhere, so don't bother. The algorithm needs boxes sorted to volume. Cost just disturbs this. Anyway, you are smart enough to use the cheapest boxes yourself.

If you wish to pre-populate your package definitions with 700+ packages which are all within the UPS size restrictions, you
can find the file for this at http://www.oscommerce.com/community/contributions,1442

DIM_TYPES and WEIGHT_TYPE were removed because the modifications required to implement multiple unit types were too
extensive for a timely release. For now, the units you define your product with are the same units you should configure in the
UPS module (i.e. If you configure UPS to LBS/IN, your products should be similarly measured.)

The UPS Time In Transit was fixed by Greg MacLellan. Also added is the option to choose a "shipping delay", which changes the pickup-date (1 -> tomorrow). This will give more accurate estimated delivery dates.

This version also gives the ability to limit the shipping options offered to your customers. If you don't want to offer Next Day
Air, Next Day Air Early AM and Next Day Air Saver for example, you may choose which methods will be available to your
customers via the Admin interface. Be careful not to limit choices too severely, as that may leave some customers with no
UPS shipping options.

**IMPORTANT** 


When upgrading from a version before a 1.2 one, you *HAVE* to go into the admin, modules shipping, make a note of the settings (especially Access Key, Username and Password) and "remove" UPSXML and then install. Otherwise the shipping options you did not wanted to offer are now the only ones offered! This is because the exclude_choices now assumes the ones you do not want to offer are in the database, instead of the chosen ones. This makes the installation more foolproof in case STEP 3,4 and 5 are not followed. Before the module would be unusable, now it only makes that you cannot exclude choices.

===============================================================================
INSTALLATION
===============================================================================

--------
STEP 1
--------
BACKUP your database and any files that will be amended before beginning

--------
STEP 2
--------
Extract the files to their appropriate locations. The files needed are:

  catalog/admin/includes/classes/xmldocument.php
  catalog/includes/classes/xmldocument.php
  catalog/includes/languages/english/modules/shipping/upsxml.php
  catalog/includes/modules/shipping/upsxml.php

--------
STEP 3 *** If you have already installed USPS Methods or UPS Choice, you can skip this step
--------

In catalog/admin/modules.php

*****************************************
Find This code somewhere around line 43:
*****************************************

if (tep_not_null($action)) {
    switch ($action) {
      case 'save':
        while (list($key, $value) = each($HTTP_POST_VARS['configuration'])) {

***********************************************
INSERT THE FOLLOWING CODE AFTER THE ABOVE LINE:
***********************************************

if( is_array( $value ) ){
          $value = implode( ", ", $value);
		  $value = ereg_replace (", --none--", "", $value);
		    }

****************************
SO IT SHOULD LOOK LIKE THIS:
****************************

if (tep_not_null($action)) {
    switch ($action) {
      case 'save':
        while (list($key, $value) = each($HTTP_POST_VARS['configuration'])) {
          if( is_array( $value ) ){
          $value = implode( ", ", $value);
		  $value = ereg_replace (", --none--", "", $value);
		    }
          tep_db_query("update " . TABLE_CONFIGURATION . " set configuration_value = '" . $value . "' where configuration_key = '" . $key . "'");
        }
        tep_redirect(tep_href_link(FILENAME_MODULES, 'set=' . $set . '&module=' . $HTTP_GET_VARS['module']));
        break;
      case 'install':

--------
STEP 4 *** If you have already installed USPS Methods or UPS Choice, you can skip this step
--------

In catalog/admin/includes/functions/general.php

*****************************************
Find This code somewhere around line 767:
*****************************************

////
// Alias function for module configuration keys
  function tep_mod_select_option($select_array, $key_name, $key_value) {
    reset($select_array);
    while (list($key, $value) = each($select_array)) {
      if (is_int($key)) $key = $value;
      $string .= '<br><input type="radio" name="configuration[' . $key_name . ']" value="' . $key . '"';
      if ($key_value == $key) $string .= ' CHECKED';
      $string .= '> ' . $value;
    }

    return $string;
  }

***********************************************
INSERT THE FOLLOWING CODE AFTER THE ABOVE LINE:
***********************************************

// UPSXML
// Alias function for Store configuration values in the Administration Tool
  function tep_cfg_select_multioption($select_array, $key_value, $key = '') {
    for ($i=0; $i<sizeof($select_array); $i++) {
      $name = (($key) ? 'configuration[' . $key . '][]' : 'configuration_value');
      $string .= '<br><input type="checkbox" name="' . $name . '" value="' . $select_array[$i] . '"';
      $key_values = explode( ", ", $key_value);
      if ( in_array($select_array[$i], $key_values) ) $string .= ' CHECKED';
      $string .= '> ' . $select_array[$i];
    } 
    $string .= '<input type="hidden" name="' . $name . '" value="--none--">';
    return $string;
  }

****************************
SO IT SHOULD LOOK LIKE THIS:
****************************

////
// Alias function for module configuration keys
  function tep_mod_select_option($select_array, $key_name, $key_value) {
    reset($select_array);
    while (list($key, $value) = each($select_array)) {
      if (is_int($key)) $key = $value;
      $string .= '<br><input type="radio" name="configuration[' . $key_name . ']" value="' . $key . '"';
      if ($key_value == $key) $string .= ' CHECKED';
      $string .= '> ' . $value;
    }

    return $string;
  }
// UPSXML
// Alias function for Store configuration values in the Administration Tool
  function tep_cfg_select_multioption($select_array, $key_value, $key = '') {
    for ($i=0; $i<sizeof($select_array); $i++) {
      $name = (($key) ? 'configuration[' . $key . '][]' : 'configuration_value');
      $string .= '<br><input type="checkbox" name="' . $name . '" value="' . $select_array[$i] . '"';
      $key_values = explode( ", ", $key_value);
      if ( in_array($select_array[$i], $key_values) ) $string .= ' CHECKED';
      $string .= '> ' . $select_array[$i];
    } 
    $string .= '<input type="hidden" name="' . $name . '" value="--none--">';
    return $string;
  }
////
// Retrieve server information
  function tep_get_system_information() {
    global $HTTP_SERVER_VARS;

--------
STEP 5
--------

The configuration key which allows for selecting the types of methods to show your customers is type "VARCHAR(255)" in the
stock osC installation, which is not long enough to hold all of the possible UPS methods.

You have 2 options to deal with this:

  1) Go to the configuration table in your database and change the type for
      field "set_function" from VARCHAR(255) to TEXT

      -- OR --

  2) In catalog/includes/modules/shipping/upsxml.php (about line 291)
      Find the key MODULE_SHIPPING_UPSXML_TYPES
      and remove several of the shipping methods listed there to reduce the field to
      less than 255 characters (for example remove: " \'Next Day Air Early A.M.\', " and
      " \'2nd Day Air A.M.\', " ) Check the language file to see what options will be returned
      in your part of the world (in Europe there are only 4, so UPS Ground will never be presented
      to your customers as an option there).

If you haven't done any of the above mentioned two things while installing, you will get an error message in the admin section:
  "Parse error: parse error, unexpected ';' in ....../admin/modules.php(235): eval()'d code on line 1"
To rectify that, do any of the two options above, go to the admin section, shipping and "remove" upsxml, then "install" upsxml (again).
It will not render the module unusable if you don't fix it, you will just not be able to disable shipping options.

----------------------------
STEP 6 ** OPTIONAL **
----------------------------
This module supports the dimensions modifications proposed by Tom St. Croix's Canada Post 3.1 Module, and extends it with
the additional attribute, products_weight_type. The shipping module can then employ length, width, height, dimensions in
either centimeters or inches, and weight in pounds or kilograms. Dimensional support is somewhat involved, and is further
detailed in dimensions.txt, but offers more accurate shipping that can save you money.

Additional files needed for dimensional support and packaging addition:

    catalog/admin/packaging.php
    catalog/admin/includes/languages/english/packaging.php
    catalog/admin/includes/languages/english/images/buttons/button_new_package.gif

--------
STEP 7
--------
In admin, choose Modules->Shipping, and activate the new United Parcel Service (XML) module.
Edit the module and set your service options:

	UPS Rates account access key (obtain from UPS)
	UPS Rates account username (obtain from UPS)
	UPS Rates account password (obtain from UPS)
	Pickup method
	Packaging Type
	Customer Classification Code
	Shipping Origin (determines what products names are shown based on origin)
	Origin City (required for some countries)
	Origin State/Province (two letter ISO 3166 code)
	Origin Country (two letter ISO 3166 code)
	Origin Zip/Postal Code
	Test or Production mode
	Unit Weight
	Unit Length
	Dimensions Support
    Quote Type
	Handling Fee
	Enable Insurance
	Tax Class
	Shipping Zone
	Sort order of display
	Disallowed shipping methods
    Shipping Delay
    Email UPS errors (to the shop owner)

If you have any questions regarding the above settings, please refer to the documentation provided to you by UPS when you
signed up for and received your access key. If you still have questions, then post to the forums in the support thread:
http://forums.oscommerce.com/index.php?showtopic=49382&hl=

Note that Customer Classification Code and Pickup methods are only used when the Shipping Origin is US! So don't bother with it if that is not the case.

--------
STEP 8
--------
Test by setting your customer destination to all sorts of different places, and running through the shipping process several
times. Please test thoroughly before committing to its use.

If you fail to get quotes, an error message will usually tell you why. Make sure your origin information is correct, and use the
proper two-letter codes for your country and state/province.

If you STILL don't get any quotes, you can enable logging which will record the request/response of the transactions and any cURL errors. Look
for, uncomment, and change (e.g. to a full path) the line in upsxml.php (line 87):

//        $this->logfile = '/tmp/upsxml.log';

example of a full path:
'/home/yoursite/public_html/catalog/includes/modules/shipping/upsxml.log';

Change the location of the log to something you can read (don't forget to give the file write permissions 777), create an empty file "upsxml.log" on that location, and give the shopping cart a whirl. Your request/response will
eventually show up there.

If cURL is not compiled into PHP (Windows users (?) and some Linux users) you can change line 74 to : $this->use_exec = '1'; Using exec() cURL from the command line interface (CLI) is then used. See for more information "Changes from 1.1.3 to 1.1.4" in the changes.txt file.
If exec() is disabled and logging is enabled, this will be logged also.

--------
STEP 9
--------

A few lines below the line 87:
//        $this->logfile = '/tmp/upsxml.log';
you will find another line:
//      $this->ups_error_file = '/srv/www/htdocs/catalog/includes/modules/shipping/upsxml_error.log';

Do as in step 8: create an empty document of that name, set the path to what you want and make it writable for the server. This file will only log the error messages that are returned by UPS. The file in step 8 will grow very big, very quickly. This file is only one line per UPS module (TimeInTransit and Rates are used). Together with the admin setting for getting those errors emailed, you can keep tabs of what is happening. The customer id is logged too, so you can contact them if necessary.

--------
STEP 10
--------

If you have installed Separate Pricing Per Customer (SPPC), add this shipping module to the enabled ones for the customer groups.

===============================================================================
Disclaimer:

This revision is based on ups.php v.1.53, which employs the UPS cgi method that has been deprecated for over a year and
although it appears to remain functional is no longer officially supported by UPS.  The currently supported UPS API requires
XML requests through a secure socket layer, for which there is not yet an osC implementation.

------------------------------------

Finally,

In particular, I would like to thank the following individuals:
  Fritz Clapp for his UPS Choice v1.7 module, upon which I built this new module, and;
  Tom Croix for his efforts on the Canada Post 3.1 module from which several ideas were adopted.

Thanks to the many other authors before me who laid down their efforts in contributions from which I excavated the parts and
means to produce this. Your efforts are greatly appreciated.

I would like very much for this module to become a permanent resident of the osC contributions.
Your comments and suggestions are welcome and encouraged.

You did go to the  http://www.geo-magnet.com  website, didn't you?

Torin...
torinwalker@rogers.com