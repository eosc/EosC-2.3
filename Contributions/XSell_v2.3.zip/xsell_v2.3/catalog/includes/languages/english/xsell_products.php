<?php
/*
  $Id: xsell_products.php, v1
  The Exchange Project - Community Made Shopping!
  http://www.theexchangeproject.org

  Copyright (c) 2000,2001 The Exchange Project

  Released under the GNU General Public License
*/

  define('TEXT_BUY', 'Buy 1 \'');
  define('TEXT_NOW', '\' now');

?>
