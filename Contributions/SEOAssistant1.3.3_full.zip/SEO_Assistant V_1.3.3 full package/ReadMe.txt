SEO_Assistant V 1.3 by Jack York @ www.oscommerce-solution.com

NOTES: 
1 - This contribution replaces the previous incarnation that was 
named Google_Position.  It was renamed since that name did not 
fit with the new additions nor the planned additions.

2 - The core code for much of this contribution was found 
on the net. I just added what was needed to make it work with 
OSCommerce. Much of the code is my own though.

Tested on osCommerce 2.2-CVS

This is a tool for admin that will allow you to 
- Check your index position with Google and Yahoo 
- Check your page rank with Google
- Check your link popularity with all major SE's
- Check your keyword density 
- Check for broken links

/**************************************************************/
HISTORY:
v 1.3 - Fixed the MSN link popularity checker
        Added Broken Link Checker 
v 1.2 - Added link popularity checker.
        Fixed various HTML errors.
v 1.1 - Added keyword density analyzer.
V 1.0 - Original upload

/**************************************************************/
INSTALLATION:

NOTE: If you installed the previous incarnation named Google Position, 
see the RemoveReadme instructions on how to remove it.  It is not 
required to be removed but it is recommended to keep your shop clean.

1) Backup your shop and database.

2) Load the seo_assistant.sql file using phpmyadmin. You can alter the 
   file to start with your url and chosen search word(s) if you like.

3) Copy all of the files in the included admin directory to the same
   location on your server.  This will only replace files relating to
   this contribution so there is no need to worry about causing damage
   to your shop.

4) Add the following to admin/includes/database_tables.php before the final ?>
    define('TABLE_SEO_GOOGLE', 'seo_google');
    define('TABLE_SEO_YAHOO', 'seo_yahoo');
    
5) Add the following to admin/includes/filenames.php before the final ?>
    define('FILENAME_SEO_ASSISTANT', 'seo_assistant.php');

6) Find the line in admin/includes/boxes/tools.php that reads
   
    '<a href="' . tep_href_link(FILENAME_MAIL) . '" class="menuBoxContentLink">' . BOX_TOOLS_MAIL . '</a><br>' .
   
    and insert the following code after it:

    '<a href="' . tep_href_link(FILENAME_SEO_ASSISTANT) . '" class="menuBoxContentLink">' . BOX_TOOLS_SEO_ASSISTANT . '</a><br>' .
                             
7) In admin/includes/languages/english.php 
   
   FIND  
    define('BOX_TOOLS_MAIL', 'Send Email');
 
   ADD the following after it
    define('BOX_TOOLS_SEO_ASSISTANT', 'SEO Assistant');
   
   and in the same file

   FIND
    define('IMAGE_FILE_MANAGER', 'File Manager');

   ADD the following after it
    define('IMAGE_GET_PAGE_RANK', 'Get Page Rank');

   and in the same file
    
   FIND
    define('IMAGE_CANCEL', 'Cancel');

   ADD the following after it
    define('IMAGE_CHECK_DENSITY', 'Check Density');

   and in the same file

   FIND
    define('IMAGE_INSERT', 'Insert');

   ADD the following after it
    define('IMAGE_LINK_POPULARITY', 'Link Popularity');
add the following before the final ?>

// seo assistant start
define('HEADING_TITLE_SEARCH', 'Search Engine Ranking');
define('TEXT_POSITION', 'Positions for each keyword');

define('HEADING_TITLE_RANK', 'Page Ranking');
define('TEXT_RANK', 'Returns given google page rank for URL');

define('HEADING_TITLE_LINKPOP', 'Link Popularity');
define('TEXT_LINKPOP', 'Find Link Popularity for a given URL or compare with a comepetitior.');

define('HEADING_TITLE_DENSITY', 'Keyword Density');
define('TEXT_DENSITY', 'Check the density of words on your page');

define('HEADING_TITLE_CHECK_LINKS', 'Link Checker');
define('TEXT_CHECK_LINKS', 'Check your pages for broken links');
//seo assistant end
 
That's it.

/**************************************************************/
USAGE:
In admin->tools, click on the SEO Assistant link.

 SEARCH ENGIN POSITION:
 Enter the search word and url you want to check and click on search.  
 You don't need the http:// when you enter your url although it will 
 work.  Just enter www.yoursite.com for convenience. 

 If you check the Show Results checkbox, a list of the found sites 
 before the site you entered will be shown.

 The position for each url and search word(s) is recorded. If you 
 check the Show History checkbox, a table will be displayed
 showing the last 10 entries for the given word(s) and url.  You can
 change how many entires are kept in the database by changing the 
 following setting in admin/seo_assistant.php:
   maxEntries = '10';

 The resulting position is indicated by something like 100 (99).
 This means that your site is located at position 100 in the list 
 but the actual position, as far as google is concerned, is 99,
 resulting from the removal of similar sites.  They are usually
 very close or the same so it really doesn't matter when 
 everything else is considered.  Yahoo doesn't do this but the
 result is still shown.

 PAGE RANK:
 Clicking on the Get Page Rank button will return the page rank 
 Google has assigned to your site.

 LINK POPULARITY:
 This is a measure of how many links there are from other sites
 to you.  If you enter just the FIRST url, then only one site is
 checked.  If you enter a url in the COMPARE string, then both 
 will be checked. This is useful for comparing your site against 
 a competitor's site.  The results are displayed in a table.  The
 top three rows show your ranking with Alexa (considered by some to 
 be too skewed to have any true meaning), DMoz and Zeal (directories 
 that some SE's use for searching).  The bottom six entries contain 
 the number of backlinks found on the top SE's.

 KEYWORD DENSITY:
 Clicking the Check Density button will count the words on your 
 site and categorize them, providing a quick view of their density.
 Keyword density is very important if you expect to rank well in 
 the search engines.  Note that this code has a few minor problems
 in its parsing routines. They are not of any consequence and I am 
 working on them.  However, they do return what appears to be blank
 words.  These are generated by either the nobr or nbsp tags.  Also,
 in checking the results from a number of KD checkers on the web, I
 found that none of the results matched, between any of the checkers.  
 This particular code returns a higher than normal density so you 
 should keep this in mind. It will provide a quick clue as to which 
 of your word(s) are foremost from the SE's viewpoint.

 CHECK LINKS:
 Enter a url of your site and click on the Check Links button.
 That page will be checked for broken links.  Note that some links
 may appear broken but are really not. This can be due to a variety
 of reasons like needing to be signed in to use that page.  Also, since
 much of the code in an osCommerce shop is shared between pages due to
 the inclusion of the header, column_left, column_right and footer files,
 the same links may show up on any page you test.  The parser is not
 very advanced so some bad links may be due to parsing errors.  These
 will be obvious when you look at the link.  As it stands now, you have 
 to enter each page you want to test manually.  The code to check all 
 of the pages in included but not activated.  There are some problems 
 to be worked out with some of the pages causing an abort due to 
 waiting for a response (I think).  
 
/**************************************************************/
HELP:
If you have any questions regarding this contribution, please ask
on the support thread located in this thread:
http://forums.oscommerce.com/index.php?act=ST&f=7&t=108319

You can also email me at support@oscommerce-solution.com with questions 
about this package or about my services regarding improving your search
engine position using proper SEO techniques.  I provide a free
evaluation of your site with regards to SEO and will make suggestions 
as to how you may increase your position in the rankings. 