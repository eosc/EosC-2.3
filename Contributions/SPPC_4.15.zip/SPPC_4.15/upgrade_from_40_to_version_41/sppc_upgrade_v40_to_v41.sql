ALTER TABLE customers_groups
add group_payment_allowed varchar(255) NOT NULL default '',
add group_shipment_allowed varchar(255) NOT NULL default '';

ALTER TABLE customers
add customers_payment_allowed varchar(255) NOT NULL default '',
add customers_shipment_allowed varchar(255) NOT NULL default '';
