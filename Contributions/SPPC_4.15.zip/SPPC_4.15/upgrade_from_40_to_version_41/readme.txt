for version 4.1.5 no files in the upgrade folder, nor notes have been modified from 
what is was in version 4.1.4.  Suspect the included files may include files older
that those updated in osCommerce 2.2 Milestone 2 Update 051113
