ALTER TABLE customers
ADD customers_group_ra enum('0','1') NOT NULL,
ADD customers_payment_allowed varchar(255) NOT NULL default '',
ADD customers_shipment_allowed varchar(255) NOT NULL default '';

CREATE TABLE customers_groups (
 customers_group_id smallint UNSIGNED NOT NULL,
 customers_group_name varchar(32) NOT NULL default '',
 customers_group_show_tax enum('1','0') NOT NULL,
 customers_group_tax_exempt enum('0','1') NOT NULL,
 group_payment_allowed varchar(255) NOT NULL default '',
 group_shipment_allowed varchar(255) NOT NULL default '',
 PRIMARY KEY (customers_group_id)
 );

INSERT INTO customers_groups SELECT DISTINCT c.customers_group_id, c.customers_group_name, '1', '0' , '', '' FROM customers c GROUP BY customers_group_id;

ALTER TABLE address_book 
ADD entry_company_tax_id VARCHAR(32) DEFAULT NULL AFTER entry_company;

ALTER TABLE specials
ADD customers_group_id smallint UNSIGNED NOT NULL default '0';

