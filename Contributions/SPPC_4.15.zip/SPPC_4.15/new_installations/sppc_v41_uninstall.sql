ALTER TABLE customers
DROP customers_group_id,
DROP customers_group_ra,
DROP customers_payment_allowed,
DROP customers_shipment_allowed;

DROP TABLE IF EXISTS products_groups;

DROP TABLE IF EXISTS customers_groups;

ALTER TABLE specials
DROP customers_group_id;

ALTER TABLE address_book 
DROP entry_company_tax_id;
