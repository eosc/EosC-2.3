<?php
/*
   for Separate Pricing Per Customer v4 2005/03/03
*/
  
define('HEADING_TITLE', 'Grupos');
define('HEADING_TITLE_SEARCH', 'Buscar:');

define('TABLE_HEADING_NAME', 'Nombre');
define('TABLE_HEADING_ACTION', 'Acci�n');

define('ENTRY_GROUPS_NAME', 'Nombre&#160;grupo:');
define('ENTRY_GROUP_SHOW_TAX', 'Ense�ar&#160;precios&#160;con/sin&#160;impuesto:');
define('ENTRY_GROUP_SHOW_TAX_YES', 'Ense�ar precios con impuesto');
define('ENTRY_GROUP_SHOW_TAX_NO', 'Ense�ar precios sin impuesto');

define('ENTRY_GROUP_TAX_EXEMPT', 'Exempto de impuesto:'); 
define('ENTRY_GROUP_TAX_EXEMPT_YES', 'Si'); 
define('ENTRY_GROUP_TAX_EXEMPT_NO', 'No'); 

define('ENTRY_GROUP_PAYMENT_SET', 'Configurar modulos de pago para el Grupo de Clientes');
define('ENTRY_GROUP_PAYMENT_DEFAULT', 'Usar configuraciones desde la Configuraci� general');
define('ENTRY_PAYMENT_SET_EXPLAIN', 'Si escoges <b><i>Configurar modulos de pago para el Grupo de Clientes</i></b> la configuracion por defecto estar� todavia en uso.');

define('ENTRY_GROUP_SHIPPING_SET', 'Configurar modulos de env�o para el Grupo de Clientes');
define('ENTRY_GROUP_SHIPPING_DEFAULT', 'Usar configuraciones desde la Configuraci� general');
define('ENTRY_SHIPPING_SET_EXPLAIN', 'Si escoges <b><i>Configurar modulos de env�o para el Grupo de Clientes</i></b> la configuracion por defecto estar� todavia en uso.');

define('TEXT_DELETE_INTRO', 'Est�s seguro de querer borrar este Grupo de Clientes?');
define('TEXT_DISPLAY_NUMBER_OF_CUSTOMERS_GROUPS', 'Ense�ando <b>%d</b> a <b>%d</b> (de <b>%d</b> Grupos de Clientes)');
define('TEXT_INFO_HEADING_DELETE_GROUP', 'Borrar Grupo');

define('ERROR_CUSTOMERS_GROUP_NAME', 'Porfavor pon un nombre al Grupo');
?>
