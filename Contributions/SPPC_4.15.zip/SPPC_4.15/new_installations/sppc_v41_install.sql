ALTER TABLE customers
ADD customers_group_id smallint UNSIGNED NOT NULL default '0',
ADD customers_group_ra enum('0','1') NOT NULL,
ADD customers_payment_allowed varchar(255) NOT NULL default '',
ADD customers_shipment_allowed varchar(255) NOT NULL default '';

DROP TABLE IF EXISTS products_groups;
CREATE TABLE products_groups (
  customers_group_id smallint UNSIGNED NOT NULL default '0',
  customers_group_price decimal(15,4) NOT NULL default '0.0000',
  products_id int(11) NOT NULL default '0',
  PRIMARY KEY  (customers_group_id, products_id)
);

ALTER TABLE specials
ADD customers_group_id smallint UNSIGNED NOT NULL default '0';

DROP TABLE IF EXISTS customers_groups;
CREATE TABLE customers_groups (
 customers_group_id smallint UNSIGNED NOT NULL,
 customers_group_name varchar(32) NOT NULL default '',
 customers_group_show_tax enum('1','0') NOT NULL,
 customers_group_tax_exempt enum('0','1') NOT NULL,
 group_payment_allowed varchar(255) NOT NULL default '',
 group_shipment_allowed varchar(255) NOT NULL default '',
 PRIMARY KEY (customers_group_id)
 );

INSERT INTO customers_groups VALUES('0','Retail','1','0','','');

ALTER TABLE address_book 
ADD entry_company_tax_id VARCHAR(32) DEFAULT NULL AFTER entry_company;