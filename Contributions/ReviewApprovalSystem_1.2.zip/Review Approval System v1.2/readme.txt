   

Overview
--------

  This hack is to disallow any newly written review, until it is approved by the 
admin. It includes necessary hacks to catalog files to hide non-approved reviews 
from visitor and others to admin files to approve/disapprove reviews.

  In fact this is just part of my many modifications. I will try to make the 
others available too, as I get the time. Stripping my additions out of the 
source is not easy because there are so many. I'm well aware that I should make 
my changes public, and I do intend to.

  Other changes I will post include:

  - Gift Certificates
  - Order Printout
  - Discounts
  - Wholesale pricing/Basic B2B implementation 

(all completed in an old CVS snapshot, need to be ported over)

  Note that once you install this patch, no comment will show up on your site 
anymore. This is not a bug. The default state of reviews is "unapproved", so 
you'll need to approve those reviews in admin section.


Install
-------

1) Execute the review_approve.sql query, which will add the "approved" column to 
   the reviews table. If you want a newly written review be approved by default, 
   change the "DEFAULT 0" to DEFAULT "1", otherwise no need to change.

2) Preferably take a backup of your files. Admin and Catalog sections.

3) Copy all files into your shop directory, retaining directory tree.

4) That should do it.

5) If you want, and know what you're doing, run a cvs update.


Usage
-------
  When a new review is written for a product, it will be marked as "not 
approved" and will not show up on shop. To make the review shop up, admin has to 
go to the catalog/reviews page in admin section, and approve the review using 
the bottom of the box on the right. Any review can be rejected using the same 
way. The listing will show if a review has been approved or not, so it shouldnt 
be hard to find non-approved reviews.



  I hope this helps.



Tuncay GONCUOGLU
Senior Developer
tuncay@mira-soft.com

-----------------------------------
Mira Software Design House
Mira Bilisim Teknolojileri Ltd. Sti.
Microsoft Business Partner
LBS (Logo Business Solutions) Sofware Solution Partner
Mahmut Yesari Str No:9/17 Cankaya - ANKARA - TURKEY
Tel: +90 312 439 25 40 (PBX)
Fax: +90 312 435 24 60
www.mira-soft.com With us, everyday will be better than yesterday
-----------------------------------
