AutoInstall script created by Jack_mcs

Instructions for using the AutoInstall script

When ran, this script will make all the necessary changes to the 
application_top.php file as well as all of the applicable files in
the catalog directory.  All you will need to do at that point, is
copy the few files that come with the package to your shop and you
are all done (except for the admin section).  

*******************************************************************
NOTE: THIS SCRIPT REQUIRES THE SED EDITOR TO RUN.  
*******************************************************************

I am not allowed to include the script in this package due to forum 
rules, but it is freely available.  You can obtain it from my site
at http://www.oscommerce-solution.com in the Free Downloads section
or go to http://unxutils.sourceforge.net/ and click the UnxUpdates.zip 
link. If you have trouble getting the editor, contact me and I will 
send you a copy.


NOTE: THE ABOVE PROGRAM (sed) MUST INSTALLED IN THE AUTOINSTALL
DIRECTORY FOR THE SCRIPT TO WORK.  

Perform the following to use this script:

- Copy the sed.exe program to the autoinstall directory.

- Copy the contents of the Header Tags Controller zip file to some
  location on your hard drive.

- Copy all of the files (not directories) from your shops catalog
  directory to the autoinstall directory (don't create a new directory)

- Copy the includes/application_top.php file from your shop into the 
  autoinstall directory.

- Start a command prompt by 
   - Clicking on the Windows Start Button
   - Select Run
   - Type in cmd and press enter
   - Change the directory to where you have the unzipped files
      Note: If location is e:\some\long\location\, you would type in
      E: and hit return
      then type in chdir e:\some\long\location\ and hit return

- At the prompt, type in autoinstall and press enter

Look in the edited_files directory.  If the files are there, and the size
is not 0, the script completed successfully. However, you should check one
or two of the files to ensure the code was added.  Copy all of the files from 
the edited_files directory to your shops catalog directory.

In the autoinstall directory, there will be a file named appication_top.php_copy.
Copy it to your includes/ directory and rename it application_top.php.

Copy the files included in the catalog part of the HTC zip package to their 
respective locations (see regular instructions for this if you are unclear) and

You are done!