ALTER TABLE categories_description ADD categories_htc_description LONGTEXT NULL;
