ALTER TABLE products_description ADD products_head_title_tag VARCHAR(80) NULL;
ALTER TABLE products_description ADD products_head_desc_tag LONGTEXT NULL;
ALTER TABLE products_description ADD products_head_keywords_tag LONGTEXT NULL;

ALTER TABLE categories_description ADD categories_htc_title_tag VARCHAR(80) NULL;
ALTER TABLE categories_description ADD categories_htc_desc_tag LONGTEXT NULL;
ALTER TABLE categories_description ADD categories_htc_keywords_tag LONGTEXT NULL;
ALTER TABLE categories_description ADD categories_htc_description LONGTEXT NULL;

ALTER TABLE manufacturers_info ADD manufacturers_htc_title_tag VARCHAR(80) NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_desc_tag LONGTEXT NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_keywords_tag LONGTEXT NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_description LONGTEXT NULL;
