ALTER TABLE categories_description ADD categories_htc_title_tag VARCHAR(80) NULL;
ALTER TABLE categories_description ADD categories_htc_desc_tag LONGTEXT NULL;
ALTER TABLE categories_description ADD categories_htc_keywords_tag LONGTEXT NULL;