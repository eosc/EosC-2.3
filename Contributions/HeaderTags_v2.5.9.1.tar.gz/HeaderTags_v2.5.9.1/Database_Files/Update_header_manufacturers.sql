ALTER TABLE manufacturers_info ADD manufacturers_htc_title_tag VARCHAR(80) NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_desc_tag LONGTEXT NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_keywords_tag LONGTEXT NULL;
ALTER TABLE manufacturers_info ADD manufacturers_htc_description LONGTEXT NULL;
