The Header Tags Controller can be installed in three steps
to make troubleshooting easier.

1 - Install the data base changes. If this is a new install,
  use the header.sql file.  For exisitng installations prior
  to version V 2.3.8, use the Update_header_categories.sql file.
  They are located in the Database_Files directory of this
  archive.

  There are two easy ways to install them.  First, you can
  use a program named phpmyadmin to upload them.  It is 
  most likely available on your host.  There is a lof of
  information about it on the forums if you need it and
  can be found by searching for phpmyadmin.

  The second method is to use the database_setup.php file
  in the same directory.  This is easier to use for most
  people.  All you do is copy the file to your host.  Place
  it in the same directory that your index.php file is in.
  Then, open a browser and go to your site and type in the 
  name of the file after it.  For example, if the url of 
  your site is www.mysite.com, then type the following in 
  the browsers url string: 
    http://www.mysite.com/database_setup.php
  Then press enter and it should install it for you.

2 - If your site still works after the above and the database
  was uploaded successfully, then install the catalog
  part of the contribution by following the steps in the
  Install_Catalog file.  Once this is done, you should see a new
  title, Home, for your index page (it won't be the right title
  since you need to edit the includes/languages/enlgish/header_tags.php
  file).

  Note that the majority of the above changes are the same for each file.
  An AutoInstall script is included to make this process easier.  It 
  only changes some of the files (the ones mentioned in the instructions)
  so be sure to finish the rest of the installation should you decide 
  to use it.

3 - If your site still works after the above and the title
  seems to be changing, then install the admin part of the 
  contribution by following the steps in the Install_Admin file.

4) - Go to admin->Header Tags->Fill Tags, click on Fill All for 
  Categories, Manufacturers and Products and then click update.

  This will autofill your title, meta desc and meta keywords
  for all existing categories, manufacturers and products.

   product meta_title with product_name
   product meta_description with product_name or product_description (depends on settings)
   product meta_keyword with product_name 

   manufacturer meta_title with manufacturer_name
   manufacturer meta_description with manufacturer_name
   manufacturer meta_keyword with manufacturer_name

   category meta_title with category_name
   category meta_description with category_name
   category meta_keywords with category_name


If you have any problems, ask on the forum in the support thread at
http://forums.oscommerce.com/index.php?act=ST&f=7&t=51815

