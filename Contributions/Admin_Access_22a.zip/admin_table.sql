# $Id: admin_tabel.sql,v 1.1 2005/05/02 21:31:35 tropic Exp $
# --------------------------------------------------
# ADMIN ACCESS with LEVEL              
# for osCommerce's Administration Tool 
#
# Released under the GPL
# 
# Original Author
# ---------------
# Zaenal Muttaqin
# zaenal@paramartha
# donation to http://www.stormpay.com <email: zaenal@paramartha.org>
#
# Changes by Piero Trono for http://php-multishop.com


# Table structure for table `admin`
# ---------------------------------

DROP TABLE IF EXISTS admin;
CREATE TABLE admin (
  admin_id int(11) NOT NULL auto_increment,
  admin_groups_id int(11) default NULL,
  admin_firstname varchar(32) NOT NULL default '',
  admin_lastname varchar(32) default NULL,
  admin_email_address varchar(96) NOT NULL default '',
  admin_password varchar(40) NOT NULL default '',
  admin_created datetime default NULL,
  admin_modified datetime NOT NULL default '0000-00-00 00:00:00',
  admin_logdate datetime default NULL,
  admin_lognum int(11) NOT NULL default '0',
  PRIMARY KEY  (admin_id),
  UNIQUE KEY admin_email_address (admin_email_address)  
);

INSERT INTO admin VALUES (1, 1, 'AdminFirstname', 'AdminLastname', 'admin@localhost', '351683ea4e19efe34874b501fdbf9792:9b', now(), '0000-00-00 00:00:00', null, 0);



# Table structure for table `admin_files`
# ---------------------------------------

DROP TABLE IF EXISTS admin_files;
CREATE TABLE admin_files (
  admin_files_id int(11) NOT NULL auto_increment,
  admin_files_name varchar(64) NOT NULL default '',
  admin_files_is_boxes tinyint(5) NOT NULL default '0',
  admin_files_to_boxes int(11) NOT NULL default '0',
  admin_groups_id set('1','2') NOT NULL default '1',
  PRIMARY KEY  (admin_files_id)
);

INSERT INTO admin_files VALUES (1, 'administrator.php', 1, 0, '1');
INSERT INTO admin_files VALUES (2, 'configuration.php', 1, 0, '1');
INSERT INTO admin_files VALUES (3, 'catalog.php', 1, 0, '1,18');
INSERT INTO admin_files VALUES (4, 'modules.php', 1, 0, '1');
INSERT INTO admin_files VALUES (5, 'customers.php', 1, 0, '1,18');
INSERT INTO admin_files VALUES (6, 'taxes.php', 1, 0, '1');
INSERT INTO admin_files VALUES (7, 'localization.php', 1, 0, '1');
INSERT INTO admin_files VALUES (8, 'reports.php', 1, 0, '1');
INSERT INTO admin_files VALUES (9, 'tools.php', 1, 0, '1,18');
INSERT INTO admin_files VALUES (10, 'admin_members.php', 0, 1, '1');
INSERT INTO admin_files VALUES (11, 'admin_files.php', 0, 1, '1');
INSERT INTO admin_files VALUES (12, 'configuration.php', 0, 2, '1');
INSERT INTO admin_files VALUES (13, 'categories.php', 0, 3, '1');
INSERT INTO admin_files VALUES (14, 'products_attributes.php', 0, 3, '1');
INSERT INTO admin_files VALUES (15, 'manufacturers.php', 0, 3, '1');
INSERT INTO admin_files VALUES (16, 'reviews.php', 0, 3, '1');
INSERT INTO admin_files VALUES (17, 'specials.php', 0, 3, '1,18');
INSERT INTO admin_files VALUES (18, 'products_expected.php', 0, 3, '1');
INSERT INTO admin_files VALUES (19, 'modules.php', 0, 4, '1');
INSERT INTO admin_files VALUES (20, 'customers.php', 0, 5, '1,18');
INSERT INTO admin_files VALUES (21, 'orders.php', 0, 5, '1');
INSERT INTO admin_files VALUES (22, 'countries.php', 0, 6, '1');
INSERT INTO admin_files VALUES (23, 'zones.php', 0, 6, '1');
INSERT INTO admin_files VALUES (24, 'geo_zones.php', 0, 6, '1');
INSERT INTO admin_files VALUES (25, 'tax_classes.php', 0, 6, '1');
INSERT INTO admin_files VALUES (26, 'tax_rates.php', 0, 6, '1');
INSERT INTO admin_files VALUES (27, 'currencies.php', 0, 7, '1');
INSERT INTO admin_files VALUES (28, 'languages.php', 0, 7, '1');
INSERT INTO admin_files VALUES (29, 'orders_status.php', 0, 7, '1');
INSERT INTO admin_files VALUES (30, 'stats_products_viewed.php', 0, 8, '1');
INSERT INTO admin_files VALUES (31, 'stats_products_purchased.php', 0, 8, '1');
INSERT INTO admin_files VALUES (32, 'stats_customers.php', 0, 8, '1');
INSERT INTO admin_files VALUES (33, 'backup.php', 0, 9, '1');
INSERT INTO admin_files VALUES (34, 'banner_manager.php', 0, 9, '1,18');
INSERT INTO admin_files VALUES (35, 'cache.php', 0, 9, '1');
INSERT INTO admin_files VALUES (36, 'define_language.php', 0, 9, '1');
INSERT INTO admin_files VALUES (37, 'file_manager.php', 0, 9, '1');
INSERT INTO admin_files VALUES (38, 'mail.php', 0, 9, '1,18');
INSERT INTO admin_files VALUES (39, 'newsletters.php', 0, 9, '1,18');
INSERT INTO admin_files VALUES (40, 'server_info.php', 0, 9, '1');
INSERT INTO admin_files VALUES (41, 'whos_online.php', 0, 9, '1,18');
INSERT INTO admin_files VALUES (42, 'banner_statistics.php', 0, 9, '1,18');



# Table structure for table `admin_groups`
# ----------------------------------------

DROP TABLE IF EXISTS admin_groups;
CREATE TABLE admin_groups (
  admin_groups_id int(11) NOT NULL auto_increment,
  admin_groups_name varchar(64) default NULL,
  PRIMARY KEY  (admin_groups_id),
  UNIQUE KEY admin_groups_name (admin_groups_name)
);

INSERT INTO admin_groups VALUES (1, 'Top Administrator');
INSERT INTO admin_groups VALUES (2, 'Customer Relations');

