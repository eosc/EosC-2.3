#
# Access with Level Account (v. 2.2) for the Admin Area of osCommerce (MS2)
#

This is the full previous Admin-Access-Level package (2.1_1)
with UPDATE to oscommerce-2.2ms2-051113

The package includes definitions of constants in the following languages:
english, french, spanish, italian, german,


# INSTALLATION
--------------

1. Backup your files.

2. Database.
You must to create three tables into your DB, using the 'admin_tabel.sql' file.

3. Upload the files (ONLY if you have the original oscommerce files, without changes)
Upload/ovewrite all files of the package on your server.

4. Log In in the admin area and change the Admini default account
The default admin is 'admin@localhost' with password 'admin'.
Your first job may well be changing this security hole.

----------------------------------------------------------------

- This package has been originally written for osCommerce's Administration Tool (MS1)
by Zaenal Muttaqin <zaenal@paramartha.org>
(donation to http://www.stormpay.com <zaenal@paramartha.org>)

- After, customized by Seth Lake to works on osCommerce (MS2)
  and refinements by Herald Ponce De Leon (hpdl@oscommerce.com)

- Then, the existing works have been joined by Piero Trono (http://php-multishop.com)
in this package that includes the complete translation in
spanish, italian and french (translation in french thanks to CRDD - coroidedroite@yahoo.fr),
including the button images and some missing variables.
Note: as I don't speak german, some german definitions are written in english,
I'm sorry.

This package is released under the GNU/GPL License with absolutely no warranty
(read LICENSE.txt file).


# Features
----------
- Login box, password forgoten and logoff account
- Create/edit/delete admin account with group
- Create/edit/delete groups
- Define boxes and files permission for each groups
- Add/remove boxes and files
- My Account: edit admin account
- Automatic display accessed boxes and files (Left Menu)
- Email notification when create admin account
