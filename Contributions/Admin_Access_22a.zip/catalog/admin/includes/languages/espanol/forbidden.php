<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Incluye La Contribuci�n:
  Tenga acceso con la cuenta llana (v. 2.2a) para el �rea del Admin del osCommerce (MS2

  Este archivo puede ser suprimido si inhabilita la contribuci�n antedicha
*/

define('HEADING_TITLE', 'Access Negado');
define('NAVBAR_TITLE', 'No tienes Permnisos de Acceso');
define('TEXT_MAIN', '&nbsp;Por favor contacta tu <b>Administrator Web</b> para pedir <br>&nbsp;mas permisos o cualquier problema.<br>&nbsp;');
define('TEXT_BACK', 'vovler');
?>