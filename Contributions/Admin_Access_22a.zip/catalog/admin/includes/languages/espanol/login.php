<?php
/*
  $Id: login.php,v 1.2 2005/05/04 20:11:09 tropic Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Incluye La Contribuci�n:
  Tenga acceso con la cuenta llana (v. 2.2a) para el �rea del Admin del osCommerce (MS2

  Este archivo puede ser suprimido si inhabilita la contribuci�n antedicha
*/

// Translation by Piero Trono http://php-multishop.com


define('NAVBAR_TITLE', 'Login');
define('HEADING_TITLE', 'Bienvenido, puedes hacer el login');
define('TEXT_STEP_BY_STEP', 'paso a paso'); // should be empty


define('HEADING_RETURNING_ADMIN', 'Panel de Login:');
define('HEADING_PASSWORD_FORGOTTEN', 'Password Olvidada:');
define('TEXT_RETURNING_ADMIN', 'Solo Staff!');
define('ENTRY_EMAIL_ADDRESS', 'Direccion E-Mail:');
define('ENTRY_PASSWORD', 'Password:');
define('ENTRY_FIRSTNAME', 'Nombre:');
define('IMAGE_BUTTON_LOGIN', 'Submit');

define('TEXT_PASSWORD_FORGOTTEN', 'Password olvidada?');

define('TEXT_LOGIN_ERROR', '<font color="#ff0000"><b>ERROR:</b></font> Invalido username o password!');
define('TEXT_FORGOTTEN_ERROR', '<font color="#ff0000"><b>ERROR:</b></font> Nombre o password no rescontrada!');
define('TEXT_FORGOTTEN_FAIL', 'Ya has ententado mas que 3 veces. Por seguridad contacta tu Administrador para obtener una nueva password.<br>&nbsp;<br>&nbsp;');
define('TEXT_FORGOTTEN_SUCCESS', 'La nueva password ha sido enviada a tu correo elecctronico. Controlalo para hacer el login.<br>&nbsp;<br>&nbsp;');

define('ADMIN_EMAIL_SUBJECT', 'Nueva Password');
define('ADMIN_EMAIL_TEXT', 'Hola %s,' . "\n\n" . 'Puedes entrar en el area de Admin con la seguiente password. Despues del login, es mejor cambiar tu password!' . "\n\n" . 'Website : %s' . "\n" . 'Username: %s' . "\n" . 'Password: %s' . "\n\n" . 'Gracias!' . "\n" . '%s' . "\n\n" . 'Esto es un mail automatico, entonces no respondes!');
?>