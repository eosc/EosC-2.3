<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Incluye La Contribuci�n:
  Tenga acceso con la cuenta llana (v. 2.2a) para el �rea del Admin del osCommerce (MS2

  Este archivo puede ser suprimido si inhabilita la contribuci�n antedicha
*/

// Translation by Piero Trono http://php-multishop.com

define('HEADING_TITLE', 'Log Off');
define('NAVBAR_TITLE', 'Log Off');
define('TEXT_MAIN', 'Has salido desde el area <b>Admin</b>. Ahora puedes dejar tranquilo el ordenador. Puedes hacer click sobre Volver para otro login.');
define('TEXT_RELOGIN', 're-login');
?>