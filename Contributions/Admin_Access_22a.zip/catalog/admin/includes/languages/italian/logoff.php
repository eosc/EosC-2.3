<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Liberato sotto l'autorizzazione del grande pubblico di GNU
  Accesso con il cliente livellato (V. 2.2a) per la zona di Admin di osCommerce (MS2)

	Questa lima pu� essere cancellata se rimuovendo il suddetto contributo
*/

//Translation by Piero Trono http://php-multishop.com

define('HEADING_TITLE', 'Fine attivit�');
define('NAVBAR_TITLE', 'Fine attivit�');
define('TEXT_MAIN', 'Ora non sei Loggato nel pannello di <b>Amministrazione</b>. Clicca Indietro per un nuovo Login');
define('TEXT_RELOGIN', 'Inizio attivit�');
?>