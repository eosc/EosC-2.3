<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Liberato sotto l'autorizzazione del grande pubblico di GNU
  Accesso con il cliente livellato (V. 2.2a) per la zona di Admin di osCommerce (MS2)

	Questa lima pu� essere cancellata se rimuovendo il suddetto contributo
*/

//Translation by Piero Trono http://php-multishop.com

define('HEADING_TITLE', 'Access Negato');
define('NAVBAR_TITLE', 'Non hai i permessi per accedere');
define('TEXT_MAIN', '&nbsp;Contatta il <b>Web Administrator</b> per richiedere <br>&nbsp;ulteriori privilegi di accesso o eventuali problemi.<br>&nbsp;');
define('TEXT_BACK', 'indietro');
?>