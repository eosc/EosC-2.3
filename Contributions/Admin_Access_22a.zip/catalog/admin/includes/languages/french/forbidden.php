<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Inclut La Contribution:
  Acc�s avec le compte de niveau (V. 2.2a) pour la r�gion d'Admin de l'osCommerce (MS2)

	Ce dossier peut �tre supprim� si neutralisant la contribution ci-dessus
*/
// translation by CRDD (coroidedroite@yahoo.fr)

define('HEADING_TITLE', 'Acc&egrave; refus&eacute;');
define('NAVBAR_TITLE', 'Droits insuffisants');
define('TEXT_MAIN', '&nbsp;Veuillez contacter votre <b>Administrateur Web</b> pour demander des droits suppl&eacute;mentaires<br>&nbsp;ou si vous avez rencontr&eacute; un probl&egrave;me.<br>&nbsp;');
define('TEXT_BACK', 'Retour');
?>