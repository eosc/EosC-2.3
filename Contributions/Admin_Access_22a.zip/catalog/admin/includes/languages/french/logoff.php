<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Inclut La Contribution:
  Acc�s avec le compte de niveau (V. 2.2a) pour la r�gion d'Admin de l'osCommerce (MS2)

	Ce dossier peut �tre supprim� si neutralisant la contribution ci-dessus
*/
// translation by CRDD (coroidedroite@yahoo.fr)

define('HEADING_TITLE', 'Se connecter');
define('NAVBAR_TITLE', 'Se d&eacute;connecter');
define('TEXT_MAIN', 'Vous �tes d&eacute;connect&eacute; de la partie <b>Administration</b>. Vous pouvez quitter votre ordinateur en toute s&eacute;curit&eacute;. Cliquez sur retour pour vous reconnecter.');
define('TEXT_RELOGIN', 'Connexion');
?>