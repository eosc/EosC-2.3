<?php
/*
  $Id: login.php,v 1.11 2002/06/03 13:19:42 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Schlie�t Beitrag Ein:
  Zugang mit waagerecht ausgerichtetem Konto (v. 2.2a) f�r den Admin Bereich des osCommerce (MS2)

	Diese Akte kann gel�scht werden, wenn man den oben genannten Beitrag entfernt
*/


define('NAVBAR_TITLE', 'Zeichen Innen');
define('HEADING_TITLE', 'Willkommen. Bitte Zeichen Innen');
define('TEXT_STEP_BY_STEP', ''); // should be empty


define('HEADING_RETURNING_ADMIN', 'Zeichen In der Verkleidung:');
define('HEADING_PASSWORD_FORGOTTEN', 'Kennwort Vergessen:');
define('TEXT_RETURNING_ADMIN', 'Nur Personal!');
define('ENTRY_EMAIL_ADDRESS', 'Email Adresse:');
define('ENTRY_PASSWORD', 'Kennwort:');
define('ENTRY_FIRSTNAME', 'Vorname:');
define('IMAGE_BUTTON_LOGIN', 'Reichen Sie ein');

define('TEXT_PASSWORD_FORGOTTEN', 'Kennwort vergessen?');

define('TEXT_LOGIN_ERROR', '<font color="#ff0000"><b>St�rung:</b></font> Falsches username oder Kennwort!');
define('TEXT_FORGOTTEN_ERROR', '<font color="#ff0000"><b>St�rung:</b></font> Vorname und Kennwort passen nicht zusammen!');
define('TEXT_FORGOTTEN_FAIL', 'Sie haben �ber 3mal versucht. Aus Sicherheit Gr�nden treten Sie bitte mit Ihrem Hauptverwalter in Verbindung, um ein neues Kennwort zu erhalten.<br>&nbsp;<br>&nbsp;');
define('TEXT_FORGOTTEN_SUCCESS', 'Ein neues Kennwort ist zu Ihrer E-mail Adresse geschickt worden. �berpr�fen Sie bitte Ihre E-mail und klicken Sie die "r�ckseitige" Taste an, um innen zu unterzeichnen.<br>&nbsp;<br>&nbsp;');

define('ADMIN_EMAIL_SUBJECT', 'Neues Kennwort');
define('ADMIN_EMAIL_TEXT', 'Hallo %s,' . "\n\n" . 'Sie k�nnen die Leitung Verkleidung mit dem folgenden Kennwort zug�nglich machen. Sobald Sie die Verkleidung zug�nglich machen, �ndern Sie bitte Ihr Kennwort aus Sicherheit Gr�nden!' . "\n\n" . 'Website : %s' . "\n" . 'Username: %s' . "\n" . 'Kennwort: %s' . "\n\n" . 'Danke!' . "\n" . '%s' . "\n\n" . 'Dieses ist eine automatisierte Antwort, bitte antworten Sie nicht!');
?>