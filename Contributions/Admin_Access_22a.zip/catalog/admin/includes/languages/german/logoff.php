<?php
/*
  $Id $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Schlie�t Beitrag Ein:
  Zugang mit waagerecht ausgerichtetem Konto (v. 2.2a) f�r den Admin Bereich des osCommerce (MS2)

	Diese Akte kann gel�scht werden, wenn man den oben genannten Beitrag entfernt
*/

define('HEADING_TITLE', 'Maschinenbordbuch Weg');
define('NAVBAR_TITLE', 'Maschinenbordbuch Weg');
define('TEXT_MAIN', 'Sie sind vom Leitung Bereich geloggt worden-weg. Es ist jetzt sicher, den Computer zu lassen. Klicken zur�ck zu Maschinenbordbuchr�ckseite innen.');
define('TEXT_RELOGIN', 'Maschinenbordbuch innen');
?>