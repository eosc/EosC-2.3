<?php
/*
  $Id: whos_online.php,v 1.9 2002/03/30 15:48:55 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

// added for version 1.9 - to be translated to the right language BOF ******
define('AZER_WHOSONLINE_WHOIS_URL', 'http://www.dnsstuff.com/tools/whois.ch?ip='); //for version 2.9 by azer - whois ip
define('TEXT_NOT_AVAILABLE', '   <b>Note:</b> N/A = IP non available'); //for version 2.9 by azer was missing
define('TEXT_LAST_REFRESH', 'Last refresh at'); //for version 2.9 by azer was missing
define('TEXT_EMPTY', 'Empty'); //for version 2.8 by azer was missing
define('TEXT_MY_IP_ADDRESS', 'My IP adresss '); //for version 2.8 by azer was missing
define('TABLE_HEADING_COUNTRY', 'Country'); // azerc : 25oct05 for contrib whos_online with country and flag
// added for version 1.9 EOF *************************************************

define('HEADING_TITLE', 'Hvem er i butikken 1.9');
define('TABLE_HEADING_ONLINE', 'Online');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Fullt navn');
define('TABLE_HEADING_IP_ADDRESS', 'IP Addresse');
define('TABLE_HEADING_ENTRY_TIME', 'Ankomsttid');
define('TABLE_HEADING_LAST_CLICK', 'Siste klikk');
define('TABLE_HEADING_LAST_PAGE_URL', 'Siste URL');
define('TABLE_HEADING_ACTION', 'Kj�r');
define('TABLE_HEADING_SHOPPING_CART', 'Brukerens handlekurv');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Totalt');
define('TEXT_NUMBER_OF_CUSTOMERS', '%s &nbsp;kunder i butikken');
define('TABLE_HEADING_HTTP_REFERER', 'Kom fra');
define('TEXT_HTTP_REFERER_URL', 'HTTP Kom fra');
define('TEXT_HTTP_REFERER_FOUND', 'Funnet');
define('TEXT_HTTP_REFERER_NOT_FOUND', 'N/A');
define('TEXT_STATUS_ACTIVE_CART', 'Aktiv with kurv');
define('TEXT_STATUS_ACTIVE_NOCART', 'Aktiv No kurv');
define('TEXT_STATUS_INACTIVE_CART', 'Inaktiv with Kurv');
define('TEXT_STATUS_INACTIVE_NOCART', 'Inaktiv No kurv');
define('TEXT_STATUS_NO_SESSION_BOT', 'Inaktiv Session Bot?');
define('TEXT_STATUS_INACTIVE_BOT', 'Inaktiv Session Bot?');
define('TEXT_STATUS_ACTIVE_BOT', 'Aktiv Session Bot?');
define('TABLE_HEADING_COUNTRY', 'Cntry');
define('TABLE_HEADING_USER_SESSION', 'Session?');
define('TEXT_IN_SESSION', 'Yes');
define('TEXT_NO_SESSION', 'No');

define('TEXT_OSCID', 'osCid');
define('TEXT_PROFILE_DISPLAY', 'Profil Vis');
define('TEXT_USER_AGENT', 'Bruker Agent');
define('TEXT_ERROR', 'Feil!');
define('TEXT_ADMIN', 'Admin');
define('TEXT_DUPLICATE_IP', 'Duplikate IP\'er');
define('TEXT_BOTS', 'Bots');
define('TEXT_ME', 'Meg!');
define('TEXT_ALL', 'Alle');
define('TEXT_REAL_CUSTOMERS', 'Reelle kunder');
define('TEXT_MY_IP_ADDRESS', 'Din IP Addresse');
define('TEXT_SET_REFRESH_RATE', 'Sett Oppdateringsfrekvens');
define('TEXT_NONE_', 'Ingen');
define('TEXT_CUSTOMERS', 'Customers');
?>