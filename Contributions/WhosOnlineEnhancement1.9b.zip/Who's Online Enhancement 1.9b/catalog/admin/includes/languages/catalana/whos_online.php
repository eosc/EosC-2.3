<?php
/*
  $Id: whos_online.php,v 1.9 2002/03/30 15:48:55 harley_vb Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
  Versi� catalana: calbasi@pangea.org
*/

// added for version 1.9 - to be translated to the right language BOF ******
define('AZER_WHOSONLINE_WHOIS_URL', 'http://www.dnsstuff.com/tools/whois.ch?ip='); //for version 2.9 by azer - whois ip
define('TEXT_NOT_AVAILABLE', '   <b>Note:</b> N/A = IP non available'); //for version 2.9 by azer was missing
define('TEXT_LAST_REFRESH', 'Last refresh at'); //for version 2.9 by azer was missing
define('TEXT_EMPTY', 'Empty'); //for version 2.8 by azer was missing
define('TEXT_MY_IP_ADDRESS', 'My IP adresss '); //for version 2.8 by azer was missing
define('TABLE_HEADING_COUNTRY', 'Country'); // azerc : 25oct05 for contrib whos_online with country and flag
// added for version 1.9 EOF *************************************************

define('HEADING_TITLE', 'Qui est� connectat 1.9?');

define('TABLE_HEADING_ONLINE', 'Connectat');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Nom');
define('TABLE_HEADING_IP_ADDRESS', 'Adre�a IP');
define('TABLE_HEADING_ENTRY_TIME', 'Temps entrada');
define('TABLE_HEADING_LAST_CLICK', '�ltim Click');
define('TABLE_HEADING_LAST_PAGE_URL', '�ltim URL');
define('TABLE_HEADING_ACTION', 'Acci�');
define('TABLE_HEADING_SHOPPING_CART', 'Cistella');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Subtotal');
define('TEXT_NUMBER_OF_CUSTOMERS', '%s &nbsp;Clients online');
define('TABLE_HEADING_HTTP_REFERER', 'URL d\'origen');
define('TEXT_HTTP_REFERER_URL', 'HTTP URL d\'origen');
define('TEXT_HTTP_REFERER_FOUND', 'Trobada');
define('TEXT_HTTP_REFERER_NOT_FOUND', 'No trobada');
define('TEXT_STATUS_ACTIVE_CART', 'Actiu/Cistella');
define('TEXT_STATUS_ACTIVE_NOCART', 'Actiu/Sense cistella');
define('TEXT_STATUS_INACTIVE_CART', 'Inactiu/Cistella');
define('TEXT_STATUS_INACTIVE_NOCART', 'Inactiu/Sense cistella');
define('TEXT_STATUS_NO_SESSION_BOT', 'Sense sessi�/Bot?');
define('TEXT_STATUS_INACTIVE_BOT', 'Inactiu/Bot');
define('TEXT_STATUS_ACTIVE_BOT', 'Actiu/Bot');
define('TABLE_HEADING_COUNTRY', 'Pais');
define('TABLE_HEADING_USER_SESSION', 'Sesi�?');
define('TEXT_IN_SESSION', 'Yes');
define('TEXT_NO_SESSION', 'No');

define('TEXT_OSCID', 'osCid');
define('TEXT_PROFILE_DISPLAY', 'Visualitzaci� del perfil');
define('TEXT_USER_AGENT', 'Navegador');
define('TEXT_ERROR', 'Error!');
define('TEXT_ADMIN', 'Admininstrador');
define('TEXT_DUPLICATE_IP', 'IPs duplicades');
define('TEXT_BOTS', 'Bots');
define('TEXT_ME', 'Jo!');
define('TEXT_ALL', 'Tot');
define('TEXT_REAL_CUSTOMERS', 'Clients reals');
define('TEXT_MY_IP_ADDRESS', 'La teva IP');
define('TEXT_SET_REFRESH_RATE', 'Temps d\'actualitzaci�');
define('TEXT_NONE_', 'Cap');
define('TEXT_CUSTOMERS', 'Customers');

?>
