<?php
/*
  $Id: whos_online.php,v 1.9 2002/03/30 15:48:55 harley_vb Exp $
// corection french by azer
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

// added for version 1.9 - to be translated to the right language BOF ******
define('AZER_WHOSONLINE_WHOIS_URL', 'http://www.dnsstuff.com/tools/whois.ch?ip='); //for version 2.9 by azer - whois ip
define('TEXT_NOT_AVAILABLE', '   <b>Note:</b> N/A = IP non disponible'); //for version 2.9 by azer was missing
define('TEXT_LAST_REFRESH', '(am pour matin et pm pour apres-midi) -  Dernier rafraichissement fait �'); //for version 2.9 by azer was missing
define('TEXT_EMPTY', 'Vide'); //for version 2.8 by azer was missing
define('TEXT_MY_IP_ADDRESS', 'Mon adressse IP'); //for version 2.8 by azer was missing
define('TABLE_HEADING_COUNTRY', 'Pays'); // azerc : 25oct05 for contrib whos_online with country and flag
define('HEADING_TITLE', 'Qui est en ligne 1.9');
// added for version 1.9 EOF *************************************************

define('TABLE_HEADING_ONLINE', 'En ligne');
define('TABLE_HEADING_CUSTOMER_ID', 'ID');
define('TABLE_HEADING_FULL_NAME', 'Nom et Pr&eacute;nom'); //azer
define('TABLE_HEADING_IP_ADDRESS', 'Adresse IP');
define('TABLE_HEADING_ENTRY_TIME', 'Heure d\'arriv&eacute;e');
define('TABLE_HEADING_LAST_CLICK', 'Dernier Clic');
define('TABLE_HEADING_LAST_PAGE_URL', 'Derni&egrave;re URL');
define('TABLE_HEADING_ACTION', 'Action');
define('TABLE_HEADING_SHOPPING_CART', 'Panier utilisateur');
define('TEXT_SHOPPING_CART_SUBTOTAL', 'Sous-total');
define('TEXT_NUMBER_OF_CUSTOMERS', 'Actuellement il y a %s client(s) en ligne');
define('TABLE_HEADING_HTTP_REFERER', 'Referer URL');
define('TEXT_HTTP_REFERER_URL', 'HTTP Referer URL');
define('TEXT_HTTP_REFERER_FOUND', 'Trouv&eacute;');
define('TEXT_HTTP_REFERER_NOT_FOUND', 'Non trouv&eacute;');
define('TEXT_STATUS_ACTIVE_CART', 'Actif avec Panier');
define('TEXT_STATUS_ACTIVE_NOCART', 'Actif avec panier vide'); //azer
define('TEXT_STATUS_INACTIVE_CART', 'Inactif avec Panier'); //azer
define('TEXT_STATUS_INACTIVE_NOCART', 'Inactif avec panier vide');
define('TEXT_STATUS_NO_SESSION_BOT', 'Robot sans session?'); //Azer !!! check if right description
define('TEXT_STATUS_ACTIVE_BOT', 'Robot avec session actif '); //Azer !!! check if right description
define('TEXT_STATUS_INACTIVE_BOT', 'Robot avec session inactif '); //Azer !!! check if right description
define('TABLE_HEADING_COUNTRY', 'Pays');
define('TABLE_HEADING_USER_SESSION', 'Session ?'); //azer
define('TEXT_IN_SESSION', 'Oui'); //azer
define('TEXT_NO_SESSION', 'Non'); //azer

define('TEXT_OSCID', 'Session osCsid'); //azer
define('TEXT_PROFILE_DISPLAY', 'Affichage Profil');
define('TEXT_USER_AGENT', 'Navigateur');
define('TEXT_ERROR', 'Erreur!');
define('TEXT_ADMIN', 'Admin');
define('TEXT_DUPLICATE_IP', 'IP(s) dupliqu�e(s)'); //azer
define('TEXT_BOTS', 'Robot(s)');
define('TEXT_ME', 'Moi-m�me!'); //azer
define('TEXT_ALL', 'Tous'); //azer
define('TEXT_REAL_CUSTOMERS', 'Client(s) r�el(s)');
define('TEXT_YOUR_IP_ADDRESS', 'Votre Adresse IP');
define('TEXT_SET_REFRESH_RATE', 'Taux de rafra&icirc;chissement');
define('TEXT_NONE_', 'Aucun');
define('TEXT_CUSTOMERS', 'Client(s)');
?>