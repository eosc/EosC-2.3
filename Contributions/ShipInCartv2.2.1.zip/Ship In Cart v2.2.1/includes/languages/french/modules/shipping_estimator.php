<?php
/*
  $Id: shipping_estimator.php,v 2.10 2004/07/01 15:16:07 eml Exp $

  v2.00 by Acheron
  (see Install.txt for partial version history)

  Copyright (c) 2004

  Released under the GNU General Public License
*/

  define('CART_SHIPPING_CARRIER_TEXT', 'Livreur');
  define('CART_SHIPPING_OPTIONS', 'Estimation des co�ts de livraisons');
  define('CART_SHIPPING_OPTIONS_LOGIN', 'SVP <a href="' . tep_href_link(FILENAME_LOGIN, '', 'SSL') . '"><u>Identifiez-vous</u></a>, pour affiner l\'estimation.');
  define('CART_SHIPPING_METHOD_TEXT','Delivery Methods');
  define('CART_SHIPPING_METHOD_RATES','Rates');
  define('CART_SHIPPING_METHOD_TO','Ship to: ');
  define('CART_SHIPPING_METHOD_TO_NOLOGIN', '<b>Livraison � :</b>&nbsp;&nbsp;<a href="' . tep_href_link(FILENAME_LOGIN, '', 'SSL') . '"><u>S\'identifier</u></a>');
  define('CART_SHIPPING_METHOD_FREE_TEXT','Livraison gratuite');
  define('CART_SHIPPING_METHOD_ALL_DOWNLOADS',' (Article t�l�chargeable ou virtuel)');
  define('CART_SHIPPING_METHOD_RECALCULATE','Recalculer');
  define('CART_SHIPPING_METHOD_ADDRESS','Addresse :');
  define('CART_OT','Estimation du co�t du panier ');
  define('CART_SELECT','s�l�ctionner');
  define('CART_SELECT_THIS_METHOD','Calculer le total en optant pour ce mode de livraison'); // added for 2.10
?>