#----------------------------
# Table structure for pages
#----------------------------
CREATE TABLE `pages` (
  `pages_id` int(11) NOT NULL auto_increment,
  `pages_name` varchar(32) NOT NULL default '',
  `pages_image` varchar(64) NOT NULL default '',
  `sort_order` int(3) NOT NULL default '0',
  `pages_status` tinyint(1) NOT NULL default '0',
  PRIMARY KEY  (`pages_id`)
) TYPE=MyISAM ;


#----------------------------
# Records for table pages
#----------------------------
INSERT INTO `pages` VALUES (1, 'home', '', -100, 1);
INSERT INTO `pages` VALUES (2, 'contact_us', '', -100, 1);
INSERT INTO `pages` VALUES (3, 'shipping', '', 1, 1);
INSERT INTO `pages` VALUES (4, 'conditions', '', 3, 1);
INSERT INTO `pages` VALUES (5, 'privacy', '', 2, 1);

#----------------------------
# Table structure for pages_description
#----------------------------

CREATE TABLE `pages_description` (
  `pages_id` int(11) NOT NULL default '0',
  `language_id` int(11) NOT NULL default '0',
  `pages_title` varchar(255) NOT NULL default '',
  `pages_body` text NOT NULL,
  PRIMARY KEY  (`pages_id`,`language_id`)
) TYPE=MyISAM ;

#----------------------------
# Records for table pages_description
#----------------------------
INSERT INTO `pages_description` VALUES (1, 1, 'Home Page', 'Place your home page text here...');
INSERT INTO `pages_description` VALUES (2, 1, 'Contact Us', 'Place your contact us text here...');
INSERT INTO `pages_description` VALUES (3, 1, 'Shipping & Returns', 'Place your shipping and returns text here...');
INSERT INTO `pages_description` VALUES (4, 1, 'Conditions of Use', 'Place your conditions of use text here...');
INSERT INTO `pages_description` VALUES (5, 1, 'Privacy Notice', 'Place your privacy notice text here...');
