Overview
--------
The page editor allows you to easily add, edit and delete your
own web pages in osCommerce.  You will also be able to manage
your home page and contact page.  Pages can be enabled and disabled.  
Supports multiple languages and page header images.

It works and looks like the product manager.


Requirements
------------
osCommerce 2.2MS2
PHP 4 or greater


Features
--------
 - Administrative features:
   o Manage home page
   o Manage contact page
   o Manage custom pages
   o Enable/Disable pages
   o Upload page images
   o Multi language

 - User features:
   o Display pages


Installation
------------
Please refer to the INSTALL.txt file for installation directions.


Credits
-------
 - Designed and maintained by Mr PHP:
    http://www.mrphp.com.au/


Bugs and Suggestions
--------------------
Bug reports, support requests, feature requests, etc, should be posted to
page edit project page at:
http://mrphp.com.au/