<?php
/*
  $Id: latest_news.php,v 1.1.1.1 2002/11/11 06:15:14 will Exp $
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 Will Mays
  Released under the GNU General Public License
*/
define('HEADING_INFOS_TITLE', 'Ent�te & Pied de pages par d�fault');
define('TABLE_HEADING_NEWSLETTER_HEADER', 'Ent�te');
define('TABLE_HEADING_NEWSLETTER_ID', 'Newsletter Id');
define('TABLE_HEADING_LATEST_NEWS_ACTION', 'Action');
define('TEXT_NEWS_ITEMS', 'Extra Information:');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Suppression de l\'Item');
define('TEXT_DELETE_ITEM_INTRO', 'Etes vous sur de vouloir supprimer cet item ?');
define('TEXT_NEW_NEWSLETTER_INFO', 'Informations par d�fault sur Ent�te & Pied de page');
define('TEXT_NEWSLETTER_MODULE', 'Module utilis� pour envoyer la newsletter :');
define('TEXT_NEWSLETTER_HEADER', 'Ent�te de la page :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA', 'Pied de page n�1 avec le lien pour ce d�sabonner :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEB', 'Pied de page n�2 pour information divers :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA_INFO', '<font color="#ff000">Information ! Sur le pied de page n�1, un lien sera ajout� <u>automatiquement</u> � l\'envoi de la newsletter afin de pouvoir donner la possibilt� au client de ce d�sabonner.</font>');
?>