<?php
/*
  $Id: newsletter.php,v 1.3 2002/03/08 18:38:18 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

// ################# Contribution Newsletter v050 ##############
define('TEXT_COUNT_CUSTOMERS', '&bull; Clients recevant le bulletin d\'informations : <font color="#0000ff">%s</font>');
define('TEXT_MODULE', '&bull; Module utilis� pour envoyer la newsletter :');
define('TEXT_BULLETIN_NUMB', '&bull; Bulletin d\'information num�ro :');
define('TEXT_TITRE_MAIL', '&bull; Titre du bulletin d\'information :');
define('TEXT_TITRE_INFO', '&bull; Information sur le bulletin d\'information &bull;');
define('TEXT_TITRE_VIEW', '&bull; Aper�u du bulletin d\'information &bull;');
// ################# END - Contribution Newsletter v050 ##############
?>