<?php
/*
  $Id: latest_news.php,v 1.1.1.1 2002/11/11 06:15:14 will Exp $
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 Will Mays
  Released under the GNU General Public License
*/
define('HEADING_INFOS_TITLE', 'Administration Ent�te /bas de page');
define('TABLE_HEADING_NEWSLETTER_HEADER', 'Module d\'envoie utilis�');
define('TABLE_HEADING_NEWSLETTER', 'Titre Newsletter');
define('TABLE_HEADING_NEWSLETTER_ID', 'Num�ro');
define('TABLE_HEADING_LATEST_NEWS_ACTION', 'Action');
define('TEXT_NEWS_ITEMS', 'Nombres d\'ent�te et pied de page :');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Suppression Item');
define('TEXT_DELETE_ITEM_INTRO', 'Etes vous sur de vouloir supprimer cet item ?');
define('TEXT_NEW_NEWSLETTER_INFO', 'Modifier Ent�te & Pied de page sur la newsletter n�');
define('IMAGE_NEW_NEWS_ITEM', 'info nouveau item');
define('TEXT_NO_CHILD_CATEGORIES_OR_PRODUCTS', 'Aucune information');
define('EMPTY_CATEGORY', 'Aucune Ent�te & pied de page');
define('TEXT_NEWSLETTER_MODULE', 'Module utilis� pour envoyer la newsletter :');
define('TEXT_NEWSLETTER_HEADER', 'Ent�te de la page :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA', 'Pied de page n�1 avec le lien pour ce d�sabonner :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEB', 'Pied de page n�2 pour information divers :');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA_INFO', '<font color="#ff000">Information ! Sur le pied de page n�1, un lien sera ajout� <u>automatiquement</u> � l\'envoi de la newsletter afin de pouvoir donner la possibilt� au client de ce d�sabonner.</font>');
?>