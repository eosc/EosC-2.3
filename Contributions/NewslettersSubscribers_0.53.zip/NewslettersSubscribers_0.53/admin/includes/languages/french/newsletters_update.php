<?php
/*
  $Id: newsletters.php,v 1.5 2002/03/08 22:10:08 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

define('HEADING_TITLE', 'Gestionnaire des abonnements anonymes � la Newsletters');

define('TABLE_HEADING_NEWSLETTERS', 'Mise � jour');
define('TABLE_HEADING_SIZE', 'Taille');
define('TABLE_HEADING_MODULE', 'Module');
define('TABLE_HEADING_SENT', 'MAJ');
define('TABLE_HEADING_STATUS', 'Statut');
define('TABLE_HEADING_ACTION', 'Action');

define('TEXT_NEWSLETTER_MODULE', 'Module:');
define('TEXT_NEWSLETTER_TITLE', 'Titre Newsletter:');
define('TEXT_NEWSLETTER_CONTENT', 'Contenu:');

define('TEXT_NEWSLETTER_READ_PROCESS', 'Lire l\'aide avant mise � jour:');
define('TABLE_NEWSLETTER_UPDATE_INFO', 'Cliquer ici pour voir l\'aide');

define('TEXT_NEWSLETTER_DATE_ADDED', 'Date d\'Ajout:');
define('TEXT_NEWSLETTER_DATE_SENT', 'Date d\'envoie:');

define('TEXT_INFO_DELETE_INTRO', 'Etes vous sur de vouloir supprimer cette newsletter?');

define('TEXT_PLEASE_WAIT', 'Veuillez attendre .. nous envoyons les courriels ..<br><br>Veuillez ne pas interrompre ce processus!');
define('TEXT_FINISHED_SENDING_EMAILS', 'Envois des courriels termin�s!');

define('ERROR_NEWSLETTER_TITLE', 'Erreur: Titre de la Newsletter requis');
define('ERROR_NEWSLETTER_MODULE', 'Erreur: Module d\'appartenance de la Newsletter requis');
define('ERROR_REMOVE_UNLOCKED_NEWSLETTER', 'Error: Please lock the newsletter before deleting it.');
define('ERROR_EDIT_UNLOCKED_NEWSLETTER', 'Error: Please lock the newsletter before editing it.');
define('ERROR_SEND_UNLOCKED_NEWSLETTER', 'Error: Please lock the newsletter before sending it.');
define('TEXT_TABLE_UPDATED', 'Subscriber Table Updated !');
?>