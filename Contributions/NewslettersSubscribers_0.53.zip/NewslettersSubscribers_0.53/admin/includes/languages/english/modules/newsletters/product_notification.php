<?php
/*
  $Id: product_notification.php,v 1.3 2002/03/10 01:34:25 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/

// ################# Contribution Newsletter v050 ##############
define('TEXT_COUNT_CUSTOMERS', '&bull; Customers receiving news bulletin: <font color="#0000ff">%s</font>');
define('TEXT_PRODUCTS', 'Products');
define('TEXT_SELECTED_PRODUCTS', 'Selected products');

define('TEXT_MODULE', '&bull; Module used to send the newsletter:');
define('TEXT_BULLETIN_NUMB', '&bull; News bulletin number:');
define('TEXT_TITRE_MAIL', '&bull; Title of the news bulletin:');
define('TEXT_TITRE_INFO', '&bull; Information about the news bulletin &bull;');
define('TEXT_TITRE_VIEW', '&bull; Outline of the news bulletin &bull;');
// ################# END - Contribution Newsletter v050 ##############

define('JS_PLEASE_SELECT_PRODUCTS', 'Please select some products.');

define('BUTTON_GLOBAL', 'Global');
define('BUTTON_SELECT', '>>>');
define('BUTTON_UNSELECT', '<<<');
define('BUTTON_SUBMIT', 'Send');
define('BUTTON_CANCEL', 'Cancel');
?>