<?php
/*
  $Id: newsletter.php,v 1.3 2002/03/08 18:38:18 hpdl Exp $

  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com

  Copyright (c) 2002 osCommerce

  Released under the GNU General Public License
*/
define('TEXT_COUNT_CUSTOMERS', 'Customers receiving newsletter: %s');
// ################# Contribution Newsletter v050 ##############
define('TEXT_COUNT_CUSTOMERS', 'Customers receiving newsletter: %s');
define('TEXT_MODULE', '&bull; Module used to send the newsletter:');
define('TEXT_BULLETIN_NUMB', '&bull; News bulletin number:');
define('TEXT_TITRE_MAIL', '&bull; Title of the news bulletin:');
define('TEXT_TITRE_INFO', '&bull; Information about the news bulletin &bull;');
define('TEXT_TITRE_VIEW', '&bull; Outline of the news bulletin &bull;');
// ################# END - Contribution Newsletter v050 ##############
?>