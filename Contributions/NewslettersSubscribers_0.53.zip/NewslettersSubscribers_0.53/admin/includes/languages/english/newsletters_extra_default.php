<?php
/*
  $Id: latest_news.php,v 1.1.1.1 2002/11/11 06:15:14 will Exp $
  osCommerce, Open Source E-Commerce Solutions
  http://www.oscommerce.com
  Copyright (c) 2002 Will Mays
  Released under the GNU General Public License
*/
define('HEADING_INFOS_TITLE', 'Subscribers / Newsletter Admin');
define('TABLE_HEADING_NEWSLETTER_HEADER', 'Header');
define('TABLE_HEADING_NEWSLETTER_ID', 'Newsletter Id');
define('TABLE_HEADING_LATEST_NEWS_ACTION', 'Action');
define('TEXT_NEWS_ITEMS', 'Extra Info:');
define('TEXT_INFO_HEADING_DELETE_ITEM', 'Delete Item');
define('TEXT_DELETE_ITEM_INTRO', 'Are you sure you want to permanently delete this item?');
define('TEXT_NEW_NEWSLETTER_INFO', 'New Newsletter Info');
define('TEXT_NEWSLETTER_MODULE', 'Module used to send the newsletter:');
define('TEXT_NEWSLETTER_HEADER', 'Page Header:');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA', 'First Part of footer for Unsubscribe link:');
define('TEXT_NEWSLETTER_UNSUBSCRIBEB', 'This is a secondary footer to give optional extra information:');
define('TEXT_NEWSLETTER_UNSUBSCRIBEA_INFO', '<font color="#ff000">Information! There is the option to provide 2 footers. The first will carry the Unsubscribe link or the text preceding it, the second is for any other information you may want to include.</font>');
?>