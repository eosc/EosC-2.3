# 
# Base for Newsletters v.50+
# 

# --------------------------------------------------------

#
# Table structure for table  `subscribers`
#

CREATE TABLE `subscribers` (
  `subscribers_id` int(11) NOT NULL auto_increment,
  `customers_id` int(11) NOT NULL default '0',
  `subscribers_email_address` varchar(80) NOT NULL default '',
  `subscribers_firstname` varchar(40) default NULL,
  `subscribers_lastname` varchar(40) default NULL,
  `language` varchar(30) default NULL,
  `subscribers_gender` char(1) default NULL,
  `subscribers_email_type` varchar(5) default NULL,
  `entry_date` date default '0000-00-00',
  `undeliverable_count` mediumint(11) default '0',
  `mail_details_customers_id` int(5) default '0',
  `list_number` int(5) default '0',
  `source_import` varchar(70) default NULL,
  `date_account_created` datetime default '0000-00-00 00:00:00',
  `date_account_last_modified` datetime default '0000-00-00 00:00:00',
  `customers_newsletter` int(4) default NULL,
  `subscribers_blacklist` int(2) default '0',
  `subscription_date` datetime default '0000-00-00 00:00:00',
  `status_sent1` int(2) default '0',
  `host_name` varchar(25) default NULL,
  `hardiness_zone` char(3) default NULL,
  PRIMARY KEY  (`subscribers_id`),
  KEY `list_number` (`list_number`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


# --------------------------------------------------------

# 
# Table structure for table `subscribers_default`
#

CREATE TABLE `subscribers_default` (
  `news_id` int(11) NOT NULL auto_increment,
  `module_subscribers` varchar(255) NOT NULL default '',
  `header` text NOT NULL,
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL default '0',
  `news_order` int(2) NOT NULL default '0',
  `unsubscribea` longtext NOT NULL,
  `unsubscribeb` longtext NOT NULL,
  PRIMARY KEY  (`news_id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

# 
# Dumping data for table `subscribers_default`
# 

INSERT INTO `subscribers_default` VALUES (1, 'Module newsletter_subscribers', '', '2002-11-28 09:31:06', 1, 0, 'You can unsubscribe from our newsletter here :', '');
INSERT INTO `subscribers_default` VALUES (2, 'Module newsletter', '', '2005-01-04 03:51:20', 1, 0, '<DIV>To be unsubscribe click here :</DIV>', '<DIV>Thank you</DIV>');
INSERT INTO `subscribers_default` VALUES (3, 'Module product_notification', '', '2005-01-04 03:53:10', 1, 0, '<DIV>Thanks for using our newsletter its been great.<br /><br />\r\nWe look forward to sending you next months newsletter<br /><br />\r\nTo unsubscribe please click the following :UNSUBSCRIBE AUTOMAGICALLY ADDED HERE</DIV>', '<DIV>All content Copyright &copy; us </DIV>');

# --------------------------------------------------------

#
# Table structure for table `subscribers_infos`
#

CREATE TABLE `subscribers_infos` (
  `news_id` int(11) NOT NULL auto_increment,
  `newsletters_id` int(11) NOT NULL default '0',
  `module_subscribers` varchar(255) NOT NULL default '',
  `header` text NOT NULL,
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL default '0',
  `news_order` int(2) NOT NULL default '0',
  `unsubscribea` longtext NOT NULL,
  `unsubscribeb` longtext NOT NULL,
  PRIMARY KEY  (`news_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

#
# Dumping data for table `subscribers_infos`
#


# --------------------------------------------------------

#
# Table structure for table `subscribers_update`
#

CREATE TABLE `subscribers_update` (
  `newsletters_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `module` varchar(255) NOT NULL default '',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_sent` datetime default NULL,
  `status` int(1) default NULL,
  `locked` int(1) default '0',
  `action` text NOT NULL,
  `set_order` int(2) NOT NULL default '0',
  PRIMARY KEY  (`newsletters_id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Dumping data for table `subscribers_update`
#

INSERT INTO `subscribers_update` VALUES (1, 'Update of the table of the Subscribers', 'Compare the table of the Members recorded on the site and the table of the anonymities having subscribed to the newsletter.', 'newsletter', '2002-11-27 15:13:25', '2002-11-27 15:13:25', 1, 1, 'update', 1);
INSERT INTO `subscribers_update` VALUES (2, 'Update of the Names and First names', 'To update the whole of the data concerning the name and the first name modified by Customer Records', '', '2002-11-29 14:42:20', '2002-11-29 14:42:20', 1, 1, 'update', 2);
