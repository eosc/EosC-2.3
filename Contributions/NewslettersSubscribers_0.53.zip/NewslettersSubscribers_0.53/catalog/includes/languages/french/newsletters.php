<?
/*
English Text for The Exchange Project Preview Release 2.0
Last Update: 01/12/2000
Author(s): Harald Ponce de Leon (hpdl@theexchangeproject.org)
*/
define('TABLE_HEADING_NEW_PRODUCTS', 'Nouveaut� pour %s');
define('TABLE_HEADING_UPCOMING_PRODUCTS', 'Produit � venir');
define('TABLE_HEADING_DATE_EXPECTED', 'Date d\'envoie');

define('TEXT_NO_PRODUCTS', 'There are no references to list in this category.');

define('NAVBAR_TITLE_1', 'Newsletters');
define('NAVBAR_TITLE', 'Newsletters');
define('HEADING_TITLE', 'S\'abonner � notre Newsletter');
define('TEXT_INFORMATION', 'F�licitation, votre enregistrement s\'est effectu� avec succ�s. Vous recevrez prochainement notre lettre d\'information de la soci�t� ' . STORE_NAME . '. <br><br>Nous ne vendons pas les coordonn�s de nos clients � des soci�t�s tiers et nous garantissons la confidentialit� des informations que vous nous avez donn�es.');
define('TOP_BAR_TITLE', STORE_NAME . 'Newsletter');
define('TOP_BAR_SUCCESS', '<I>Merci ! Vous �tes maintenant abonn�s</I> � notre bulletin d\'information.<BR><BR><B>Un mail vous a �t� envoy� � l\adresse du courriel que vous avez donn�</I> afin <B>de confirmer votre enregistrement</B> et dde v�rifier que l\adresse est correcte. <BR><BR>Le courriel vous apportea de plus amples informations et instruction sur le d�sabonnement par exemple. <BR><BR> You may review as well the archives of the <B>past newsletters</B> in acrobat format at the bottom on the Section "Newsletters" of our site. <BR><BR>If you would like to <B>contribute or write an article</B> for one of our newsletters , do not hesitate to contact us . You can as well <B>use the online form in order to submit your article and pictures</B>. (The newsletter online form link is located in the section Newsletter of our site).<BR><BR>All photo credits and name of the author will of course be mentionned in our newsletter. <BR><BR> Your article will be as well stored in our Knowledge base in order to be searched by visitors.');
define('TOP_BAR_EXPLAIN', STORE_NAME . ' is dedicated to bring you sound advices and tips about <I>your site</I>, <I>special offers</I> or <I>new products</I>.<BR>If you are looking for tips and new ideas. Our newsletter is full of useful information. Just enter your e-mail address below and we will add you to our list.<BR><BR>)');
define('TOP_BAR_EXPLAIN1', ' * Note: Tous nos bulletins d\'information sont en HTML. <BR><BR>');	


define('EMAIL_WELCOME_SUBJECT', 'Bienvenue chez ' . STORE_NAME . '!');

define('EMAIL_WELCOME', '
Cher Mr, Mme ' . $lastname . ' ' . "\n\n" . '
Nous vous souhaitons la bienvenue chez ' . STORE_NAME . '! ' . "\n" . '

Nous sommes heureux de vous accueillir dans notre communaut�. ' . "\n" . '
Ce Courriel vous confirme que l\'enregistrement s\'est effectu� correctement et que vous recevrez prochainement les bulletins d\'information de la soci�t�  ' . STORE_NAME . '. ' . "\n\n" . '
Vous recevrez � partir de maintenant nos divers bulletins d\'information afin de partager avec vous toutes nos nouveaut�s ....' . "\n\n" . '
Notre politique de confidentialit� est importante pour nous. Nous ne vendons pas � des soci�t�s tiers les informations que vous nous avez fournies. ' . "\n\n" . '
Si vous avez besoin d\'aide sur nos diff�rents services en ligne, vous pouvez nous contacter via ce courriel : ' . STORE_OWNER_EMAIL_ADDRESS . ' ou utiliser notre formulaire de contact.' . "\n\n" . '

Merci encore de la confiance que vous nous t�moigniez et n\'hesitez pas � venir consulter r�guli�rement nos produits sur ' . STORE_NAME . ' ' . "\n\n" 
. 'Cordialement' . "\n" 
. 'Service Client ' . "\n" 
. STORE_NAME . "\n" 
. STORE_NAME_ADDRESS. "\n" 
. 'web: ' . HTTP_SERVER . DIR_WS_CATALOG . "\n"
. STORE_OWNER_EMAIL_ADDRESS . "\n\n" 
);


define('EMAIL_WELCOME1', '

Note : Veuillez ne pas oublier votre courriel de r�f�rence afin de vous d�sabonner si vous le souhaitez. ' . "\n\n" . '
Si vous ne souhaitez plus recevoir ce bulletin d\'information, vous trouverez un lien ci-dessous qui vous permettra de vous d�sinscrire automatiquement ou vous pouvez nous contacter via notre mail : ' . STORE_OWNER_EMAIL_ADDRESS . ' ' . "\n\n" . '
' );



define('CLOSING_BLOCK1', 'Ce courriel a �t� envoy� � : ');
define('CLOSING_BLOCK2', ' � votre demande par '.STORE_NAME.'  .');
define('CLOSING_BLOCK3', "\n\n" . 'Se d�sabonner : ' . HTTP_SERVER . DIR_WS_CATALOG . 'newsletters_unsubscribe.php?action=view&email=');
define('CLOSING_BLOCK4', "\n\n" . 'Acc�der � la page de notre politique confidentialit� : ' . HTTP_SERVER . DIR_WS_CATALOG . 'privacy.php' . '.');



define('TEXT_ORIGIN_LOGIN', '<font color="#FF0000"><small><b>NOTE:</b></font></small>Registering to receive our newsletter is a different process than registering when placing an order. To receive our newsletters, you only need to enter your name, email and country. (however you will not have access to the Club area and the online Customer Service Center.)</font>');
define('TEXT_ORIGIN_LOGIN1', '<font color="#FF0000"><small><b>NOTE2:</b></font></small>' . STORE_NAME . ' respects very strongly your privacy. We will never resell the information entered or use it in a way which was not originally explained : read our privacy page for all details.</font>');	
define('EMAIL_GREET_MR', 'Cher Mr. ');
define('EMAIL_GREET_MS', 'Ch�re Mme. ');
define('EMAIL_GREET_NONE', 'Cher ');

define('TEXT_EMAIL', 'Courriel');
define('TEXT_EMAIL_FORMAT', 'Format');
define('TEXT_GENDER', 'Civilit�');
define('TEXT_FIRST_NAME', 'Pr�nom');
define('TEXT_LAST_NAME', 'Nom');
define('TEXT_ZIP_INFO', 'By entering your Zip Code below (USA only), we can define....');
define('TEXT_ZIP_CODE', 'Code Postal');
define('TEXT_ORIGIN_EXPLAIN_BOTTOM', '');
define('TEXT_ORIGIN_EXPLAIN_TOP', '');
define('TEXT_EMAIL_HTML', 'HTML');
define('TEXT_EMAIL_TXT', 'Text');
define('TEXT_GENDER_MR', 'Mr');
define('TEXT_GENDER_MRS', 'Mrs');
?>