<?php
////////////////////////////////////////////////////////////////////////////
// $Id: Newsletter Unsubscribe, (/catalog/includes/languages/english/unsubscribe.php)v 1.0 2003/01/24
// Programed By: Christopher Bradley (www.wizardsandwars.com)
//
// Developed for osCommerce, Open Source E-Commerce Solutions
// http://www.oscommerce.com
// Copyright (c) 2003 osCommerce
//
// Released under the GNU General Public License
//
///////////////////////////////////////////////////////////////////////////

define('NAVBAR_TITLE', 'D�sabonnement');
define('HEADING_TITLE', 'D�sabonnement effectu�');

define('UNSUBSCRIBE_TEXT_INFORMATION', '<br>Vore d�sabonnement a �t� pris en compte.Si vous avez eu des d�sagr�ments de notre part veuillez nous en excuser, vous pouvez aussi regarder notre charte de confidentialit� � la rubrique : regarder la rubrique <a href="' .FILENAME_PRIVACY . '"><u>Vie priv�e</u></a> pour plus d\'information.<br><br>Les autres souscriptions restent valides, (promotions, nouveaut�s sur le site ...).<br>');
define('UNSUBSCRIBE_DONE_TEXT_INFORMATION', '<br>Votre adresse e mail ci dessous a �t� supprim�e de notre newsletter, comme demand� par votre requ�te.<br><br>');
define('UNSUBSCRIBE_ERROR_INFORMATION', '<br>L\'adresse Email ci-dessous, n\'a pas �t� trouv�e dans base de donn�es des newsletter, ou elle a �t� d�j� supprim�e de notre liste.<br><br>');
?>