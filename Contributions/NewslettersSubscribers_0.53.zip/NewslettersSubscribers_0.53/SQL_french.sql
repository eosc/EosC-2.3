# 
# Base de donn�es: `newsletter v050`
# 

# --------------------------------------------------------

#
# Structure de la table `subscribers`
#

CREATE TABLE `subscribers` (
  `subscribers_id` int(11) NOT NULL auto_increment,
  `customers_id` int(11) NOT NULL default '0',
  `subscribers_email_address` varchar(80) NOT NULL default '',
  `subscribers_firstname` varchar(40) default NULL,
  `subscribers_lastname` varchar(40) default NULL,
  `language` varchar(30) default NULL,
  `subscribers_gender` char(1) default NULL,
  `subscribers_email_type` varchar(5) default NULL,
  `entry_date` date default '0000-00-00',
  `undeliverable_count` mediumint(11) default '0',
  `mail_details_customers_id` int(5) default '0',
  `list_number` int(5) default '0',
  `source_import` varchar(70) default NULL,
  `date_account_created` datetime default '0000-00-00 00:00:00',
  `date_account_last_modified` datetime default '0000-00-00 00:00:00',
  `customers_newsletter` int(4) default NULL,
  `subscribers_blacklist` int(2) default '0',
  `subscription_date` datetime default '0000-00-00 00:00:00',
  `status_sent1` int(2) default '0',
  `host_name` varchar(25) default NULL,
  `hardiness_zone` char(3) default NULL,
  PRIMARY KEY  (`subscribers_id`),
  KEY `list_number` (`list_number`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;


# --------------------------------------------------------

#
# Structure de la table `subscribers_default`
#

CREATE TABLE `subscribers_default` (
  `news_id` int(11) NOT NULL auto_increment,
  `module_subscribers` varchar(255) NOT NULL default '',
  `header` text NOT NULL,
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL default '0',
  `news_order` int(2) NOT NULL default '0',
  `unsubscribea` longtext NOT NULL,
  `unsubscribeb` longtext NOT NULL,
  PRIMARY KEY  (`news_id`)
) TYPE=MyISAM AUTO_INCREMENT=4 ;

#
# Contenu de la table `subscribers_default`
#

INSERT INTO `subscribers_default` VALUES (1, 'Module newsletter_subscribers', '<DIV>Votre ent�te de page</DIV>', '2002-11-28 09:31:06', 1, 0, 'A tout moment vous disposez d\'un droit d\'acc�s, de modification, de rectification et de suppression des donn�es qui vous concernent (art 34 de la loi Informatique et Libert�s du 6 Janvier 1978). Vous pouvez vous d�sinscrire de la newsletter en cliquant sur le lien suivant&nbsp;:', 'ou vous pouvez nous contacter via notre mail : <A href="mailto:mail@domaine.com">mail@domaine.com</A>');
INSERT INTO `subscribers_default` VALUES (2, 'Module newsletter', '<DIV>Votre ent�te de page</DIV>', '2005-01-04 03:51:20', 1, 0, '<DIV>Pour vous d�sabonner � la newsletter, veuillez cliquer sur le lien suivant :</DIV>', '<DIV>Cordialement, toute l\'�quipe de www.maboutique.com</DIV>');
INSERT INTO `subscribers_default` VALUES (3, 'Module product_notification', '<DIV>Votre ent�te de page</DIV>', '2005-01-04 03:53:10', 1, 0, '<DIV>Pour vous d�sabonner � la notification des produits, veuillez vous connecter sur le site</DIV>', '<DIV>&nbsp;en utilsant votre login </DIV>');

# --------------------------------------------------------

#
# Structure de la table `subscribers_infos`
#

CREATE TABLE `subscribers_infos` (
  `news_id` int(11) NOT NULL auto_increment,
  `newsletters_id` int(11) NOT NULL default '0',
  `module_subscribers` varchar(255) NOT NULL default '',
  `header` text NOT NULL,
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `status` tinyint(1) NOT NULL default '0',
  `news_order` int(2) NOT NULL default '0',
  `unsubscribea` longtext NOT NULL,
  `unsubscribeb` longtext NOT NULL,
  PRIMARY KEY  (`news_id`)
) TYPE=MyISAM AUTO_INCREMENT=1 ;

#
# Contenu de la table `subscribers_infos`
#


# --------------------------------------------------------

#
# Structure de la table `subscribers_update`
#

CREATE TABLE `subscribers_update` (
  `newsletters_id` int(11) NOT NULL auto_increment,
  `title` varchar(255) NOT NULL default '',
  `content` text NOT NULL,
  `module` varchar(255) NOT NULL default '',
  `date_added` datetime NOT NULL default '0000-00-00 00:00:00',
  `date_sent` datetime default NULL,
  `status` int(1) default NULL,
  `locked` int(1) default '0',
  `action` text NOT NULL,
  `set_order` int(2) NOT NULL default '0',
  PRIMARY KEY  (`newsletters_id`)
) TYPE=MyISAM AUTO_INCREMENT=3 ;

#
# Contenu de la table `subscribers_update`
#

INSERT INTO `subscribers_update` VALUES (1, 'Mise � Jour de la table des Abonn�s', 'Compare la table des Membres enregistr�s sur le site et la table des anonymes ayant souscrit � la newsletter.', 'newsletter', '2002-11-27 15:13:25', '2002-11-27 15:13:25', 1, 1, 'update', 1);
INSERT INTO `subscribers_update` VALUES (2, 'Mise � Jour des Noms et Pr�noms', 'Mettre � jour l\'ensemble des donn�es concernant le nom et le pr�nom modifi�s par les Membes Enregistr�s', '', '2002-11-29 14:42:20', '2002-11-29 14:42:20', 1, 1, 'update', 2);
