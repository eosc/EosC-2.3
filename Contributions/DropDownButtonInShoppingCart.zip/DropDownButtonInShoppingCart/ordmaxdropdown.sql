# osCommerce, Open Source E-Commerce Solutions
# http://www.oscommerce.com
#
# Database Changes for "DROP DOWN MENU FOR SHOPPING CART" contribution
#
insert into configuration (configuration_title, configuration_key, configuration_value, configuration_description, configuration_group_id, sort_order, last_modified, date_added, use_function, set_function) values ('Max. number of Products to be ordered in drop-down', 'NUM_PROD_MAXORD', '1', 'Enter the number,that shall be shown in the drop-down menu for number of products to be ordered in the shopping cart ', '3', '999', now(), now(), NULL,NULL);