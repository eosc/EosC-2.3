
DROP DOWN BUTTON IN SHOPPING CART TO CHANGE THE NUMBER OF PRODUCTS ORDERED 13.09.2003 


DROP DOWN BUTTON IN SHOPPING CART TO CHANGE THE NUMBER OF PRODUCTS ORDERED contribution is an addition to OScommerce 2.2. It was written/tested using OSCOMMERCE MS2.2, 2003.

osCommerce:
	Open Source E-Commerce Solutions
	http://www.oscommerce.com
	Copyright (c) 2003 osCommerce
	Released under the GNU General Public License

DROP DOWN ORDER BUTTON IN SHOPPING CART:
	Contribution to OScommerce providing the possibility of a 
	DROP DOWN BUTTON IN SHOPPING CART TO CHANGE THE NUMBER OF PRODUCTS ORDERED!
	Copyright (c) 2003 Trend-Products, Singer Georg
	Released under the GNU General Public License

**********************************************************************************************************************


**********************************************************************************************************************

Languages:
	Following OSC-software conventions, the contribution is fully multi-language capable.
**********************************************************************************************************************

Changes to OSC-software :
	An overview of the installation-changes:


	Changed files:

		catalog/shopping_cart.php
		
	Database changes:
		
		insert one line into table configuration	

		

**********************************************************************************************************************

Installation:
	Precautions:
		As always: BACKUP YOUR DATABASE AND FILES BEFORE ATTEMPTING TO INSTALL THIS CONTRIBUTION.
	
	
	Changed files:"
		DO NOT COPY THE CHANGED FILES IN THE CONTRIBUTION TO YOUR STORE, THE FILES MAY BE DIFFERENT TO YOUR
		INSTALLATIONS.
		

	Changes:

	1)

	----Apply the ordmaxdropdown.sql code to your shop either manually or by copy and paste to your MySQL
 		user interface.

	2)


	-----In catalog/shopping_cart.php FIND the following(it�s line 115 in my installation):


	 for ($i=0, $n=sizeof($products); $i<$n; $i++) {
      		if (($i/2) == floor($i/2)) {
      	  	$info_box_contents[] = array('params' => 'class="productListing-even"');
      		} else {
        	$info_box_contents[] = array('params' => 'class="productListing-odd"');
      		}

      		$cur_row = sizeof($info_box_contents) - 1;

      		$info_box_contents[$cur_row][] = array('align' => 'center',
                                             'params' => 'class="productListing-data" valign="top"',
                                             'text' => tep_draw_checkbox_field('cart_delete[]', $products[$i]['id']));


	Right before above code ENTER the following:

		//change dropdown
		for ($s=0 ; $s<NUM_PROD_MAXORD; $s++) {
		$z =  $s+1;
		$options[] = array('id' => $z,
                                'text' => $z);	
		}
		//end change dropdown



	FIND the following (should be line 161):

		'text'=> tep_draw_input_field('cart_quantity[]', $products[$i]['quantity'], 'size="4"') . tep_draw_hidden_field('products_id[]', $products[$i]['id']));
		
		
	and EXCHANGE BY

		//change dropdown
                'text' => tep_draw_pull_down_menu('cart_quantity[]', $options, $products[$i]['quantity'], 'onchange="this.form.submit()').tep_draw_hidden_field('products_id[]', $products[$i]['id']));
		//end change dropdown
		




	HOW USE IT:

	Go to your admin-site and find unter Konfiguration->Maximum Values->Number of Products to be ordered
	Here you can enter the number of products, that the drop-down button in your shopping cart shall display. 


That�s it ENJOY!!!


**********************************************************************************************************************



Questions, suggestions, comments, critics, compliments, ... : georg.singer@trend-products.com

Cheerio!

Georg Singer