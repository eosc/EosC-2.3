# Insert configuration items into the configuration table.
INSERT INTO configuration (
   configuration_title,
   configuration_key,
   configuration_value,
   configuration_description,
   configuration_group_id,
   date_added
   ) VALUES (
   'Display Product Description',
   'PRODUCT_LIST_DESCRIPTION',
   1,
   'Include product description in the product listing. The product description will be included under the product name. So, the product name has to be printed in the product listing',
   8,
   now()
   );

# Insert configuration items into the configuration table.
INSERT INTO configuration (
   configuration_title,
   configuration_key,
   configuration_value,
   configuration_description,
   configuration_group_id,
   date_added
   ) VALUES (
   'Product Description',
   'PRODUCT_LIST_DESCRIPTION_MAX_LENGTH',
   200,
   'Maximum number of caracters when displaying the product description in the product listing',
   3,
   now()
   );
